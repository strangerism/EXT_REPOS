function isFile {
    param (
        $path
    )

    if ($path.EndsWith("*")){
        if (Test-Path -Path $path){
            return $true
        }else{
            return $false
        }
    }
    elseif (Test-Path -LiteralPath $path -PathType Leaf){
        return $true   
    }else{
        return $false
    }

}
function CopyFilesWithExludes {
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        # it must end with gamedata (can be relative to ext home)
        $resourcesPath,
        [Parameter(Mandatory = $true, Position = 1)]
        $modFolderPath,
        [Parameter(Mandatory = $true, Position = 2)]
        $selectedGamedata,
        [Parameter(Mandatory = $true, Position = 3)]
        # an array
        $excludePaths
    )

    # all the files under the resourcesPath
    # TODO add wildcard path handling
    $resources = Get-ChildItem -LiteralPath $resourcesPath -Recurse

    if (!$selectedGamedata.path.Contains("gamedata")){
        # this is likely a path to an xrdb
        $resourcesBasePath = $resourcesPath.Substring(0, $resourcesPath.LastIndexOf($selectedGamedata.path))
    }elseif($selectedGamedata.path.StartsWith("gamedata")){
        $resourcesBasePath = $resourcesPath.Substring(0, $resourcesPath.LastIndexOf($selectedGamedata.path))
    }else{
        $temp = $selectedGamedata.path.Substring($selectedGamedata.path.LastIndexOf("gamedata"))
        $resourcesBasePath = $resourcesPath.Substring(0, $resourcesPath.LastIndexOf($temp))
    }
    # Write-Host "CopyFilesWithExludes from $resourcesBasePath"
    foreach($resourceFile in $resources){
        # Write-Host "CopyFilesWithExludes $resourceFile"
        $match = $false

        $excludePaths.excludePaths | ForEach-Object{
            $matchingPath = $_.name
            if ($resourceFile.FullName.Replace("\","/").Contains($matchingPath)){
                $match = $true
            }
        }

        if ($match){
            ## do not copy
            # Write-Host "do not copy $($resourceFile.FullName)"
        }else{
            # extract the relative path part from the resource source path - everything up to and including gamedata
            $resourceRelativePath = $resourceFile.FullName.Replace($resourcesBasePath.Replace("/","\"),"")
            # use relative part to build destination path
            if (!$selectedGamedata.path.Contains("gamedata")){
                # this is likely a path to an xrdb
                if ($null -eq $selectedGamedata.target){
                    $destination = "$modFolderPath/$resourceRelativePath"
                }else{
                    $destination = "$modFolderPath/$($selectedGamedata.target)/$($resourceRelativePath.Substring($resourceRelativePath.LastIndexOf("\") + 1))"
                }
            }elseif ($resourceRelativePath.StartsWith("gamedata")){
                $destination = "$modFolderPath/$resourceRelativePath"
            }else{
                $destination = "$modFolderPath/gamedata/$resourceRelativePath"
            }
            
            # check if resource is a folder or a file
            if (Test-Path -LiteralPath $resourceFile.FullName -PathType Container){
                # create destination folder where does not exists
                # Write-Host "Resource is a Folder $($resourceFile.FullName)"
                if (!(Test-Path -LiteralPath $destination)) {New-Item $destination -Type Directory -Force | Out-Null}
            }else{
                # copy the file instead
                # Write-Host "Resource is a File $($resourceFile.FullName)"
                if (!(Test-Path -LiteralPath $destination)){
                    New-Item -ItemType File -Path $destination -Force | Out-Null
                }
                Copy-Item -LiteralPath $resourceFile.FullName -Destination $destination -Force
            } 
        }
    }
}
function CopyFiles {
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $resourcesPath,
        [Parameter(Mandatory = $true, Position = 1)]
        $modFolderPath,
        [Parameter(Mandatory = $true, Position = 2)]
        $selectedGamedata
    )

    # all the files under the resourcesPath
    $resources = Get-ChildItem -Path $resourcesPath -Recurse 

    if (!$selectedGamedata.path.Contains("gamedata")){
        # this is likely a path to an xrdb
        $resourcesBasePath = $resourcesPath.Substring(0, $resourcesPath.LastIndexOf($selectedGamedata.path))
    }elseif($selectedGamedata.path.StartsWith("gamedata")){
        $resourcesBasePath = $resourcesPath.Substring(0, $resourcesPath.LastIndexOf($selectedGamedata.path))
    }else{
        $temp = $selectedGamedata.path.Substring($selectedGamedata.path.LastIndexOf("gamedata"))
        $resourcesBasePath = $resourcesPath.Substring(0, $resourcesPath.LastIndexOf($temp))
    }

    foreach($resourceFile in $resources){
        
        # extract the relative path part from the resource source path - everything up to and including gamedata
        $resourceRelativePath = $resourceFile.FullName.Replace($resourcesBasePath.Replace("/","\"),"")
        # use relative part to build destination path
        if (!$selectedGamedata.path.Contains("gamedata")){
            # this is likely a path to an xrdb
            if ($null -eq $selectedGamedata.target){
                $destination = "$modFolderPath/$resourceRelativePath"
            }else{
                $destination = "$modFolderPath/$($selectedGamedata.target)/$($resourceRelativePath.Substring($resourceRelativePath.LastIndexOf("\") + 1))"
            }
        }elseif ($resourceRelativePath.StartsWith("gamedata")){
            $destination = "$modFolderPath/$resourceRelativePath"
        }else{
            $destination = "$modFolderPath/gamedata/$resourceRelativePath"
        }
        # check if resource is a folder or a file
        if (Test-Path -LiteralPath $resourceFile.FullName -PathType Container){
            # create destination folder where does not exists
            if (!(Test-Path -LiteralPath $destination)) {New-Item $destination -Type Directory -Force | Out-Null}
        }else{
            # copy the file instead
            if (!(Test-Path -LiteralPath $destination)){
                New-Item -ItemType File -Path $destination -Force | Out-Null
            }
            Copy-Item -LiteralPath $resourceFile.FullName -Destination $destination -Force
        } 
    }
}
function CopyFile {
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $resourcesPath,
        [Parameter(Mandatory = $true, Position = 1)]
        $modFolderPath,
        [Parameter(Mandatory = $true, Position = 2)]
        $selectedGamedata      
    )
    
    # check if selectedGamedata is a simple path or a json object
    if ($selectedGamedata -is [psobject]){
        # check if a custom target (or destination) is defined
        if ($null -ne $selectedGamedata.target){
            # use the target as destination path
            $gamedataPath = $selectedGamedata.target
        }else{
            # use source path as destination path
            $gamedataPath = $selectedGamedata.path
        }       
    }else{
        # use source path as destination path
        $gamedataPath = $selectedGamedata
    }

    if ($gamedataPath.Contains("appdata")){
        if ($gamedataPath.StartsWith("appdata")){
            # gamedataPath is canonical and at the root of the addon archive
            $destination = "$modFolderPath/$gamedataPath"
        }else{
            # gamedataPath is not canonical and deep within the addon archive
            $relativePath = $gamedataPath.substring($gamedataPath.IndexOf("appdata"))
            $destination = "$modFolderPath/$relativePath"
        }
    }elseif (!$gamedataPath.Contains("gamedata")){
        # this is likely a path to an xrdb
        $destination = "$modFolderPath/$gamedataPath"
    }elseif ($gamedataPath.StartsWith("gamedata")){
        # gamedataPath is canonical and at the root of the addon archive
        $destination = "$modFolderPath/$gamedataPath"
    }else{
        # gamedataPath is not canonical and deep within the addon archive
        $relativePath = $gamedataPath.substring($gamedataPath.IndexOf("gamedata"))
        $destination = "$modFolderPath/$relativePath"
    }
    # since gamedataPath is a file we must create the path first, using a dummy file
    New-Item -ItemType File -Path $destination -Force | Out-Null
    # look for [] in the path and escape it
    if ($resourcesPath.Contains("[")){
        $resourcesPath = [WildcardPattern]::Escape($resourcesPath)
    }    
    # now copy the file
    Copy-Item -Path $resourcesPath -Destination $destination -Force | Out-Null
}
function CopyFolder {
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $resourcesPath,
        [Parameter(Mandatory = $true, Position = 1)]
        $modFolderPath,
        [Parameter(Mandatory = $true, Position = 2)]
        $selectedGamedata      
    )
    
    # check if selectedGamedata is a simple path or a json object
    if ($selectedGamedata -is [psobject]){
        # check if a custom target (or destination) is defined
        if ($null -ne $selectedGamedata.target){
            # use the target as destination path
            $gamedataPath = $selectedGamedata.target
        }else{
            # use source path as destination path
            $gamedataPath = $selectedGamedata.path
        }       
    }else{
        # use source path as destination path
        $gamedataPath = $selectedGamedata
    }
    
    if ($gamedataPath.Contains("appdata")){
        if ($gamedataPath.StartsWith("appdata")){
            # gamedataPath is canonical and at the root of the addon archive
            $destination = "$modFolderPath/$gamedataPath"
        }else{
            # gamedataPath is not canonical and deep within the addon archive
            $relativePath = $gamedataPath.substring($gamedataPath.IndexOf("appdata"))
            $destination = "$modFolderPath/$relativePath"
        }
    }elseif (!$gamedataPath.Contains("gamedata")){
        # this is likely a path to an xrdb
        $destination = "$modFolderPath/$gamedataPath"
    }elseif ($gamedataPath.StartsWith("gamedata")){
        # gamedataPath is canonical and at the root of the addon archive
        $destination = "$modFolderPath/$gamedataPath"
    }else{
        # gamedataPath is not canonical and deep within the addon archive
        $relativePath = $gamedataPath.substring($gamedataPath.IndexOf("gamedata"))
        $destination = "$modFolderPath/$relativePath"
    }
    #TODO check the two lines disabled below
    # $sourceFolder = Get-Item -LiteralPath $resourcesPath
    $destFolder = Get-Item -LiteralPath $destination -ErrorAction SilentlyContinue
    # look for [] in the path and escape it
    if ($resourcesPath.Contains("[")){
        $resourcesPath = [WildcardPattern]::Escape($resourcesPath)
    } 
    # if ($sourceFolder.BaseName -eq $destFolder.BaseName -and $destFolder.Exists){
    if ($destFolder.Exists){        
        Copy-Item -Path "$resourcesPath/*" -Destination $destination -Recurse -Force | Out-Null
    }else{
        Copy-Item -Path $resourcesPath -Destination $destination -Recurse -Force | Out-Null
    }
}

function GetPatchOrigin{
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $modName,
        [Parameter(Mandatory = $true, Position = 1)]
        $pathToGamedata,        
        [Parameter(Mandatory = $true, Position = 2)]
        $profileDefinitions
    )

    $resoucesPath = "$Global:pathToEXTProfiles/$($profileDefinitions.profileName)/patches/mods/$pathToGamedata"

    # patch files is included in profile - use that
    if (Test-Path -LiteralPath $resoucesPath) {
        return $profileDefinitions.profileName
    }

    # check if mod belongs to a parent profile
    if (isModInParent $modName $profileDefinitions){
        # use path to parent patch
        $pathToPatch =  $profileDefinitions.parentProfile.name
    }else{
        $pathToPatch =  $profileDefinitions.profileName
    }

    return $pathToPatch
}
function CreatePatchMod{
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $customMod,
        [Parameter(Mandatory = $true, Position = 1)]
        $profileDefinitions
    )

    $modFolderName = $customMod.modName
    $modFolderPath = "$Global:pathToMOMods/$modFolderName"

    New-Item -Path $Global:pathToMOMods -Name $modFolderName -ItemType "directory" | Out-Null

    $pathToPatch = GetPatchOrigin $customMod.modName $customMod.pathToGamedata $profileDefinitions

    $resoucesPath = "$Global:pathToEXTProfiles/$pathToPatch/patches/mods/$($customMod.pathToGamedata)"

    Copy-Item -Path $resoucesPath -Destination $modFolderPath -Recurse | Out-Null

    CreateModPatchMetaIni  $customMod $modFolderPath

}

function createLocalMod{
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $customMod,
        [Parameter(Mandatory = $false, Position = 1)]
        $excludeMods
    )

    if ($null -ne $excludeMods -and (isModInExludeList $modName $excludeMods)){
        return
    }

    $modFolderName = $customMod.modName
    $modFolderPath = "$Global:pathToMOMods/$modFolderName"

    If(Test-Path -LiteralPath $modFolderPath){
        # do nothing
    }else{
        # create dummy mod for sorting modlist
        New-Item -Path $Global:pathToMOMods -Name $modFolderName -ItemType "directory" | Out-Null
    }

}
function CreateMod {
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $customMod,
        [Parameter(Mandatory = $true, Position = 1)]
        $profileDefinitions
    )
    
    $modFolderPath = "$Global:pathToMOMods/$($customMod.modName)"
    $addon = $profileDefinitions.addons | Where-Object { $_.addonName -eq $customMod.addonName }
    $resourcesPath = "$Global:pathToEXTWorkspace/$($addon.resourceWorkspace)/$($customMod.pathToGamedata)"

    if ($customMod.excludePaths -and !(isFile $resourcesPath)){
        # custom mod include exclude paths json that needs to be enforced
        $excludeFile = [WildcardPattern]::Escape("$Global:pathToEXTProfiles/$profileName/filters/$($customMod.excludePaths)")
        $excludePaths = Get-Content -LiteralPath $excludeFile -Raw | ConvertFrom-Json
        $selectedGamedata =  [pscustomobject]@{
            path = $customMod.pathToGamedata
        }
        CopyFilesWithExludes $resourcesPath $modFolderPath $selectedGamedata $excludePaths
    }else{
        # no excludes will be applied
        if (isFile $resourcesPath){
            # handle single file with care
            CopyFile $resourcesPath $modFolderPath $customMod.pathToGamedata
        }else{
            # pathToGamedata is a folder
            CopyFolder $resourcesPath $modFolderPath $customMod.pathToGamedata
            # Copy-Item -Path $resourcesPath -Destination "$modFolderPath/$($customMod.pathToGamedata)" -Recurse | Out-Null
        }
    }

    CreateModMetaIni $customMod $addon
}
function createFOMod {
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $customMod,
        [Parameter(Mandatory = $true, Position = 1)]
        $profileDefinitions
    )

    $profileName = $profileDefinitions.profileName

    $modFolderPath = "$Global:pathToMOMods/$($customMod.modName)"
    $addon = $profileDefinitions.addons | Where-Object { $_.addonName -eq $customMod.addonName }
    $mainModAddon = $addon
    if ($customMod.pathToGamedata -isnot [Array]){
        PromptErrorBeforeExit "FOMOD definitions only supports pathToGamedata as an array "
    }

    for($i = 0; $i -lt $customMod.pathToGamedata.Count; $i++){

        # select the gamedataPath to copy based on priority if exists
        if ($null -eq $customMod.pathToGamedata[$i].priority){
            $selectedGamedata = $customMod.pathToGamedata[$i]
        }else{
            $selectedGamedata = $customMod.pathToGamedata | Where-Object { $_.priority -eq $i }
        }

        # addonName from customMod definition is implicit
        # this might be overriden if pathToGamedata contains explicit addon definition
        if ($null -ne $selectedGamedata.addonName){
            $addon = $profileDefinitions.addons | Where-Object { $_.addonName -eq $selectedGamedata.addonName }
            if (!(Test-Path -LiteralPath "$Global:pathToEXTWorkspace/$($addon.resourceWorkspace)")){
                CreateAddonWorkspace $addon
            }
        }

        Write-Host
        DisplayGamedataPath "Processing pathToGamedata [$($selectedGamedata.priority)]: " $selectedGamedata.path ($tabIndent + $tabIndent)

        # selectedGamedata type patch is handled separately, excludes are not applied
        #TODO maybe just resolve the $resourcesPath based on type
        if ($selectedGamedata.type -eq "patch"){

            $pathToPatch = GetPatchOrigin $customMod.modName $selectedGamedata.path $profileDefinitions
            $resourcesPath = [WildcardPattern]::Escape("$Global:pathToEXTProfiles/$pathToPatch/patches/mods/$($selectedGamedata.path)")
            if (isFile $resourcesPath){
                CopyFile $resourcesPath $modFolderPath $selectedGamedata
            }else{
                # pathToGamedata is a folder
                CopyFolder $resourcesPath $modFolderPath $selectedGamedata
            }
            continue
        }

        $resourcesPath = "$Global:pathToEXTWorkspace/$($addon.resourceWorkspace)/$($selectedGamedata.path)"

        if ($customMod.excludePaths -and !(isFile $resourcesPath)){
            $excludeFile = [WildcardPattern]::Escape("$Global:pathToEXTProfiles/$profileName/filters/$($customMod.excludePaths)")
            $excludePaths = Get-Content -LiteralPath $excludeFile -Raw | ConvertFrom-Json
            CopyFilesWithExludes $resourcesPath $modFolderPath $selectedGamedata $excludePaths
        }else{
            # no excludes will be applied
            if (isFile $resourcesPath){
                # handle single file with care
                CopyFile $resourcesPath $modFolderPath $selectedGamedata
            }else{
                # pathToGamedata is a folder
                CopyFolder $resourcesPath $modFolderPath $selectedGamedata
            }
        }
    }

    CreateModMetaIni $customMod $mainModAddon
}
function createXRDBMod{
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $customMod,
        [Parameter(Mandatory = $true, Position = 1)]
        $profileDefinitions
    )

    $profileName = $profileDefinitions.profileName
    
    $modFolderPath = "$Global:pathToMOMods/$($customMod.modName)"
    $addon = $profileDefinitions.addons | Where-Object { $_.addonName -eq $customMod.addonName }
    $mainModAddon = $addon
    if ($customMod.pathToGamedata -isnot [Array]){
        PromptErrorBeforeExit "FOMOD definitions only supports pathToGamedata as an array "
    }

    for($i = 0; $i -lt $customMod.pathToGamedata.Count; $i++){

        # select the gamedataPath to copy based on priority if exists
        if ($null -eq $customMod.pathToGamedata[$i].priority){
            $selectedGamedata = $customMod.pathToGamedata[$i]
        }else{
            $selectedGamedata = $customMod.pathToGamedata | Where-Object { $_.priority -eq $i }
        }

        # addonName from customMod definition is implicit
        # this might be overriden if pathToGamedata contains explicit addon definition
        if ($null -ne $selectedGamedata.addonName){
            $addon = $profileDefinitions.addons | Where-Object { $_.addonName -eq $selectedGamedata.addonName }
            if (!(Test-Path -LiteralPath "$Global:pathToEXTWorkspace/$($addon.resourceWorkspace)")){
                CreateAddonWorkspace $addon
            }
        }

        Write-Host
        DisplayGamedataPath "Processing pathToGamedata [$($selectedGamedata.priority)]: " $selectedGamedata.path ($tabIndent + $tabIndent)

        # selectedGamedata type patch is handled separately, excludes are not applied
        #TODO maybe just resolve the $resourcesPath based on type
        if ($selectedGamedata.type -eq "patch"){

            $pathToPatch = GetPatchOrigin $customMod.modName $selectedGamedata.path $profileDefinitions
            $resourcesPath = [WildcardPattern]::Escape("$Global:pathToEXTProfiles/$pathToPatch/patches/mods/$($selectedGamedata.path)")
            if (isFile $resourcesPath){
                CopyFile $resourcesPath $modFolderPath $selectedGamedata
            }else{
                # pathToGamedata is a folder
                CopyFolder $resourcesPath $modFolderPath $selectedGamedata
            }
            continue
        }

        $compositePath = ($selectedGamedata.path).Split(":",2)
        # compositePath example "db/mods/thms.db:gamedata/zombie_head"
        if(!$compositePath[1]){
            # no inner db path declared
            # e.g. "db/mods/textures_act.db"
            # e.g. "db/mods/textures_act*"
            # but it could be a loose path to gamedata
            # in both cases resourcePath is the same
            
            $resourcesPath = "$Global:pathToEXTWorkspace/$($addon.resourceWorkspace)/$($selectedGamedata.path)"
        }else{
            # split path
            # e.g. db/mods/thms.db:gamedata/act --> explore and copy
            #      db/mods/thms.db:gamedata --> explode and copy
            # [0] "db/mods/thms.db"
            # [1] "gamedata/act"
            # we need to explode the archive and set $resourcesPath to xrdb archive workspace
            
            # resolve the name of the xrdb workspace when exploded
            $xrdbws = GetXrDbWorkspaceName $compositePath[0]

            $resourceWorkspacePath = "$Global:pathToEXTWorkspace/$($addon.resourceWorkspace)"

            if (Test-Path -LiteralPath "$resourceWorkspacePath/$xrdbws"){
                # db file workspace alread created
            }else{
                # if (!(Test-Path -LiteralPath $compositePath[0] -PathType leaf)){
                #     PromptErrorBeforeExit " XRDB path element $($compositePath[0]) does not exists or is not a file, cannot create xrdb workspace "
                # }
                # explode the xrdb file
                CreateEXTWorkspaceFromXr $resourceWorkspacePath $compositePath[0]
            }
            $resourcesPath = "$Global:pathToEXTWorkspace/$($addon.resourceWorkspace)/$xrdbws/$($compositePath[1])"
            $selectedGamedata.path = $compositePath[1]
        }

        if ($customMod.excludePaths -and !(isFile $resourcesPath)){
            $excludeFile = [WildcardPattern]::Escape("$Global:pathToEXTProfiles/$profileName/filters/$($customMod.excludePaths)")
            $excludePaths = Get-Content -LiteralPath $excludeFile -Raw | ConvertFrom-Json
            CopyFilesWithExludes $resourcesPath $modFolderPath $selectedGamedata $excludePaths
        }else{
            # no excludes will be applied
            if ($resourcesPath.EndsWith("*")){
                # multiple files since a wildcard is present at the end of the path
                CopyFiles $resourcesPath $modFolderPath $selectedGamedata
            }elseif (isFile $resourcesPath){
                # handle single file with care
                CopyFile $resourcesPath $modFolderPath $selectedGamedata
            }else{
                # pathToGamedata is a folder
                CopyFolder $resourcesPath $modFolderPath $selectedGamedata
            }
        }
    }

    CreateModMetaIni $customMod $mainModAddon
}
function RemoveMOMods{
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $profileDefinitions
    )

    
    DisplayProcessStep "Deleting $($profileDefinitions.profileName) ModOrganizer Mods"
    
    foreach ($customMod in $profileDefinitions.customMods){

        # $modFolderName = $profileCode + "_" +$customMod.modName
        $modFolderName = $customMod.modName
        $modFolderPath = "$Global:pathToMOMods/$modFolderName"
        DisplayModName $customMod.modName $tabIndent

        if (Test-Path -LiteralPath $modFolderPath) {
            $pathToMetaIni = "$Global:pathToMOMods/$modFolderName/meta.ini"
            $modMetaIni = [ModMetaIni]::new()
            $modMetaIni.Load($pathToMetaIni)
            
            if ($modMetaIni.properties.'modType' -eq "local"){
                DisplayWarningMessage "Keeping local mod $($customMod.modName)" $tabIndent
                continue
            }
            ExitIfPathIsProhibited($modFolderPath)
            Remove-Item -Recurse -Force -LiteralPath $modFolderPath
            # Remove-Item -Recurse -Force -LiteralPath [WildcardPattern]::Escape($modFolderPath)
        }else{
            DisplayNoticeMessage "Cannot find mod folder $modFolderPath" ($tabIndent + $tabIndent)
            DisplayNoticeText "This warning can be ingored if mod was not installed in the first place, e.g. mods from parents that are not used this profile" ($tabIndent + $tabIndent)
        }
    }

    RemoveProfileSeparatorMod $profileDefinitions

}

function RemoveMOMod{
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $mod
    )

    $modFolderPath = "$Global:pathToMOMods/$($mod.modName)"
    DisplayModName $mod.modName $tabIndent
    ExitIfPathIsProhibited($modFolderPath)
    try {
        Remove-Item -Recurse -Force -LiteralPath $modFolderPath -ErrorAction Stop
    }
    catch {
        Write-Host
        DisplayNoticeMessage " Could not delete old mod, probably it does not exists " ($tabIndent + $tabIndent)
    }
    
}

function UpdateMOMod {
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $profileDefinitions,
        [Parameter(Mandatory = $true, Position = 1)]
        $modName
    )

    $modFolderPath = "$Global:pathToMOMods/$modName"
    DisplayModName $modName $tabIndent
    ExitIfPathIsProhibited($modFolderPath)
    Remove-Item -Recurse -Force -LiteralPath $modFolderPath



}

function RemoveParentMods{
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $profileDefinitions
    )

    $parentProfileDefinitions = GetProfileDefinitions $profileDefinitions.parentProfile.name

    RemoveMOMods $parentProfileDefinitions
}

function CreateParentMods{
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $profileDefinitions
    )

    DisplayProcessStep " Installing parent mods required by this profile "

    $moParentProfileDefinitions = GetMOParentBuildProfileDefinitions $profileDefinitions

    if ($moParentProfileDefinitions){

        # parent is installed in MO
        if($moParentProfileDefinitions.version -ne $profileDefinitions.parentProfile.version){
            # version not matching
            DisplayNegativeText "A compatible parent is installed in MO but is not the required version for this profile"
            DisplayErrorMessage " Install aborted " 
        }else{
            # version matches, no need to install mods
            DisplayInfoMessage " Parent is installed already "
        }
    }else{
        
        $parentProfileDefinitions = GetProfileDefinitions $profileDefinitions.parentProfile.name

        CreateMOMods $parentProfileDefinitions $profileDefinitions.parentProfile.excludeMods
    }

}
function CreateEXTSeparatorMod{

    $modFolderName = GetEXTSeparatorModName
    $modFolderPath = "$Global:pathToMOMods/$modFolderName"

    if (!(Test-Path -LiteralPath $modFolderPath)){
        New-Item -Path $Global:pathToMOMods -Name $modFolderName -ItemType "directory" | Out-Null
        CreateSeparatorMetaIni $modFolderPath
    }
}
function GetEXTSeparatorModName {
    return "[ EXT ] EXT Build Version $($Global:version)_separator"
}
function RemoveEXTSeparatorMod{

    $modFolderName = "*EXT Build Version*"
    $modFolderPath = "$Global:pathToMOMods/$modFolderName"

    if (Test-Path -Path $modFolderPath){
        ExitIfPathIsProhibited($modFolderPath)
        Remove-Item -Recurse -Force -Path $modFolderPath | Out-Null
    }
}
function GetProfileSeparatorModName {
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $profileDefinitions       
    )

    if ($profileDefinitions.profileType -eq "kit" -or $profileDefinitions.profileType -eq "clone"){
        $profileSeparatorModName = "[ EXT ] $($profileDefinitions.profileBaseName) Version $($profileDefinitions.profileBaseVersion)_separator"
    }else{
        $profileSeparatorModName = "[ EXT ] $($profileDefinitions.profileName) Version $($profileDefinitions.version)_separator"
    }

    return $profileSeparatorModName
}
function IsModSignpost {
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $modName,
        [Parameter(Mandatory = $true, Position = 1)]
        $profileDefinitions        
    )
    
    # if ($modName -eq "$($profileDefinitions.profileName) - Custom Mods Compatibility Patch"){
    #     return $true
    # }

    # $namePrefix = GetSignpostsModsNamePrefix $profileDefinitions
    $namePrefix = "[ EXT ]"

    if ($modName -eq "$namePrefix - $Global:highPrioritySignpostModName"){
        return $true
    }

    if ($modName -eq "$namePrefix - Your HIGH priority Custom Mods_separator"){
        return $true
    }

    if ($modName -eq "$namePrefix - $Global:lowPrioritySignpostModName"){
        return $true
    }

    if ($modName -eq "$namePrefix - Your LOW priority Custom Mods_separator"){
        return $true
    }

    return $false
}
function CreateKitCustomModsSignpost {
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $profileDefinitions
    )
    
    $kitsDefinitions = GetProfileKitsDefinitions($profileDefinitions.profileName) 

    if ($kitsDefinitions){
        foreach($kit in $kitsDefinitions.kits){

            # Custom Mods Compatibility patch
            # TODO check if a cmcp custommod definitions exists already in profiledefinitions
            $cmcp = "$($kit.profileName) - Custom Mods Compatibility Patch"
            if (Test-Path "$pathToEXTProfiles/patches/mods/CMCP/$($kit.profileName)"){
                $modGamedataPath = "CMCP/$($kit.profileName)/gamedata"
            }else{
                $modGamedataPath = "CMCP/$($profileDefinitions.profileName)/gamedata"
            }
            $customMod = [PSCustomObject]@{
                modName = $cmcp
                pathToGamedata = $modGamedataPath
            }
            $modFolderName = $customMod.modName
            $modFolderPath = "$Global:pathToMOMods/$modFolderName"
            if (Test-Path -LiteralPath $modFolderPath) {
                ExitIfPathIsProhibited($modFolderPath)
                Remove-Item -Recurse -Force -LiteralPath $modFolderPath | Out-Null
            }    
            CreatePatchMod $customMod $profileDefinitions
        }
    }
}

function RemoveKitCustomModsSignpost {
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $profileDefinitions
    )
    
    $kitsDefinitions = GetProfileKitsDefinitions($profileDefinitions.profileName) 

    if ($kitsDefinitions){
        foreach($kit in $kitsDefinitions.kits){

            $modFolderName = "$($kit.profileName) - Custom Mods Compatibility Patch"
            $modFolderPath = "$Global:pathToMOMods/$modFolderName"
            if (Test-Path -LiteralPath $modFolderPath) {
                ExitIfPathIsProhibited($modFolderPath)
                Remove-Item -Recurse -Force -LiteralPath $modFolderPath | Out-Null
            } 

        }
    }
}

function RemoveProfileCustomModsCompatibilityPatch {
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $profileDefinitions
    )

    $modFolderName = "$($profileDefinitions.profileName) - Custom Mods Compatibility Patch"
    $modFolderPath = "$Global:pathToMOMods/$modFolderName"
    if (Test-Path -LiteralPath $modFolderPath) {
        ExitIfPathIsProhibited($modFolderPath)
        Remove-Item -Recurse -Force -LiteralPath $modFolderPath | Out-Null
    } 
}

function RemoveProfileCustomModsSignposts{

    $namePrefix = "[ EXT ]"

    $modFolderName = "$namePrefix - Your LOW priority Custom Mods_separator"
    $modFolderPath = "$Global:pathToMOMods/$modFolderName"
    if (Test-Path -LiteralPath $modFolderPath) {
        ExitIfPathIsProhibited($modFolderPath)
        Remove-Item -Recurse -Force -LiteralPath $modFolderPath | Out-Null
    } 

    $modFolderName = "$namePrefix - $Global:lowPrioritySignpostModName"
    $modFolderPath = "$Global:pathToMOMods/$modFolderName"
    if (Test-Path -LiteralPath $modFolderPath) {
        ExitIfPathIsProhibited($modFolderPath)
        Remove-Item -Recurse -Force -LiteralPath $modFolderPath | Out-Null
    } 

    $modFolderName = "$namePrefix - Your HIGH priority Custom Mods_separator"
    $modFolderPath = "$Global:pathToMOMods/$modFolderName"
    if (Test-Path -LiteralPath $modFolderPath) {
        ExitIfPathIsProhibited($modFolderPath)
        Remove-Item -Recurse -Force -LiteralPath $modFolderPath | Out-Null
    }
    
    $modFolderName = "$namePrefix - $Global:highPrioritySignpostModName"
    $modFolderPath = "$Global:pathToMOMods/$modFolderName"
    if (Test-Path -LiteralPath $modFolderPath) {
        ExitIfPathIsProhibited($modFolderPath)
        Remove-Item -Recurse -Force -LiteralPath $modFolderPath | Out-Null
    }    
}

function CreateProfileCustomModsCompatibilityPatch{

    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $profileDefinitions
    )

    # Custom Mods Compatibility patch
    # TODO check if a cmcp custommod definitions exists already in profiledefinitions
    $cmcp = "$($profileDefinitions.profileName) - Custom Mods Compatibility Patch"

    if ($profileDefinitions.profileType -eq "clone"){
        $modGamedataPath = "CMCP/$($profileDefinitions.clonedFrom.profileName)/gamedata"
    }else{
        $modGamedataPath = "CMCP/$($profileDefinitions.profileName)/gamedata"
    }
    $customMod = [PSCustomObject]@{
        modName = $cmcp
        pathToGamedata = $modGamedataPath
    }
    $modFolderName = $customMod.modName
    $modFolderPath = "$Global:pathToMOMods/$modFolderName"
    if (Test-Path -LiteralPath $modFolderPath) {
        ExitIfPathIsProhibited($modFolderPath)
        Remove-Item -Recurse -Force -LiteralPath $modFolderPath | Out-Null
    }    
    CreatePatchMod $customMod $profileDefinitions
}
function CreateProfileCustomModsSignposts{

    $namePrefix = "[ EXT ]"

    # separator and mod for low priority custom mods signposting 
    $separatorModName = "$namePrefix - Your LOW priority Custom Mods_separator"
    CreateProfileSeparatorMod $separatorModName

    $tipModName = "$namePrefix - $Global:lowPrioritySignpostModName"
    $customMod = [PSCustomObject]@{
        modName = $tipModName
        pathToGamedata = "gamedata"
    }
    $modFolderName = $customMod.modName
    $modFolderPath = "$Global:pathToMOMods/$modFolderName"
    if (Test-Path -LiteralPath $modFolderPath) {
        ExitIfPathIsProhibited($modFolderPath)
        Remove-Item -Recurse -Force -LiteralPath $modFolderPath | Out-Null
    }        
    createLocalMod $customMod

    # separator and mod for high priority custom mods signposting 
    $separatorModName = "$namePrefix - Your HIGH priority Custom Mods_separator"
    CreateProfileSeparatorMod $separatorModName

    $tipModName = "$namePrefix - $Global:highPrioritySignpostModName"
    $customMod = [PSCustomObject]@{
        modName = $tipModName
        pathToGamedata = "gamedata"
    }
    $modFolderName = $customMod.modName
    $modFolderPath = "$Global:pathToMOMods/$modFolderName"
    if (Test-Path -LiteralPath $modFolderPath) {
        ExitIfPathIsProhibited($modFolderPath)
        Remove-Item -Recurse -Force -LiteralPath $modFolderPath | Out-Null
    }        
    createLocalMod $customMod
}

function CreateProfileSeparatorMod{
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $modName,
        [Parameter(Mandatory = $false, Position = 1)]
        $excludeMods       
    )

    if ($null -ne $excludeMods -and (isModInExludeList $modName $excludeMods)){
        return
    }

    $modFolderPath = "$Global:pathToMOMods/$modName"

    if (!(Test-Path -LiteralPath $modFolderPath)){
        New-Item -Path $Global:pathToMOMods -Name $modName -ItemType "directory" | Out-Null
        CreateSeparatorMetaIni $modFolderPath
    }
}
function RemoveProfileSeparatorMod{
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $profileDefinitions                    
    )

    $modFolderName = "*$($profileDefinitions.profileName) Version*"
    $modFolderPath = "$Global:pathToMOMods/$modFolderName"

    if (Test-Path -Path $modFolderPath){
        ExitIfPathIsProhibited($modFolderPath)
        Remove-Item -Recurse -Force -Path $modFolderPath | Out-Null
    }
}
function CreateMOMods{
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $profileDefinitions,
        [Parameter(Mandatory = $false, Position = 1)]
        $excludeMods,
        [Parameter(Mandatory = $false, Position = 2)]
        $update    
    )

    if ($null -ne $update){
        DisplayProcessStep " Updating Mod Organizer Mods "
    }else{
        DisplayProcessStep " Creating Mod Organizer Mods "
    }
    Write-Host

    foreach ($customMod in $profileDefinitions.customMods){
        if ($force.IsPresent){
            # install mods regardless
        }else{
            # check if this is an udpate, then only process mod that are in the update list
            if ($null -ne $update){
                $updateCandidate = $update | Where-Object { $_.modName -eq $customMod.modName }
                if ($null -eq $updateCandidate){
                    Continue
                }
            }
            # check if mods are installed by parent, if yes skip mod installation
            if (isModInInstalledParent $customMod.modName $profileDefinitions){
                if (($null -ne $update) -and (isModInstalled $customMod.modName)){
                    DisplayParentInstalledModName $customMod.modName $tabIndent
                    Write-Host
                    Continue
                }
            }  
            # check if mod is in the excludeMods
            if ($null -ne $excludeMods){
                if (isModInExludeList $customMod.modName $excludeMods){
                    # mod is excluded
                    DisplayParentSkippedModName $customMod.modName $tabIndent
                    Write-Host
                    Continue
                }
            } 
        }

        DisplayHeadingMessage " Creating Mod: $($customMod.modName) "
        Write-Host
        if (($customMod.modType -ne "patch") -and ($customMod.modType -ne "separator")){
            CreateModWorkspace $profileDefinitions $customMod
        }

        DisplayModName $customMod.modName $tabIndent
        # $modFolderName = $profileCode + "_" +$customMod.modName
        $modFolderName = $customMod.modName
        $modFolderPath = "$Global:pathToMOMods/$modFolderName"
        
        if (Test-Path -LiteralPath $modFolderPath) {
            ExitIfPathIsProhibited($modFolderPath)
            Remove-Item -Recurse -Force -LiteralPath $modFolderPath | Out-Null
        }

        if ($customMod.modType -eq "separator"){
            New-Item -Path $Global:pathToMOMods -Name $modFolderName -ItemType "directory" | Out-Null
            CreateSeparatorMetaIni $modFolderPath
        }else{

            if ($customMod.modType -eq "patch"){

                CreatePatchMod $customMod $profileDefinitions
            }elseif ($customMod.modType -eq "fomod"){

                createFOMod $customMod $profileDefinitions
            }elseif ($customMod.modType -eq "xrdbmod"){

                createXRDBMod $customMod $profileDefinitions
            }elseif ($customMod.modType -eq "local"){
                CreateLocalMod $customMod
            }else{

                createMod $customMod $profileDefinitions
            }

        }

        # look for [] in the path and escape it
        if ($modFolderPath.Contains("[")){
            $modFolderPath = [WildcardPattern]::Escape($modFolderPath)
        }

        [int]$modSize = [math]::Round(((Get-ChildItem $modFolderPath -Recurse | Measure-Object -Property Length -Sum -ErrorAction Stop).Sum / 1MB),0)
        if ($Global:optionsList -contains "compilesize"){
            SetModSize $customMod.modName $modSize
        }
        if ($modSize -ge 1){
            Write-Host
            DisplayNoticeText "Size of installed mod: $modSize MB" $($tabIndent + $tabIndent)
            $Global:installedModsSize += $modSize
        }else{
            [int]$modSize = [math]::Round(((Get-ChildItem $modFolderPath -Recurse | Measure-Object -Property Length -Sum -ErrorAction Stop).Sum / 1KB),0)
            Write-Host
            DisplayNoticeText "Size of installed mod: $modSize KB" $($tabIndent + $tabIndent)
        }   
        Write-Host  
        ClearModWorkspace $profileDefinitions $customMod  
    }

    if($null -eq $excludeMods){
        CreateProfileSeparatorMod $(GetProfileSeparatorModName $profileDefinitions)
    }
    Write-Host
    DisplayNoticeMessage "Size of all installed mods: $Global:installedModsSize MB" $tabIndent
    Write-Host
}

function GetModDefinitions {
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $profileDefinitions,
        [Parameter(Mandatory = $true, Position = 1)]
        $modName        
    )

    foreach ($customMod in $profileDefinitions.customMods) {
        if ($customMod.modName -eq $modName){
            return $customMod
        }
    }
    $parentDefinitions = GetParentProfileDefinitions $profileDefinitions
    
    if ($parentDefinitions){
        foreach ($customMod in $parentDefinitions.customMods) {
            if ($customMod.modName -eq $modName){
                return $customMod
            }
        }
    }
    return $null
    
}

function BuildCustomModDefinition{
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $modName,
        [Parameter(Mandatory = $true, Position = 1)]
        $profileModAction,      
        [Parameter(Mandatory = $true, Position = 2)]
        $forExport
    )

    $pathToMetaIni = "$Global:pathToMOMods/$modName/meta.ini"
    
    if ((Test-Path -LiteralPath $pathToMetaIni) -eq $false){
        # the mod in MO does not have a meta ini. # many of GAMMA default mods are like this but also new added mods for some reason dont have meta.ini? quite unusual
        # lets generate a basic MO meta.ini for ourselves, it will be replaced with the proper one soon after because it's a new mow

        $pathToMetaTemplate = "$Global:pathToEXTTemplates/meta.ini"

        #TODO this must be moved outside of this class
        $metainiTemplate = Get-Content -Path $pathToMetaTemplate -Raw
        [ModMetaIni]::SaveNew($pathToMetaIni, $metainiTemplate)
    }

    $modMetaIni = [ModMetaIni]::new()
    $modMetaIni.Load($pathToMetaIni)

    if ($modMetaIni.isNewMod -eq $true){
        BuildModMetaIni $modName $profileModAction $forExport
        $modMetaIni.Load($pathToMetaIni)
    }else{

        if (($modMetaIni.properties.modType -eq "mod") -or ($modMetaIni.properties.modType -eq "fomod")){

            if ($modMetaIni.properties.addonUrl -eq ""){
                $modMetaIni.EditProperty("addonUrl")
            }
        
            if ($modMetaIni.properties.fileUrl -eq ""){
                $modMetaIni.EditProperty("fileUrl")
            }

            if ($modMetaIni.properties.info -eq "" -and $forExport){
                $modMetaIni.EditProperty("info")
            }

            $modMetaIni.Save()          
        }

    }

    if (($modMetaIni.properties.'modType' -eq "local") -and ($forExport -eq $true)){
        return
    }

    $customModDefinition = [PSCustomObject]@{
        modName = $modName
        info = $modMetaIni.properties.'info'
        modType = $modMetaIni.properties.'modType'
        addonName = $modMetaIni.properties.'addonName'
    }

    if (($modMetaIni.properties.'modType' -eq "fomod") -or ($modMetaIni.properties.'modType' -eq "xrdbmod")){
        $ModGamedata = @()
        $pathToGamedata = ConvertFrom-Json -InputObject $modMetaIni.properties.'pathToGamedata'
        foreach($gamedata in $pathToGamedata){
            $ModGamedata += $gamedata
        }
        
    }else{
        $ModGamedata = $modMetaIni.properties.'pathToGamedata'
    }

    $customModDefinition | Add-Member -MemberType NoteProperty -Name "pathToGamedata" -Value $ModGamedata

    if ( $modMetaIni.properties.'excludePaths' -ne ""){
        $customModDefinition | Add-Member -MemberType NoteProperty -Name "excludePaths" -Value $modMetaIni.properties.'excludePaths'
    }

    return $customModDefinition
}
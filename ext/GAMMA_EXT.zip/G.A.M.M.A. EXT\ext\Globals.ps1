$AppProps = convertfrom-stringdata (get-content "./app.properties" -raw).Replace("\","/")

if ((Test-Path -Path $AppProps.'gammafolder') -eq $False) {
    PromptMessageBeforeExit cannot find path to $AppProps.'gammafolder' - ensure gammafoder in app.properties points to your GAMMA folder
} 

if ((Test-Path -Path $AppProps.'anomalyfolder') -eq $False) {
    PromptMessageBeforeExit cannot find path to $AppProps.'anomalyfolder' - ensure anomalyfoder in app.properties points to your Anomaly folder
} 

if ((Test-Path -Path $AppProps.'7zipFolder') -eq $False) {
    PromptMessageBeforeExit cannot find path to $AppProps.'7zipFolder' - ensure 7zipFolder in app.properties points to your 7zip folder
} 

if ((Test-Path -Path $AppProps.'extfolder') -eq $False) {
    PromptMessageBeforeExit cannot find path to $AppProps.'extfolder' - ensure extfolder in app.properties points to your EXT folder
} 
$Global:optionsList = @()

$Global:version = 0.68
$Global:extUrl = "https://discordapp.com/channels/912320241713958912/1035976982321692802/1035976982321692802"
$Global:7zPath =  $AppProps.'7zipFolder' + "/7z.exe"
$Global:unpackerPath = $AppProps.'anomalyfolder' + "/tools/converter.exe"
$Global:xrCompress = $AppProps.'anomalyfolder' + "/tools/Anomaly-Mod-Compress/xrCompress.exe"
$Global:xrCompressConfig = $AppProps.'anomalyfolder' + "/tools/Anomaly-Mod-Compress/xrCompress.ltx"
$Global:pathToAnomalyAppdata = $AppProps.'anomalyfolder' + "/appdata"
$Global:pathToAnomalyBin = $AppProps.'anomalyfolder' + "/bin"
$Global:pathToAnomaly = $AppProps.'anomalyfolder'
$Global:AnomalyShaderCache = $AppProps.'anomalyfolder' + "/appdata/shaders_cache"

$Global:pathToMOIni = $AppProps.'gammafolder' +"/ModOrganizer.ini"
$Global:pathToMOMods = $AppProps.'gammafolder' + "/mods"
$Global:pathToMOProfiles = $AppProps.'gammafolder' + "/profiles"
$Global:gammaModlistFile = $AppProps.'gammafolder' + "/.Grok's Modpack Installer/G.A.M.M.A/modpack_data/modlist.txt"
$Global:gammaUserSettings = $AppProps.'gammafolder' + "/.Grok's Modpack Installer/G.A.M.M.A/modpack_patches/appdata/user.ltx"
$Global:pathToGAMMAReshade = $AppProps.'gammafolder' + "/.Grok's Modpack Installer/G.A.M.M.A/modpack_patches/bin"
$Global:pathToGAMMAPatches = $AppProps.'gammafolder' + "/.Grok's Modpack Installer/G.A.M.M.A/modpack_patches"
$Global:pathToGAMMASettingsAppdata = $AppProps.'extfolder' + "/settings/G.A.M.M.A/appdata/*"
$Global:GAMMAOverwrite = $AppProps.'gammafolder' + "/overwrite"
$Global:GAMMAMods = $AppProps.'gammafolder' + "/mods"
[int]$Global:installedModsSize = 0
[int]$Global:maxWorkspaceSize = 0

$Global:pathToExtIni = "./ext.ini"
$Global:pathToEXTProfiles = $AppProps.'extfolder' + "/profiles"
$Global:pathToEXTSettings = $AppProps.'extfolder' + "/settings"
$workspace = $AppProps.'workspacefolder'
if ($workspace){
    $Global:pathToEXTWorkspace = $workspace
}else{
    $Global:pathToEXTWorkspace = $AppProps.'extfolder' + "/workspace"
}
$Global:pathToEXTBackups = $AppProps.'extfolder' + "/backups"
$Global:pathToEXTTemplates = $AppProps.'extfolder' + "/ext/templates"

if ($AppProps.'addonsfolder'){
    $Global:pathToEXTAddons = $AppProps.'addonsfolder'
}else{
    $Global:pathToEXTAddons = $AppProps.'extfolder' + "/addons"
}
if ($AppProps.'browserpath'){
    $Global:pathToUserBrowser = $AppProps.'browserpath'
}else{
    $Global:pathToUserBrowser = "chrome.exe"
}
$Global:pathToEXTBrowserProfile = "$env:HOMEDRIVE" + "$env:HOMEPATH" + "\.ext\BrowserProfile"

$Global:pathToEXTShared = $AppProps.'extfolder' + "/shared"
$Global:WelcomeBanner = $AppProps.'extfolder' + "/ext/templates/banners/welcome-banner.txt"
$Global:InstallBanner = $AppProps.'extfolder' + "/ext/templates/banners/install-banner.txt"
$Global:ListProfilesBanner = $AppProps.'extfolder' + "/ext/templates/banners/listp-banner.txt"
$Global:VerifyBanner = $AppProps.'extfolder' + "/ext/templates/banners/verify-banner.txt"
$Global:UninstallBanner = $AppProps.'extfolder' + "/ext/templates/banners/uninstall-banner.txt"
$Global:InstallCompletionBanner = $AppProps.'extfolder' + "/ext/templates/banners/install-completion-banner.txt"

$Global:tabIndent = "    "

$Global:highPrioritySignpostModName = "[ TIP - Place your HIGH priority custom mods in this section. Can cause crashes or instability ]" 
$Global:lowPrioritySignpostModName = "[ TIP - Place your LOW priority custom mods in this section. Less likely to cause crashes or instability ]"
function InitializeExtIni {

    . ".\ext\ExtIni.ps1"

    if (Test-Path -Path $Global:pathToExtIni){
        $extIni = [ExtIni]::new()
        $extIni.Load($Global:pathToExtIni)
        $confirmdl = $extIni.properties.'confirmation_dl'
        if ($confirmdl -eq $true){
            $Global:confirmdl = $true
        }else{
            $Global:confirmdl = $false
        }
        $autodl = $extIni.properties.'automatic_dl'
        if ($autodl -eq $true){
            $Global:autodl = $true
        }else{
            $Global:autodl = $false
        }
        $browserdl = $extIni.properties.'browser_dl'
        if ($browserdl -eq $true){
            $Global:browserdl = $true
        }else{
            $Global:browserdl = $false
        }
    }else{
        # create the ini
        $extIniTemplate = Get-Content -Path "$Global:pathToEXTTemplates/ext.ini" -Raw
        $extIniTemplate = $extIniTemplate.Replace('%version%',$Global:version)
        $extIniTemplate = $extIniTemplate.Replace('%confirmation_dl%',$true)
        $extIniTemplate = $extIniTemplate.Replace('%automatic_dl%',$false)
        [ExtIni]::SaveNew($Global:pathToExtIni, $extIniTemplate)
    }
}

InitializeExtIni

function ExitIfPathIsProhibited {
    param (
        $aPath
    )
    $_pathToProfiles = $AppProps.'gammafolder' + "/profiles"
    $_pathToMOIni = $AppProps.'gammafolder' +"/ModOrganizer.ini"
    $_pathToMOMods = $AppProps.'gammafolder' + "/mods"
    $_gammaModlistFile = $AppProps.'gammafolder' + "/.Grok's Modpack Installer/G.A.M.M.A/modpack_data/modlist.txt"
    $_pathToGAMMAReshade = $AppProps.'gammafolder' + "/.Grok's Modpack Installer/G.A.M.M.A/modpack_patches/bin"

    $_unpackerPath = $AppProps.'anomalyfolder' + "/tools/converter.exe"
    $_pathToAnomalyAppdata = $AppProps.'anomalyfolder' + "/appdata"
    $_pathToAnomalyBin = $AppProps.'anomalyfolder' + "/bin"

    $_pathToEXTProfiles = $AppProps.'extfolder' + "/profiles"
    $_pathToEXTSettings = $AppProps.'extfolder' +"/settings"
    $_pathToEXTAddons = $AppProps.'extfolder' +"/addons"
    $_pathToEXTBackups = $AppProps.'extfolder' +"/backups"

    if (($aPath -eq $_pathToProfiles) -or ($aPath -eq $_pathToMOIni) -or ($aPath -eq $_pathToMOMods)) {
        PromptMessageBeforeExit " Error on addressing host path: $aPath "
    }
    elseif (($aPath -eq $_gammaModlistFile) -or ($aPath -eq $_pathToGAMMAReshade)){
        PromptMessageBeforeExit " Error on addressing host path: $aPath "
    }
    elseif (($aPath -eq $_unpackerPath) -or ($aPath -eq $_pathToAnomalyAppdata)){
        PromptMessageBeforeExit " Error on addressing host path: $aPath "
    }
    elseif (($aPath -eq $_pathToAnomalyBin)){
        PromptMessageBeforeExit " Error on addressing host path: $aPath "
    }elseif (($aPath -eq $_pathToEXTProfiles) -or ($aPath -eq $_pathToEXTSettings)) {
        PromptMessageBeforeExit " Error on addressing host path: $aPath "
    }
    elseif (($aPath -eq $_pathToEXTAddons)){
        PromptMessageBeforeExit " Error on addressing host path: $aPath "
    }
    elseif (($aPath -eq $_pathToEXTBackups)){
        PromptMessageBeforeExit " Error on addressing host path: $aPath "
    }
}

function DisplayDebugInfoFull{

    DisplayHeadingMessage " app.properties "
    Write-Host (Get-Content -Path ".\app.properties" | Out-String)
    Write-Host

    DisplayHeadingMessage " Parent folder "
    Invoke-Expression "ls ../"
    Write-Host

    DisplayHeadingMessage " Addons "
    Invoke-Expression "ls `"$Global:pathToEXTAddons`""
    Write-Host

    DisplayHeadingMessage " Settings "
    Invoke-Expression "ls ./settings"
    Write-Host

    DisplayHeadingMessage " MO Profiles "
    Invoke-Expression "ls `"$Global:pathToMOProfiles`""
    Write-Host

    DisplayHeadingMessage " MO Mods "
    Invoke-Expression "ls `"$Global:pathToMOMods`""
    Write-Host

    DisplayHeadingMessage " Anomaly bin "
    Invoke-Expression "ls `"$Global:pathToAnomalyBin`""
    Write-Host

    if (Test-Path -Path $Global:AnomalyShaderCache){
        DisplayHeadingMessage " Anomaly shaders cache "
        Invoke-Expression "ls `"$Global:AnomalyShaderCache`""
        Write-Host
    }

    DisplayHeadingMessage " Anomaly appdata "
    Invoke-Expression "ls `"$Global:pathToAnomalyAppdata`""
    Write-Host

    Write-Host " App environment " -ForegroundColor Red -BackgroundColor Yellow
    Write-Host

    DisplayHeadingMessage " EXT "
    DisplayInfoText "automatic downloads: $Global:autodl" $tabIndent
    DisplayInfoText "confirmation downloads: $Global:confirmdl" $tabIndent
    Write-Host

    DisplayHeadingMessage " Anomaly "
    DisplayInfoText "unpackerPath $Global:unpackerPath" $tabIndent
    DisplayInfoText "AnomalyAppdata $Global:pathToAnomalyAppdata" $tabIndent
    DisplayInfoText "pathToAnomalyBin $Global:pathToAnomalyBin" $tabIndent
    Write-Host

    DisplayInfoMessage " G.A.M.M.A. "
    DisplayInfoText "pathToMOIni $Global:pathToMOIni" $tabIndent
    DisplayInfoText "pathToMOMods $Global:pathToMOMods" $tabIndent
    DisplayInfoText "pathToMOProfiles $Global:pathToMOProfiles" $tabIndent
    DisplayInfoText "gammaModlistFile $Global:gammaModlistFile" $tabIndent
    Write-Host
    DisplayProcessStep " GAMMA-EXT "
    DisplayInfoText "pathToEXTProfiles $Global:pathToEXTProfiles" $tabIndent
    DisplayInfoText "pathToEXTSettings $Global:pathToEXTSettings" $tabIndent
    DisplayInfoText "pathToEXTWorkspace $Global:pathToEXTWorkspace" $tabIndent
    DisplayInfoText "pathToEXTTemplates $Global:pathToEXTTemplates" $tabIndent
    DisplayInfoText "pathToEXTAddons $Global:pathToEXTAddons" $tabIndent
    DisplayInfoText "EXTAddons $Global:pathToEXTAddons" $tabIndent
    Write-Host
}


function DisplayDebugInfo{

    DisplayHeadingMessage " app.properties "
    Write-Host (Get-Content -Path ".\app.properties" | Out-String)
    Write-Host

    DisplayHeadingMessage " Parent folder "
    Invoke-Expression "ls ../"
    Write-Host

    DisplayHeadingMessage " Settings "
    Invoke-Expression "ls ./settings"
    Write-Host

    DisplayHeadingMessage " MO Profiles "
    Invoke-Expression "ls `"$Global:pathToMOProfiles`""
    Write-Host

    Write-Host " App environment " -ForegroundColor Red -BackgroundColor Yellow
    Write-Host

    DisplayHeadingMessage " EXT "
    DisplayInfoText "automatic downloads: $Global:autodl" $tabIndent
    DisplayInfoText "confirmation downloads: $Global:confirmdl" $tabIndent
    Write-Host

    DisplayHeadingMessage " Anomaly "
    DisplayInfoText "unpackerPath $Global:unpackerPath" $tabIndent
    DisplayInfoText "AnomalyAppdata $Global:pathToAnomalyAppdata" $tabIndent
    DisplayInfoText "pathToAnomalyBin $Global:pathToAnomalyBin" $tabIndent
    Write-Host

    DisplayInfoMessage " G.A.M.M.A. "
    DisplayInfoText "pathToMOIni $Global:pathToMOIni" $tabIndent
    DisplayInfoText "pathToMOMods $Global:pathToMOMods" $tabIndent
    DisplayInfoText "pathToMOProfiles $Global:pathToMOProfiles" $tabIndent
    DisplayInfoText "gammaModlistFile $Global:gammaModlistFile" $tabIndent
    Write-Host
    DisplayProcessStep " GAMMA-EXT "
    DisplayInfoText "pathToEXTProfiles $Global:pathToEXTProfiles" $tabIndent
    DisplayInfoText "pathToEXTSettings $Global:pathToEXTSettings" $tabIndent
    DisplayInfoText "pathToEXTWorkspace $Global:pathToEXTWorkspace" $tabIndent
    DisplayInfoText "pathToEXTTemplates $Global:pathToEXTTemplates" $tabIndent
    DisplayInfoText "pathToEXTAddons $Global:pathToEXTAddons" $tabIndent
    DisplayInfoText "EXTAddons $Global:pathToEXTAddons" $tabIndent
    Write-Host
}

function DisplayDebugInfoAnomaly{

    DisplayHeadingMessage " Anomaly bin "
    Invoke-Expression "ls `"$Global:pathToAnomalyBin`""
    Write-Host

    DisplayHeadingMessage " Anomaly appdata "
    Invoke-Expression "ls `"$Global:pathToAnomalyAppdata`""
    Write-Host

    if (Test-Path -Path $Global:AnomalyShaderCache){
        DisplayHeadingMessage " Anomaly shaders cache "
        Invoke-Expression "ls `"$Global:AnomalyShaderCache`""
        Write-Host
    }

}

function DisplayDebugInfoMO{

    DisplayHeadingMessage " MO Profiles "
    Invoke-Expression "ls `"$Global:pathToMOProfiles`""
    Write-Host

    DisplayHeadingMessage " MO Mods "
    Invoke-Expression "ls `"$Global:pathToMOMods`""
    Write-Host

}

function DisplayDebugInfoMOProfiles{

    DisplayHeadingMessage " MO Profiles "
    Invoke-Expression "ls `"$Global:pathToMOProfiles`""
    Write-Host

}

function DisplayDebugInfoMOIni{

    DisplayHeadingMessage " MO Ini "
    Write-Host
    $ini = Get-Content -Path $Global:pathToMOIni
    foreach ($line in $ini){
        if ($line.Contains("[Geometry]")){
            break
        }
        Write-Host $line
    }
    Write-Host
}

function ParseMO2Settings {
    param (
        $pathToMOIni
    )

    $moIni = Get-Content -LiteralPath $pathToMOIni

    $settings = [PSCustomObject]@{
        anomalyFolder = ""
        downloadsFolder = ""
    }

    foreach($line in $MOIni)
    {

        if ($line -like "gamePath=*"){
            $settings.anomalyFolder = $line.Replace("gamePath=@ByteArray(", "").Replace("\\", "\")
            $settings.anomalyFolder = $settings.anomalyFolder.Substring(0, $settings.anomalyFolder.Length -1)
        }
        
        if ($line -like "download_directory=*"){
            $settings.downloadsFolder = $line.Replace("download_directory=", "").Replace("/","\")
        }

    }

    return $settings
}
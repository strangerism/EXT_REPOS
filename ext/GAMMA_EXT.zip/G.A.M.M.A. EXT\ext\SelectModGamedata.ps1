
class SelectModGamedata{

    $pathToEXTWorkspace = "./workspace/"

    [PSCustomObject]Parse($modName, $installationFilePath){
    
        $resourceWorkspacePath = $this.pathToEXTWorkspace + $modName
    
        CreateAddonWorkspace $modName $installationFilePath
    
        $gamedataFolders = Get-ChildItem -Path $resourceWorkspacePath -Recurse -Filter "gamedata" -Directory
        $pathToGamedata = @()
        $gamedataModDefinitions = [PSCustomObject]@{
            modType = $null
            pathToGamedata = $null
        }
        Write-Host "- pathToGamedata" -BackgroundColor DarkYellow -ForegroundColor DarkRed
        if ($gamedataFolders.Count -gt 1){
            $gamedataModDefinitions.modType = "fomod"
            $fomodConfig = Get-ChildItem $resourceWorkspacePath -Recurse -File -Include "ModuleConfig.xml"
            if ($fomodConfig.Exists){
                Write-Host
                Write-Host "    The mod's addon archive contains a " -NoNewline 
                Write-Host "FOMOD" -BackgroundColor DarkYellow -ForegroundColor DarkRed -NoNewline
                Write-Host " installer. It has different options to choose from:"  
                Write-Host
                Write-Host "    !! Make sure to match options as originally selected in the FOMOD installer, when this mod was installed in MO " -BackgroundColor DarkYellow -ForegroundColor DarkRed
                Write-Host                
                Write-Host "    !! You must choose at least one option " -BackgroundColor DarkYellow -ForegroundColor DarkRed
                Write-Host
                $this.DisplayFomodOptions($fomodConfig)

                $pathToGamedata = $this.SelectFomodOptions($fomodConfig, $resourceWorkspacePath)
            }else{
                Write-Host
                Write-Host "    The mod addon archive has different option to choose from:"
                Write-Host
                Write-Host "    !! You must choose at least one option " -BackgroundColor DarkYellow -ForegroundColor DarkRed
                Write-Host
                $this.DisplayModOptions($modName, $gamedataFolders)

                $pathToGamedata = $this.SelectModOptions($gamedataFolders, $resourceWorkspacePath)
            }   
        }else{
            $gamedataModDefinitions.modType = "mod"
            
            $addonWorkspace = (Get-Item -Path $resourceWorkspacePath).FullName + "\"
            $words = $gamedataFolders.FullName.Replace($addonWorkspace,'')
            $gamedata = $words.Trim()
    
            $gamedataDefinitions = [PSCustomObject]@{
                priority = 0
                path = $gamedata.Replace('\','/')
            }
            $pathToGamedata += $gamedataDefinitions
            $selectedPath = $gamedataDefinitions.path
            Write-Host
            Write-Host "Automatically selected: $selectedPath" -BackgroundColor Yellow -ForegroundColor Black
            Write-Host            
        }
    
        ClearAddonWorkspace $modName
        $gamedataModDefinitions.pathToGamedata = $pathToGamedata
        return $gamedataModDefinitions
    }

    DisplayModOptions($modName, $gamedataFolders){

        $y = 1
        foreach($gamedataFolder in $gamedataFolders){
            $workspace = (Get-Item -Path $this.pathToEXTWorkspace).FullName
            $words = $gamedataFolder.FullName.Replace($workspace,'')
            $option = $words.Trim().Replace('\','/').Replace($modName, "")
            Write-Host "            Option $y [$option]" -BackgroundColor Yellow -ForegroundColor Black
            $y++
        }
    }

    DisplayFomodOptions($fomodConfig){

        [XML]$optionalFileGroups = Get-Content $fomodConfig.FullName
        $y = 1
        $groups = $optionalFileGroups.SelectNodes("//group")
        foreach($group in $groups){
            $selectionGroup = $group.name
            Write-Host "            - $selectionGroup  Selection" -ForegroundColor Yellow -BackgroundColor DarkCyan
            Write-Host
            $name = $group.name
            $xpath = "//group[@name='$name']/plugins/plugin"
            $group.SelectNodes($xpath) | ForEach-Object{
                $option = $_.files.folder.source
                $description = $_.description
                if ($selectionGroup -eq "Info"){
                    Write-Host "            $description" -ForegroundColor Yellow
                }else{
                    Write-Host "            Option $y [$option]" -BackgroundColor Yellow -ForegroundColor Black
                    Write-Host
                    Write-Host "            $description" -ForegroundColor Cyan
                    $y++
                }
                Write-Host
            }
            
        }  
    }

    [PSCustomObject]SelectModOptions($gamedataFolders, $resourceWorkspacePath){
        $y = 1
        $priority = 0
        $assignedPriority = 0
        $pathToGamedata = @()
        foreach($gamedataFolder in $gamedataFolders){
            $Title = ""
            $workspace = (Get-Item -Path $this.pathToEXTWorkspace).FullName
            $words = $gamedataFolder.FullName.Replace($workspace,'')
            $option = $words.Trim().Replace('\','/')
            
            Write-Host
            Write-Host "            Option $y [$option]" -BackgroundColor Yellow -ForegroundColor Black
            Write-Host
            $Prompt = "Type `"Yes`" to add this gamedata folder to the mod definitions, `"No`" to skip"
            $Choices = [System.Management.Automation.Host.ChoiceDescription[]] @("&Yes", "&No")
            $Default = 1
    
            # Prompt for the choice
            $Choice = $global:Host.UI.PromptForChoice($Title, $Prompt, $Choices, $Default)
             
            # Action based on the choice
            switch($Choice)
            {
                0 { 
                    $addonWorkspace = (Get-Item -Path $resourceWorkspacePath).FullName + "\"
                    $words = $gamedataFolder.FullName.Replace($addonWorkspace,'')
                    $gamedata = $words.Trim()
                    
                    if (!($priority = Read-Host ">> enter a priority value for this path (lowest is 0) [Enter to accept $assignedPriority]")) { $priority = $assignedPriority }
                    $gamedataDefinitions = [PSCustomObject]@{
                        priority = $priority
                        path = $gamedata.Replace('\','/')
                    }
                    $pathToGamedata += $gamedataDefinitions
                    $assignedPriority++
                }
                1 { 
                    # selected No --> skip
                }
            }
            $y++ 
        }
        return $pathToGamedata        
    }

    [PSCustomObject]SelectFomodOptions($fomodConfig, $resourceWorkspacePath){
        Write-Host "    Please select for each options which one you like to use"  -ForegroundColor Yellow
        Write-Host 
        $y = 1
        $Title = ""
        $pathToGamedata = @()
        [XML]$optionalFileGroups = Get-Content $fomodConfig.FullName
        $y = 1
        $priority = 0
        $assignedPriority = 0
        $groups = $optionalFileGroups.SelectNodes("//group")
        foreach($group in $groups){
            $selectionGroup = $group.name

            if ($selectionGroup -eq "Info"){
                continue
            }
            Write-Host "            - $selectionGroup  Selection" -ForegroundColor Yellow -BackgroundColor DarkCyan
            $name = $group.name
            $xpath = "//group[@name='$name']/plugins/plugin"
            $group.SelectNodes($xpath) | ForEach-Object{
                $option = $_.files.folder.source
                $description = $_.description
                Write-Host
                Write-Host "            Option $y [$option]" -BackgroundColor Yellow -ForegroundColor Black
                Write-Host
                Write-Host "            $description" -ForegroundColor Cyan
                Write-Host
                $Prompt = "Type `"Yes`" to add this gamedata folder to the mod definitions, `"No`" to skip"
                $Choices = [System.Management.Automation.Host.ChoiceDescription[]] @("&Yes", "&No")
                $Default = 1
        
                # Prompt for the choice
                $Choice = $global:Host.UI.PromptForChoice($Title, $Prompt, $Choices, $Default)
                 
                # Action based on the choice
                switch($Choice)
                {
                    0 { 
                        $path = $this.ResolveOptionPath($option, $resourceWorkspacePath)
                        if (!($priority = Read-Host ">> enter a priority value for this path (lowest is 0) [Enter to accept $assignedPriority]")) { $priority = $assignedPriority }
                        $gamedataDefinitions = [PSCustomObject]@{
                            priority = $priority
                            path = $path
                        }
                        $pathToGamedata += $gamedataDefinitions
                        $assignedPriority++
                    }
                    1 { 
                        # selected No --> skip
                    }
                }
                $y++
            }
            
        } 

        return $pathToGamedata
    }

    [PSCustomObject]ResolveOptionPath($option, $resourceWorkspacePath){

        Write-Host "option `"$option`""
        if ($option -eq "gamedata"){
            return $option
        }

        $addonWorkspace = (Get-Item -Path $resourceWorkspacePath).FullName + "\"
        $path = ""
        $gameDataPaths = Get-ChildItem -Recurse -Path $addonWorkspace -Directory -Include gamedata 
        foreach($gameData in $gameDataPaths) {
            $currentPath = $gameData.FullName.Replace('\','/')
            $matchPath = $option.Replace('\','/')
            if ($currentPath.Contains($matchPath)){

                $path = $gameData.FullName.Replace($addonWorkspace, "").Replace('\','/')
                return $path
            }
        }
        return $path
    }
}

function ReadProfileModlist {

    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $profileName              
    )

    if ($profileName -eq "G.A.M.M.A") {
        $modlist = Get-Content -LiteralPath $Global:gammaModlistFile
    }else{
        if (Test-Path -LiteralPath "$pathToMOProfiles/$profileName/modlist.txt"){
            $modlist = Get-Content -LiteralPath "$pathToMOProfiles/$profileName/modlist.txt"
        }else{
            return $null
        }
    }
    $linkedList = CreateLinkedList $modlist
    return $linkedList
}

function ReadProfileBuildModlist {

    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $profileName              
    )

    if ($profileName -eq "G.A.M.M.A") {
        $modlist = Get-Content -LiteralPath $Global:gammaModlistFile
    }else{
        if (Test-Path -LiteralPath "$pathToMOProfiles/$profileName/build_modlist.txt"){
            $modlist = Get-Content -LiteralPath "$pathToMOProfiles/$profileName/build_modlist.txt"
        }else{
            return $null
        }
    }
    $linkedList = CreateLinkedList $modlist
    return $linkedList
}

function CreateLinkedList {
    param (
        $modlist
    )
    $linkedList = New-Object LinkedList(,{
        param($currentNode, $modName)
    
        if ($currentNode.name -eq $modName){
            return 0
        }else{
            return -1
        }
    
        return 1
    })
    $i = 1
    foreach($line in $modlist){
    
        if ($line -eq "" -or $line.Substring(0,1) -eq "#"){
            continue
        }
    
        $name = $line.Substring(1,$line.Length - 1)
        $state = $line.Substring(0,1)
    
        $null = $linkedList.append( @{ name = $name.Trim(); state = $state; pos = $i })

        $i++
    }

    return $linkedList    
}
function GetAction {
    param (
        $state
    )
    
    if ($state -eq "-"){
        $action = "disable"
    }else{
        $action = "enable"
    }

    return $action
}
function GetState {
    param (
        $action
    )
    
    if ($action -eq "add" -or $action -eq "add-profile-separator" -or $action -eq "enable"){
        $state = "+"
    }else{
        $state = "-"
    }

    return $state
}
function ResetProfile {
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $profileName
    )

    DisplayProcessStep "Resetting $profileName Profile Definitions and modlist"
    Write-Host
    if ($profileName -eq "G.A.M.M.A"){
        Copy-Item -LiteralPath $Global:gammaModlistFile -Destination "$Global:pathToMOProfiles/$profileName/modlist.txt"

        DisplayHeadingMessage " G.A.M.M.A Profile default modlist reset "
    }else{

        Copy-Item -LiteralPath "$Global:pathToMOProfiles/$profileName/build_profile_definitions.json" -Destination "$Global:pathToMOProfiles/$profileName/profile_definitions.json" -Force

        Copy-Item -LiteralPath "$Global:pathToMOProfiles/$profileName/build_modlist.txt" -Destination "$Global:pathToMOProfiles/$profileName/modlist.txt"

        $profileDefinitions = GetMOProfileDefinitions $profileName

        if ($null -eq $profileDefinitions){
            PromptMessageBeforeExit " This profile is $profileName not installed in MO "
        }

        SynchProfile $profileDefinitions

        DisplayHeadingMessage " EXT Profile Definitions and modlist reset "
    }

    Write-Host
    DisplayResetCompletionMessage

}
function BuildSeparatorRule {
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $action,
        [Parameter(Mandatory = $true, Position = 1)]
        $modName,
        [Parameter(Mandatory = $true, Position = 2)]
        $before                
    )

    $customLoadOrder =  [pscustomobject]@{
        action = "add-profile-separator"
        before = $before.modName
    }
    
    return $customLoadOrder
}
function BuildLoadOrderRule {
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $action,
        [Parameter(Mandatory = $true, Position = 1)]
        $modName,
        [Parameter(Mandatory = $true, Position = 2)]
        $before                
    )


    if ($action -eq "enable"){
        $newAction = "add"
    }else{
        $newAction = "add-disabled"
    }

    DisplayModOrderRule $newAction $modName $before.modName

    if ($before.modName -eq $(GetEXTSeparatorModName)){
        $customLoadOrder =  [pscustomobject]@{
            modName = $modName 
            action = $newAction
            before = $before.modName
        }
    }else{
        $customLoadOrder =  [pscustomobject]@{
            modName = $modName 
            action = $newAction
            before = $before.modName
        }
    }

    return $customLoadOrder
    
}

function ProcessProfileBuildMod {
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $action,
        [Parameter(Mandatory = $true, Position = 1)]
        $modName,
        [Parameter(Mandatory = $true, Position = 2)]
        $before                
    )
    # This custom mod belongs to:
    #
    #   1. the build profile
    #       we want to add a load rule, mod definitions and addon definitions
    #       force rule
    #       rules granted: add/add-disabled
    
    # check if it is last in modlist
    if ($null -eq $before.modName){
        PromptErrorBeforeExit " Custom Mod [$modName] cannot be enabled as last in the modlist "
    }

    # add rule
    $newCustomLoadOrderRule = BuildLoadOrderRule $action $modName $before
    
    # add mod definitions
    $customModDefinition = $moBuildProfileDefinitions.customMods| Where-Object { $_.modName -eq $modName }
    if ($dev.IsPresent){
        DisplayInfoText "Adding to definitions mod $modName" $tabindent
        Write-Host
    }
    
    # add mod definitions only if not added already or if the mod has them (e.g. patch/local don't have them)
    $addonDefinition = BuildAddonDefinition $modName
    if ($addonDefinition){
        # checks if this addon has already been added
        $addon = $newAddons | Where-Object { $_.addonName -eq $addonDefinition.addonName }
        if ($null -eq $addon){
            if ($dev.IsPresent){
                DisplayInfoText "Adding to definitions addon $($addonDefinition.addonName)" $tabIndent
                Write-Host
            }
            $newAddon = $addonDefinition
        }else{
            $newAddon = $null
        }
    }else{
        $newAddon = $null
    }

    $result =  [pscustomobject]@{
        newCustomLoadOrderRule = $newCustomLoadOrderRule 
        customModDefinition = $customModDefinition
        newAddon = $newAddon
    }

    return $result
}

function ProcessProfileParentMod {
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $action,
        [Parameter(Mandatory = $true, Position = 1)]
        $modName,
        [Parameter(Mandatory = $true, Position = 2)]
        $before                
    )
    # This custom mod belongs to:
    #  
    #   2. this parent profile
    #       we want to add a load rule and addon definitions             
    #       we dont add mod definitions
    #       force rule
    #       rules granted: add/add-disabled

    # check if it is last in modlist
    if ($null -eq $before.modName){
        PromptErrorBeforeExit " Custom Mod [$modName] cannot be enabled as last in the modlist "
    }

    # add rule
    $newCustomLoadOrderRule = BuildLoadOrderRule $action $modName $before

    # add mod definitions only if not added already or if the mod has them (e.g. patch/local don't have them)
    $addonDefinition = BuildAddonDefinition $modName
    if ($addonDefinition){
        # checks if this addon has already been added
        $addon = $newAddons | Where-Object { $_.addonName -eq $addonDefinition.addonName }
        if ($null -eq $addon){
            if ($dev.IsPresent){
                DisplayInfoText "Adding to definitions addon $($addonDefinition.addonName)" $tabIndent
                Write-Host
            }
            $newAddon = $addonDefinition
        }else{
            $newAddon = $null
        }
    }else{
        $newAddon = $null
    }

    $result =  [pscustomobject]@{
        newCustomLoadOrderRule = $newCustomLoadOrderRule 
        customModDefinition = $null
        newAddon = $newAddon
    }

    return $result
}
function ProcessEXTSeparator {
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $action,
        [Parameter(Mandatory = $true, Position = 1)]
        $modName,
        [Parameter(Mandatory = $true, Position = 2)]
        $before                
    )

    if ($action -eq "disable"){
        # don't add rule
        return $null
    }

    # add rule
    $newCustomLoadOrderRule = BuildSeparatorRule $action $modName $before
    
    $result =  [pscustomobject]@{
        newCustomLoadOrderRule = $newCustomLoadOrderRule 
        customModDefinition = $null
        newAddon = $null
    }

    return $result
}
function ProcessEXTMod {
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $action,
        [Parameter(Mandatory = $true, Position = 1)]
        $modName,
        [Parameter(Mandatory = $true, Position = 2)]
        $before                
    )
    # This custom mod belongs to:
    #
    #   3. another ext profile
    #       we want to add a load rule, mod definitions and addon definition (parse meta.ini for ext properties)
    #       rules granted: add
    #       optional rules

    if ($action -eq "disable" -and $null -eq $before.modName){
        # don't add rule
        return $null
    }

    # check if it is last in modlist
    if ($null -eq $before.modName){
        PromptErrorBeforeExit " Custom Mod [$modName] cannot be enabled as last in the modlist "
    }

    # add rule
    $newCustomLoadOrderRule = BuildLoadOrderRule $action $modName $before
    
    # add mod definitions
    $customModDefinition = BuildCustomModDefinition $modName $action $forExport
    if ($dev.IsPresent){
        DisplayInfoText "Adding to definitions mod $modName" $tabindent
        Write-Host
    }
    
    # add mod definitions only if not added already or if the mod has them (e.g. patch/local don't have them)
    $addonDefinition = BuildAddonDefinition $modName
    if ($addonDefinition){
        # checks if this addon has already been added
        $addon = $newAddons | Where-Object { $_.addonName -eq $addonDefinition.addonName }
        if ($null -eq $addon){
            if ($dev.IsPresent){
                DisplayInfoText "Adding to definitions addon $($addonDefinition.addonName)" $tabIndent
                Write-Host
            }
            $newAddon = $addonDefinition
        }else{
            $newAddon = $null
        }
    }else{
        $newAddon = $null
    }

    $result =  [pscustomobject]@{
        newCustomLoadOrderRule = $newCustomLoadOrderRule 
        customModDefinition = $customModDefinition
        newAddon = $newAddon
    }

    return $result
}

function ProcessNonEXTMod {
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $action,
        [Parameter(Mandatory = $true, Position = 1)]
        $modName,
        [Parameter(Mandatory = $false, Position = 2)]
        $before                
    )
    # This custom mod belongs to:
    #
    #   4. a non ext mod
    #       we want to add a load rule (eventually parse the meta.ini to add the rest)
    #       rules granted: add    
    #       optional rules

    if ($action -eq "disable"){
        # don't add rule
        return $null
    }

    # check if it is last in modlist
    if ($null -eq $before.modName){
        PromptErrorBeforeExit " Custom Mod [$modName] cannot be enabled as last in the modlist "
    }

    # add rule
    $newCustomLoadOrderRule = BuildLoadOrderRule $action $modName $before

    $result =  [pscustomobject]@{
        newCustomLoadOrderRule = $newCustomLoadOrderRule 
        customModDefinition = $null
        newAddon = $null
    }

    return $result
}
function FindRuleIn {
    param (
        $findInModlist,
        $modName
    )

    for ($i = 0; $i -lt $findInModlist.Count; $i++) {
        
        if ($findInModlist[$i] -eq "" -or $findInModlist[$i].Substring(0,1) -eq "#"){
            continue
        }

        $ancestorModName = $findInModlist[$i].Substring(1, $findInModlist[$i].Length - 1).Trim()
        if ($ancestorModName -eq $modName){
            $ancestorModRule =  [pscustomobject]@{
                name = $ancestorModName 
                state = $findInModlist[$i].Substring(0,1)
            }
            return $ancestorModRule
        }
    }

    return $null
}
function SaveProfile{
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $profileDefinitions,
        [Parameter(Mandatory = $true, Position = 1)]
        $forExport
    ) 

    $newAddons = @()
    $newCustomMods = @()
    $newCustomLoadOrderRules = @()
    $gamePatches = @()
    $addonPatches = @()

    $profileName = $profileDefinitions.profileName

    if ($profileDefinitions.clonedFrom){
        DisplayInfoText " Profile is a linked clone " $tabIndent
        if ($profileDefinitions.clonedFrom.profileName -eq "G.A.M.M.A"){
            DisplayNoticeText "the profile is linked with G.A.M.M.A"
            $ancestorModlist = Get-Content -LiteralPath $Global:gammaModlistFile
        }else{
            DisplayNoticeText "the profile is linked with $($profileDefinitions.clonedFrom.profileName)"
            $ancestorModlist = Get-Content -LiteralPath "$pathToMOProfiles/$($profileDefinitions.clonedFrom.profileName)/build_modlist.txt"
            # find ancestor profile separator rule
            $separatorRule = $profileDefinitions.customLoadOrderRules | Where-Object {$_.action -eq "add-profile-separator"}
            if ($separatorRule){
                $newCustomLoadOrderRules += $separatorRule
            }
        }        
    }else{
        $modpackName = "G.A.M.M.A"
        DisplayProcessStep " Profile is not a linked clone, it will extend the base modpack $modpackName"
        $ancestorModlist = Get-Content -LiteralPath $Global:gammaModlistFile
    }

    if ($null -eq $ancestorModlist){
        PromptErrorBeforeExit " Could not read Ancestor default modlist "
    }

    DisplayProcessStep " Saving EXT Profile Definitions "
    Write-Host
    DisplayInfoText "The current MO $profileName profile modlist will be saved to the EXT profile definitions installed in MO " $tabIndent
    Write-Host

    $profileModlistFile = "$Global:pathToMOProfiles/$profileName/modlist.txt"
    DisplayProcessStep " Loading profile MO modlist "
    $profileModlist = Get-Content -LiteralPath $profileModlistFile
    DisplayPositiveText ">> modlist loaded" $tabIndent

    DisplayProcessStep " Loading profile build definitions "
    $moBuildProfileDefinitions = GetMOBuildProfileDefinitions $profileName
    DisplayPositiveText ">> build definitions loaded" $tabIndent

    if ($null -eq $moBuildProfileDefinitions){
        PromptMessageBeforeExit " This profile does not have build definitions. I cannot save the profile modlist "
    }

    $gamePatches = $moBuildProfileDefinitions.gamePatches
    $addonPatches = $moBuildProfileDefinitions.addons | Where-Object { $_.addonType -eq "patch" }  

    $before =  [pscustomobject]@{
        modName = $null
        state = $null
    }
    
    DisplayProcessStep " Processing the profile modlist "
    for ($i = 0; $i -lt $profileModlist.Length; $i++) {

        $line = $profileModlist[$i]

        if ($line -eq "" -or $line.Substring(0,1) -eq "#"){
            continue
        }

        $modName = $line.Substring(1, $line.Length - 1).Trim()
        $state =  $line.Substring(0, 1)
        $action = GetAction $state

        if ($modName -eq $(GetEXTSeparatorModName)){
                # set new before
                $before.modName = $modName
                $before.state = $state   
            continue
        }
        if ($(IsModSignpost $modName $profileDefinitions)){
            # set new before
            $before.modName = $modName
            $before.state = $state   
            continue
        }

        $ancestorModRule = FindRuleIn $ancestorModlist $modName 

        if ($null -eq $ancestorModRule){
            # It's a custom mod!
            #
            # A custom mod can belong to:
            #
            #   1. the build profile
            #       we want to add a load rule, mod definitions and addon definitions    
            #   2. this parent profile
            #       we want to add a load rule and addon definitions             
            #       we dont add mod definitions       
            #   3. another ext profile
            #       we want to add a load rule, mod definitions and addon definition (parse meta.ini for ext properties)
            #   4. a non ext mod
            #       we want to add a load rule (eventually generate the meta.ini to add the rest)
            #   5. a deprecated gamma mod (how do we indentify them?)
            #       we don't add anything
            #   6. it's a separator
            #       we don't add anything yet (we need to implement this)
            
            if($dev.IsPresent){
                DisplayProcessSubStep " $modName "
            }

            $isModInProfileBuildCustomLoadOrderRules = $moBuildProfileDefinitions.customLoadOrderRules | ForEach-Object {
                if ($_.modName -eq $modName){
                    return $_.modName
                }
            }

            if ($isModInProfileBuildCustomLoadOrderRules){
                $isModInBuildProfileCustomMods = $moBuildProfileDefinitions.customMods| Where-Object { $_.modName -eq $modName }
                # Mod belongs to
                if ($isModInBuildProfileCustomMods){
                    #   1. the build profile
                    $result = ProcessProfileBuildMod $action $modName $before
                }else{
                    #   2. this parent profile
                    $result = ProcessProfileParentMod $action $modName $before
                }
            }else{
                $pathToMetaIni = "$Global:pathToMOMods/$modName/meta.ini"
                If (Test-Path -LiteralPath $pathToMetaIni){
                    
                    $modMetaIni = [ModMetaIni]::new()
                    $modMetaIni.Load($pathToMetaIni)
                    if ($modMetaIni.properties.'modType' -eq "separator"){
                        $result = ProcessEXTSeparator $action $modName $before
                    }elseif (!$modMetaIni.isNewMod){
                        #   3. another ext profile
                        $result = ProcessEXTMod $action $modName $before
                    }else{
                        #   4. a non ext mod
                        $result = ProcessNonEXTMod $action $modName $before
                    }
                }else{
                    #   4. a non ext mod
                    #   5. a deprecated gamma mod (how do we indentify them?)
                    $result = ProcessNonEXTMod $action $modName $before
                }
            }
            
            if ($null -ne $result.newCustomLoadOrderRule){
                $newCustomLoadOrderRules += $(AbstractSeparator $profileDefinitions $result.newCustomLoadOrderRule)
                # set new before
                $before.modName = $modName
                $before.state = $state                
            }else{
                if ($dev.IsPresent){
                    DisplayInfoText "Skipping rule for $modName" $tabindent
                    Write-Host
                }
            }
            if ($null -ne $result.customModDefinition){
                $newCustomMods += $result.customModDefinition
            }
            if ($null -ne $result.newAddon){
                $newAddons += $result.newAddon
            }
        }else{
            # it's an ancestor mod

            # check if it is last in modlist
            if ($action -eq "enable" -and $null -eq $before.modName){
                PromptErrorBeforeExit " GAMMA Mods cannot be enabled as last in the modlist "
            }

            if ($state -ne $ancestorModRule.state){
                # profile gamma mod state is different from gamma default list
                
                # create the loadorder rule
                $customLoadOrder =  [pscustomobject]@{
                    modName = $modName
                    action = $action
                    before = $before.modName
                }
                DisplayModOrderRule $action $modName $before.modName
                # add the rule because it differs from gamma default
                $customLoadOrder = $(AbstractSeparator $profileDefinitions $customLoadOrder)
                $newCustomLoadOrderRules += $customLoadOrder
            }
            $before.modName = $modName
            $before.state = $state
        }
    }
    DisplayPositiveText ">> modlist processing complete " $tabIndent

    DisplayProcessStep " Updating profile definitions "
    
    $profileDefinitions = [PSCustomObject]@{
        profileName = $moBuildProfileDefinitions.profileName
        profileType = $moBuildProfileDefinitions.profileType
        profileBaseName = $moBuildProfileDefinitions.profileBaseName
        profileBaseVersion = $moBuildProfileDefinitions.profileBaseVersion
        profileCreator = $moBuildProfileDefinitions.profileCreator
        version = $moBuildProfileDefinitions.version
        extVersion = $moBuildProfileDefinitions.extVersion
        parentProfile = $moBuildProfileDefinitions.parentProfile        
        addonsVersion = $moBuildProfileDefinitions.addonsVersion
        customModsVersion = $moBuildProfileDefinitions.customModsVersion
        settingsVersion = $moBuildProfileDefinitions.settingsVersion
        info = $moBuildProfileDefinitions.info
        installationDiskspaceRequirementMB = $moBuildProfileDefinitions.installationDiskspaceRequirementMB
        finalDiskspaceRequirementMB = $moBuildProfileDefinitions.finalDiskspaceRequirementMB
    }

    if ($moBuildProfileDefinitions.clonedFrom){
        $profileDefinitions | Add-Member -MemberType NoteProperty -Name "clonedFrom" -Value $moBuildProfileDefinitions.clonedFrom
        $profileDefinitions | Add-Member -MemberType NoteProperty -Name "linkedTo" -Value $moBuildProfileDefinitions.linkedTo
    }

    # if ($profileDefinitions.profileType -eq "kit"){
    #     $profileDefinitions | Add-Member -MemberType NoteProperty -Name "parentProfile" -Value $moBuildProfileDefinitions.parentProfile
    # }
    $profileDefinitions | Add-Member -MemberType NoteProperty -Name "installCompletionMessage" -Value $moBuildProfileDefinitions.installCompletionMessage

    $profileDefinitions | Add-Member -MemberType NoteProperty -Name "addons" -Value $newAddons

    $profileDefinitions.addons += $addonPatches 

    $profileDefinitions | Add-Member -MemberType NoteProperty -Name "customMods" -Value $newCustomMods

    $profileDefinitions | Add-Member -MemberType NoteProperty -Name "customLoadOrderRules" -Value $newCustomLoadOrderRules

    $profileDefinitions | Add-Member -MemberType NoteProperty -Name "gamePatches" -Value $gamePatches

    $profileDefinitionsFile = "$Global:pathToMOProfiles/$profileName/profile_definitions.json"

    Set-Content -LiteralPath $profileDefinitionsFile -Value ($profileDefinitions | ConvertTo-Json -Depth 5)

    DisplayPositiveText ">> Ext profile definitions saved in file $profileDefinitionsFile" $tabIndent
    # if($dev.IsPresent){
    #     DisplayProcessStep " Printing Updated Profile "
    #     Write-Host
    #     $profileDefinitions | ConvertTo-Json -Depth 5
    #     Write-Host
    # }
    Write-Host
    SynchProfile $profileDefinitions
    Write-Host
    DisplayHeadingMessage " EXT Profile Definitions Updated "


}
function AbstractSeparator{
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $profileDefinitions,
        [Parameter(Mandatory = $true, Position = 1)]
        $customLoadOrder          
    )

    # abstract separator mod if found
    if ($customLoadOrder.before -eq $(GetProfileSeparatorModName $profileDefinitions)){
        $customLoadOrder.before = "profile-separator"
    }elseif ($customLoadOrder.before -eq $(GetEXTSeparatorModName $profileDefinitions)){
        $customLoadOrder.before = "ext-separator"
    }

    return $customLoadOrder
}
function ResolveSeparator{
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $profileDefinitions,
        [Parameter(Mandatory = $true, Position = 1)]
        $customLoadOrderRule          
    )

    # convert before "profile-separator" or "ext-separator" into concrete separator mods  
    if ($customLoadOrderRule.before -eq "profile-separator"){
        $customLoadOrderRule.before = $(GetProfileSeparatorModName $profileDefinitions)
    }elseif ($customLoadOrderRule.before -eq "ext-separator"){
        $customLoadOrderRule.before = $(GetEXTSeparatorModName $profileDefinitions)
    }

    return $customLoadOrderRule
}
function GetSignpostsModsNamePrefix {
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $profileDefinitions 
    )
    if ($profileDefinitions.profileType -eq "kit" -or $profileDefinitions.profileType -eq "clone"){
        $namePrefix = $profileDefinitions.profileBaseName
    }else{
        $namePrefix = $profileDefinitions.profileName
    }

    return $namePrefix
}
function AddHighPriorityCustomModsSignpost{
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $profileDefinitions,
        [Parameter(Mandatory = $true, Position = 1)]
        $profileModList        
    )

    # add the profile custom mods HIGH priority signpost


    # $namePrefix = GetSignpostsModsNamePrefix $profileDefinitions
    $namePrefix = "[ EXT ]"
    
    $tipModName = "$namePrefix - $Global:highPrioritySignpostModName"
    $customModRule =  @{ name = $tipModName; state = "-"}
    $beforeNode = $profileModList.Find($(GetEXTSeparatorModName), $null)
    # Write-Host $tipModName before $beforeNode.value.name
    $null = $profileModList.Insert($customModRule, $beforeNode)
    # logging new added rule
    $newnode = $profileModList.Find($customModRule.name, $null)
    DisplayModOrderRule (GetAction $customModRule.state) $newnode.value.name $beforeNode.value.name

    $signpostModName = "$namePrefix - Your HIGH priority Custom Mods_separator"
    $customModRule =  @{ name = $signpostModName; state = "+"}
    $beforeNode = $profileModList.Find($tipModName, $null)
    # Write-Host $signpostModName before $beforeNode.value.name
    $null = $profileModList.Insert($customModRule, $beforeNode)
    # logging new added rule
    $newnode = $profileModList.Find($customModRule.name, $null)
    DisplayModOrderRule (GetAction $customModRule.state) $newnode.value.name $beforeNode.value.name    

    return $signpostModName
}
function AddLowPriorityCustomModsSignpost{
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $profileDefinitions,
        [Parameter(Mandatory = $true, Position = 1)]
        $profileModList,
        [Parameter(Mandatory = $true, Position = 2)]
        $customLoadOrderRule         
    )
    
    # add the profile separator
    $customModRule = @{ name = $(GetProfileSeparatorModName $profileDefinitions); state = "+"; pos = 9997 }
    $beforeNode = $profileModList.Find($customLoadOrderRule.before, $null)
    $null = $profileModList.Insert($customModRule, $beforeNode)
    # logging new added rule
    $newnode = $profileModList.Find($customModRule.name, $null)
    DisplayModOrderRule (GetAction $customModRule.state) $newnode.value.name $beforeNode.value.name   

    # $namePrefix = GetSignpostsModsNamePrefix $profileDefinitions
    $namePrefix = "[ EXT ]"

    # add the profile custom mods LOW priority signpost
    $tipModName = "$namePrefix - $Global:lowPrioritySignpostModName"
    $customModRule = @{ name = $tipModName; state = "-"; pos = 9998 }
    $beforeNode = $profileModList.Find($(GetProfileSeparatorModName $profileDefinitions), $null)
    $null = $profileModList.Insert($customModRule, $beforeNode)
    # logging new added rule
    $newnode = $profileModList.Find($customModRule.name, $null)
    DisplayModOrderRule (GetAction $customModRule.state) $newnode.value.name $beforeNode.value.name            

    $separatorModName = "$namePrefix - Your LOW priority Custom Mods_separator"
    $customModRule = @{ name = $separatorModName; state = "+"; pos = 9999 }
    $beforeNode = $profileModList.Find($tipModName, $null)
    $null = $profileModList.Insert($customModRule, $beforeNode)
    # logging new added rule
    $newnode = $profileModList.Find($customModRule.name, $null)
    DisplayModOrderRule (GetAction $customModRule.state) $newnode.value.name $beforeNode.value.name                 
}
function SynchProfile {
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $profileDefinitions
    )

    DisplayProcessStep "Synching MO profile $($profileDefinitions.profileName) modlist "
    Write-Host

    # read the profile base mod list that we can edit based on the changes found in the profile definitions
    # if profile is not a clone, then the profile base modlist is the modpack modlist
    # if profile is a clone, then the profile base modlist is the ancestor profile modlist

    # store the profile build modlist, this will help distinguish the custom mods added by the user
    # $profileBuildModList = ReadProfileBuildModlist $profileDefinitions.profileName

    if ($profileDefinitions.profileType -eq "clone"){
        DisplayInfoText " Profile is a linked clone " $tabIndent
        if ($profileDefinitions.clonedFrom.profileName -eq "G.A.M.M.A"){
            DisplayInfoText " The profile is linked with G.A.M.M.A " $tabIndent
            DisplayInfoText " The latest updated GAMMA modlist will be used " $tabIndent
            Write-Host
            $profileModList = ReadProfileModlist "G.A.M.M.A"
        }else{
            DisplayInfoText " The profile is linked with $($profileDefinitions.clonedFrom.profileName) " $tabIndent
            $profileModList = ReadProfileBuildModlist $profileDefinitions.clonedFrom.profileName
            if ($null -eq $profileModList){
                DisplayNoticeMessage " A linked ancestor clone profile is not installed in MO2, using `"clonetime`" ancestor modlist as fallback " $tabIndent
                $profileModList = ReadProfileBuildModlist $profileDefinitions.profileName
            }else{
                # update the build_modlist from the linked ancestor profile
                $ancestorProfilePath = "$Global:pathToMOProfiles/$($profileDefinitions.clonedFrom.profileName)"
                $clonedProfilePath = "$Global:pathToMOProfiles/$($profileDefinitions.profileName)"
                Copy-Item -LiteralPath "$ancestorProfilePath/build_modlist.txt" -Destination "$clonedProfilePath/build_modlist.txt"
                #update the clone profile definitions if the ancestor version has changed
                $ancestorProfileDefinitions = GetMOBuildProfileDefinitions $profileDefinitions.clonedFrom.profileName
                if ($ancestorProfileDefinitions.version -ne $profileDefinitions.linkedTo.version){
                    DisplayProcessStep " Updating clone definitions with updated ancestor "
                    $profileDefinitions = UpdateCloneDefinitions $profileDefinitions $ancestorProfileDefinitions
                }
            } 
        }
    }else{
        DisplayInfoText " Profile is not a linked clone, it will be synched against the base modpack G.A.M.M.A" $tabIndent
        DisplayInfoText " The latest updated GAMMA modlist will be used " $tabIndent
        $profileModList = ReadProfileModlist "G.A.M.M.A"
    }

    if ($null -eq $profileModList){
        PromptErrorBeforeExit " Could not read GAMMA default modlist "
    }

    
    # $gammaModList = ReadProfileModlist "G.A.M.M.A"

    # if base modlist is not GAMMA it will be from an EXT profile and thus it will have all the signposts already 
    $extSeparatorNode = $profileModList.Find($(GetEXTSeparatorModName), $null)
    if ($null -eq $extSeparatorNode){
        # add the ext separator
        $null = $profileModList.Prepend(@{ name = $(GetEXTSeparatorModName); state = "+"; pos = 0 })
    }
    if($profileDefinitions.profileType -eq "clone"){
        $signpostModName = AddHighPriorityCustomModsSignpost $profileDefinitions $profileModList
    }else{
        $signpostModName = $(GetEXTSeparatorModName)
    }
    
    foreach ($customLoadOrderRule in $profileDefinitions.customLoadOrderRules) {
    
        $modName = $customLoadOrderRule.modName
        $action = $customLoadOrderRule.action
        $customLoadOrderRule = $(ResolveSeparator $profileDefinitions $customLoadOrderRule)
        $before = $customLoadOrderRule.before
        $state = GetState $action
        $customModRule =  @{ name = $modName; state = $state}

        if (($action -eq "add" -or $action -eq "add-disabled") -and ($null -eq $before -or $before -eq "")){
            $beforeNode = $profileModList.Find($lastModRuleHandled, $null)
            if ($null -eq $beforeNode){
                $beforeNode = $profileModList.Find($signpostModName, $null)
            }
            $null = $profileModList.Insert($customModRule, $beforeNode)
        }
        if ($action -eq "add-profile-separator"){
            if($profileDefinitions.profileType -eq "clone"){
                AddLowPriorityCustomModsSignpost $profileDefinitions $profileModList $customLoadOrderRule
            }else{
                $customModRule = @{ name = $(GetProfileSeparatorModName $profileDefinitions); state = "+"; pos = 9999 }
                $beforeNode = $profileModList.Find($before, $null)
                $null = $profileModList.Insert($customModRule, $beforeNode)
            }
        }
        if (($action -eq "add" -or $action -eq "add-disabled") -and ($null -ne $before -and $before -ne "")){

            # check if we are overriding an already created rule
            $modRule = $profileModList.Find($modName, $null)
            if ($null -ne $modRule){
                $null = $profileModList.Delete($modName)
            }

            # check if before is missing from customloadorder rule
            if ($null -eq $before -or $before -eq ""){
                # put the mod at the bottom
                $null = $profileModList.Prepend($customModRule)
            }else{
                # check if before mod exists (if it's a gamma mod there is chance that it can disappear with updates)
                $beforeNode = $profileModList.Find($before, $null)
                if ($null -eq $beforeNode){
                    # use fallback instead
                    DisplayWarningMessage " Could not find before mod from custom load order rule "
                    DisplayNoticeText ($customLoadOrderRule | ConvertTo-Json) $tabIndent
                    DisplayNoticeText "the mod $before it's missing from current GAMMA modlist, using $($lastModRuleHandled.value.name) as fallback" $tabIndent
                    $beforeNode = $lastModRuleHandled
                }
                # check if before is GAMMA mod and it's disabled
                # $beforeIsGammaMod = isGAMMAMod $gammaModList $beforeNode.value.name
                # if($beforeIsGammaMod -and $beforeNode.value.state -eq "-" -and $null -ne $lastModRuleHandled){
                #     # ignore mod and use fallback as before instead
                #     Write-Host before is being changed from $beforeNode.value.name to $lastModRuleHandled.value.name
                #     $beforeNode = $lastModRuleHandled
                # }
                $null = $profileModList.Insert($customModRule, $beforeNode)
            }
            # store fallback mod
            $lastModRuleHandled  = $profileModList.Find($modName, $null)
            DisplayModOrderRule $action $lastModRuleHandled.value.name $beforeNode.value.name
        }

        if ($action -eq "enable") {

            $modRule = $profileModList.Find($modName, $null)

            if ($null -ne $modRule){

                # if there is a before rule
                if ($before){
                    $beforeNode = $profileModList.Find($before, $null)
                    # if the mod has benn moved
                    if ($beforeNode.next.value.name -ne $modRule.value.name){

                        $null = $profileModList.Move($customModRule, $beforeNode)
                        $lastModRuleHandled  = $profileModList.Find($modName, $null)
                        if ($null -eq $lastModRuleHandled){
                            DisplayWarningMessage " Could not find rule after being moved "
                        }
                        DisplayModOrderRule $action $lastModRuleHandled.value.name $beforeNode.value.name

                    }else{
                        $modRule.value.state = "+"
                        $lastModRuleHandled = $modRule
                        DisplayModOrderRule $action $modName
                    }
                }else{
                    $modRule.value.state = "+"
                    $lastModRuleHandled = $modRule
                    DisplayModOrderRule $action $modName
                }
            }else{
                DisplayWarningMessage " Could not find rule "
                DisplayNoticeText ($customLoadOrderRule | ConvertTo-Json) $tabIndent
            }
        }
        if ($action -eq "disable") {

            $modRule = $profileModList.Find($modName, $null)

            if ($null -ne $modRule){
                $modRule.value.state = "-"
                $lastModRuleHandled = $modRule
                DisplayModOrderRule $action $modName
            }else{
                DisplayWarningMessage " Could not find rule "
                DisplayNoticeText ($customLoadOrderRule | ConvertTo-Json) $tabIndent
            }
        }
        if ($action -eq "remove") {

            $modRule = $profileModList.Find($modName, $null)

            if ($null -ne $modRule){
                $null = $profileModList.Delete($modName)
                DisplayModOrderRule $action $modName
            }else{
                DisplayWarningMessage " Could not find rule "
                DisplayNoticeText ($customLoadOrderRule | ConvertTo-Json) $tabIndent
            }
        }               
    }

    $profileModList = $profileModList.ToArray({
        param($currentNode)
    
        $line = $currentNode.state + $currentNode.name
    
        return $line
    })

    $customModlistFile = "$Global:pathToMOProfiles/$($profileDefinitions.profileName)/modlist.txt"

    Set-Content -LiteralPath $customModlistFile -Value $profileModList

    Write-Host
    DisplayPositiveText ">> MO Profile Modlist Updated "
}
function isGAMMAMod {
    param (
        $profileModList,
        $before
    )
    $node = $profileModList.Find($before, $null)
    if ($node){
        return $true
    }else{
        return $false
    }
}
//No PBR Cubemaps
#define USE_PBR_CUBEMAPS
These scripts will rename (install) the file enhanced_animations.script to enhanced_animations.script.mohidden and back (uninstall) in several GAMMA mods

- uninstall_script.ps1
- install_script.ps1

####

If you have just installed the EXT profile, you don't need to do anything, same if you uninstall the profile with the EXT commands.

However if you decide to disable this mod or re-enable it further you must do one of the steps below. Same if you somehow decide to manually delete this mod. 

if you disable this mod
- open powershell a window
- run .\uninstall_script.ps1 .


if you enable this mod
- open powershell a window
- run .\install_script.ps1 .
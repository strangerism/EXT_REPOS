
function BuildAddonDefinition{
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $modName,
        [Parameter(Mandatory = $false, Position = 1)]
        $modMetaIni        
    )

    if ($null -eq $modMetaIni){
        $pathToMetaIni = "$Global:pathToMOMods/$modName/meta.ini"
        $modMetaIni = [ModMetaIni]::new()
        $modMetaIni.Load($pathToMetaIni)
    }

    if (($modMetaIni.properties.'modType' -eq "patch") -or ($modMetaIni.properties.'modType' -eq "local")){
        return
    }

    $addonDefinition = [PSCustomObject]@{
        addonName = $modMetaIni.properties.'addonName'
        info = $modMetaIni.properties.'addonInfo'
        addonType = "mod"
        addonSizeMB = $modMetaIni.properties.'addonSizeMB'
        addonUrl = $modMetaIni.properties.'addonUrl'
        fileUrl = $modMetaIni.properties.'fileUrl'
        resourceFilename = $modMetaIni.properties.'resourceFilename'
        resourceWorkspace = $modMetaIni.properties.'resourceWorkspace'
    }

    return $addonDefinition

}

function GetAddonDefinitions {
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $profileDefinitions,
        [Parameter(Mandatory = $true, Position = 1)]
        $addonName        
    )

    foreach ($addon in $profileDefinitions.addons) {
        if ($addon.addonName -eq $addonName){
            return $addon
        }
    }
    
    return $null
    
}

function GetAddonsResourceFileList {
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $profileDefinitions
    )

    $addonsList = @()
    foreach ($addon in $profileDefinitions.addons) {
        $addonsList += $addon.resourceFilename
    }

    return $addonsList
}
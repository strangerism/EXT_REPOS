
function SetSettingsFolders{
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $profileName
    )

    $profileSettingsFolder = "$Global:pathToEXTSettings/$profileName"

    # backup user custom settings (from save_settings) where exists
    $savedSettingsFile = "$profileSettingsFolder/appdata/saved_settings.ltx"
    if (Test-Path -LiteralPath $savedSettingsFile){
        $savedSettings = Get-Content -LiteralPath $savedSettingsFile
    }
    
    # backup manual settings edits where exists
    $manualEditsSettingsFile = "$profileSettingsFolder/appdata/manual_edits_settings.ltx"
    if (Test-Path -LiteralPath $manualEditsSettingsFile){
        $manualEditsSettings = Get-Content -LiteralPath $manualEditsSettingsFile
    }else{
        $manualEditsSettings = $null
    }

    # backup mcm saved settings where exists
    $mcmSavedSettingsFile = "$profileSettingsFolder/appdata/mcm_saved_settings.ltx"
    if (Test-Path -LiteralPath $mcmSavedSettingsFile){
        $mcmSavedSettings = Get-Content -LiteralPath $mcmSavedSettingsFile
    }else{
        $mcmSavedSettings = $null
    }    

    # deletes the old profile settings folder
    if (Test-Path -LiteralPath $profileSettingsFolder){
        Remove-Item -LiteralPath $profileSettingsFolder -Force -Recurse
    }

    # creates brand new profile settings folder
    New-Item -Path $profileSettingsFolder -ItemType Directory -Force | Out-Null

    $gamePatchesFolderBin = "$profileSettingsFolder/bin"
    New-Item -Path $gamePatchesFolderBin -ItemType Directory -Force | Out-Null

    $gamePatchesFolderAppdata = "$profileSettingsFolder/appdata"
    New-Item -Path $gamePatchesFolderAppdata -ItemType Directory -Force | Out-Null

    $gamePatchesFolderAppdata = "$profileSettingsFolder/gamedata"
    New-Item -Path $gamePatchesFolderAppdata -ItemType Directory -Force | Out-Null

    $gamePatchesFolderAppdata = "$profileSettingsFolder/db"
    New-Item -Path $gamePatchesFolderAppdata -ItemType Directory -Force | Out-Null

    # restore user custom settings (from save_settings) where exists
    if ($null -ne $savedSettings){
        Set-Content -LiteralPath $savedSettingsFile -Value $savedSettings
    }
    # restore manual settings where exists or generate an empty one
    Set-Content -LiteralPath $manualEditsSettingsFile -Value $manualEditsSettings

    # restore mcmSavedSettings settings where exists or generate an empty one
    Set-Content -LiteralPath $mcmSavedSettingsFile -Value $mcmSavedSettings

}

function GenerateUserSettings{
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $profileDefinitions     
    )

    $profileSettingsFolder = "$Global:pathToEXTSettings/$($profileDefinitions.profileName)"


    DisplayProcessStep " Generating profile user settings, user.ltx"

    [string[]]$profileUserSettings = Get-Content -Path $Global:gammaUserSettings
   
    $profileSettingsPatch = "$profileSettingsFolder/appdata/profile.ltx"

    if (Test-Path -LiteralPath $profileSettingsPatch){
        $profileUserSettings += "cfg_load profile.ltx"
    }

    $savedSettings = "$profileSettingsFolder/appdata/saved_settings.ltx"

    if (Test-Path -LiteralPath $savedSettings){
        $profileUserSettings += "cfg_load saved_settings.ltx"
    }

    $manualEditsSettings = "$profileSettingsFolder/appdata/manual_edits_settings.ltx"

    if (Test-Path -LiteralPath $manualEditsSettings){
        $profileUserSettings += "cfg_load manual_edits_settings.ltx"
    }

    $mcmSettings = "$profileSettingsFolder/appdata/mcm_default_settings.ltx"

    if (Test-Path -LiteralPath $mcmSettings){
        $profileUserSettings += "cfg_load mcm_default_settings.ltx"
    }

    $mcmSettings = "$profileSettingsFolder/appdata/mcm_saved_settings.ltx"

    if (Test-Path -LiteralPath $mcmSettings){
        $profileUserSettings += "cfg_load mcm_saved_settings.ltx"
    }

    Set-Content -LiteralPath "$Global:pathToAnomalyAppdata/user.ltx" -Value $profileUserSettings -Force -Verbose

}

function GenerateGAMMAUserSettings{
    
    DisplayProcessStep " Generating GAMMA default user settings, user.ltx"

    [string[]]$userGAMMASettings = Get-Content -Path $Global:gammaUserSettings

    $savedSettings = "./settings/G.A.M.M.A/appdata/saved_settings.ltx"

    if (Test-Path -LiteralPath $savedSettings){
        $userGAMMASettings += "cfg_load saved_settings.ltx"
    }

    $manualEditsSettings = "./settings/G.A.M.M.A/appdata/manual_edits_settings.ltx"

    if (Test-Path -LiteralPath $manualEditsSettings){
        $userGAMMASettings += "cfg_load manual_edits_settings.ltx"
    }

    $mcmSettings = "$profileSettingsFolder/appdata/mcm_default_settings.ltx"

    if (Test-Path -LiteralPath $mcmSettings){
        $profileUserSettings += "cfg_load mcm_default_settings.ltx"
    }

    $mcmSettings = "./settings/G.A.M.M.A/appdata/mcm_saved_settings.ltx"

    if (Test-Path -LiteralPath $mcmSettings){
        $userGAMMASettings += "cfg_load mcm_saved_settings.ltx"
    }

    Set-Content -LiteralPath "$Global:pathToAnomalyAppdata/user.ltx" -Value $userGAMMASettings -Verbose
}

function ApplyExePatch{
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $gamePatch,
        [Parameter(Mandatory = $true, Position = 1)]
        $gamePatchesFolder
    )


    $patchSource = "$Global:pathToEXTWorkspace/$($gamePatch.resourceWorkspace)/$($gamePatch.pathToPatch)"

    if (Test-Path -LiteralPath $patchSource -PathType Container){
        $patchSource = "$patchSource/*"
    }

    # look for [] in the path and escape it
    if ($patchSource.Contains("[")){
        $patchSource = [WildcardPattern]::Escape($patchSource)
    }

    $patchDestination = "$gamePatchesFolder/$($gamePatch.patchTarget)/"

    DisplayNoticeText " Applying exe patch: copying files from $patchSource to $patchDestination " $tabIndent

    Copy-Item -Path $patchSource -Destination $patchDestination -Recurse -Force
}
function ApplyReshadePatch{
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $gamePatch,
        [Parameter(Mandatory = $true, Position = 1)]
        $gamePatchesFolder
    )


    $patchSource = "$Global:pathToEXTWorkspace/$($gamePatch.resourceWorkspace)/$($gamePatch.pathToPatch)"

    $patchDestination = "$gamePatchesFolder/$($gamePatch.patchTarget)"

    if ((Test-Path -LiteralPath $patchDestination) -eq $false){
        New-Item -Path $patchDestination -ItemType Directory | Out-Null
    }

    $patchDestination = "$patchDestination/"

    # look for [] in the path and escape it
    if ($patchSource.Contains("[")){
        $patchSource = [WildcardPattern]::Escape($patchSource)
    }

    if (Test-Path -Path $patchSource -PathType Container){
        $patchSource = "$patchSource/*"
    }
    DisplayNoticeText " Applying reshade patch: copying files from $patchSource to $patchDestination " $tabIndent
    Copy-Item -Path $patchSource -Destination $patchDestination -Recurse -Force
}

function ApplyShaderCachePatch{
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $gamePatch,
        [Parameter(Mandatory = $true, Position = 1)]
        $gamePatchesFolder
    )


    $patchSource = "$Global:pathToEXTWorkspace/$($gamePatch.resourceWorkspace)/$($gamePatch.pathToPatch)/*"

    $patchDestination = "$gamePatchesFolder/$($gamePatch.patchTarget)"

    if ((Test-Path -LiteralPath $patchDestination) -eq $false){
        New-Item -Path $patchDestination -ItemType Directory | Out-Null
    }
    DisplayNoticeText " Applying profile patch: copying files from $patchSource to $patchDestination " $tabIndent
    Copy-Item -Path $patchSource -Destination $patchDestination -Recurse -Force
}

function ApplyProfilePatch{
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $gamePatch,
        [Parameter(Mandatory = $true, Position = 1)]
        $gamePatchesFolder
    )

    if ($profileDefinitions.profileType -eq "clone"){
        # this is a clone find the base profile instead
        $profileNameOverride = $profileDefinitions.profileBaseName
    }else{
        # patches always come from the base profile even for kits
        $profileNameOverride = $profileDefinitions.profileName
    }
    
    $patchSource = "$Global:pathToEXTProfiles/$profileNameOverride/patches/$($gamePatch.pathToPatch)"

    if (Test-Path -LiteralPath $patchSource -PathType Container){
        $patchSource = "$patchSource/*"
    }

    $patchDestination = "$gamePatchesFolder/$($gamePatch.patchTarget)"
    DisplayNoticeText " Applying profile patch: copying files from $patchSource to $patchDestination " $tabIndent
    if ((Test-Path -LiteralPath $patchDestination) -eq $false){
        New-Item -Path $patchDestination -ItemType Directory | Out-Null
    }

    $patchDestination = "$patchDestination/"

    Copy-Item -Path $patchSource -Destination $patchDestination -Recurse -Force
}
function ApplyPatches{
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $gamePatches,
        [Parameter(Mandatory = $false, Position = 1)]
        $profileName
    )

    $profileSettingsFolder = "$Global:pathToEXTSettings/$profileName"

    for($i = 0; $i -lt $gamePatches.Count; $i++){

        if ($gamePatches[$i].priority){
            $gamePatch = $gamePatches | Where-Object { $_.priority -eq $i }
        }else{
            $gamePatch = $gamePatches[$i]
        }

        if ($gamePatch.patchType -eq "profile"){

            ApplyProfilePatch $gamePatch $profileSettingsFolder
        }
        elseif($gamePatch.patchType -eq "reshade"){

            ApplyReshadePatch $gamePatch $profileSettingsFolder
        }
        elseif($gamePatch.patchType -eq "exe"){

            ApplyExePatch $gamePatch $profileSettingsFolder
        }
        elseif($gamePatch.patchType -eq "shaders_cache"){

            ApplyShaderCachePatch $gamePatch $profileSettingsFolder
        }
    
    }
}



function CreateProfileSettings {
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $profileDefinitions
    )

    DisplayProcessStep "Creating the profile game settings"
    Write-Host

    $profileSettingsFolder = "$Global:pathToEXTSettings/$($profileDefinitions.profileName)"

    if (Test-Path -LiteralPath $profileSettingsFolder){
        DisplayNoticeMessage " Profile Settings will be updated " $tabIndent
    }else{
        DisplayNoticeMessage " Profile Settings will be installed as new "  $tabIndent
    }

    # create the base profile settings
    DisplayNoticeMessage " Creating Profile Settings: $($profileDefinitions.profileName) " $tabIndent
    SetSettingsFolders $profileDefinitions.profileName
    
    ApplyPatches $profileDefinitions.gamePatches $profileDefinitions.profileName
    Write-Host
    # create kits settings if they have game patches
    $kitsDefinitions = GetProfileKitsDefinitions($profileDefinitions.profileName) 

    if ($kitsDefinitions){
        foreach($kit in $kitsDefinitions.kits){
            DisplayNoticeMessage " Creating Kit Settings: $($kit.profileName) " $tabIndent
            if ($kit.gamePatches){
    
                SetSettingsFolders $kit.profileName
                ApplyPatches $kit.gamePatches $kit.profileName
            }else{
                SetSettingsFolders $kit.profileName
                ApplyPatches $profileDefinitions.gamePatches $kit.profileName
            }
            Write-Host
        }
    }

    Write-Host
    DisplayPositiveText " >> Profile game settings created/updated"
    Write-Host
}

function RemoveSettings{
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $settingsProfileName
    )

    DisplayProcessStep " Deleting Settings "
    DisplayModName " $settingsProfileName " $tabIndent

    # archive and remove base profile settings
    DisplayProcessStep " Archiving profile settings "
    ArchiveSettings $settingsProfileName

    # if kits exists then remove the kits settings as well
    $kitsDefinitions = GetProfileKitsDefinitions($profileDefinitions.profileName)
    if($kitsDefinitions){

        foreach($kit in $kitsDefinitions.kits){

            $moKit = GetMOBuildProfileDefinitions $kit.profileName
            if ($moKit){
                # archive and remove kit settings
                ArchiveSettings $moKit.profileName
            }
        } 
    }
    CompressSettings $settingsProfileName
}

function CloneProfileSettings {
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $profileName,        
        [Parameter(Mandatory = $true, Position = 1)]
        $clonedProfile
    )

    $profileSettingsPath = "$Global:pathToEXTSettings/$profileName"
    $clonedProfileSettingsPath = "$Global:pathToEXTSettings/$clonedProfile"

    # archive old settings
    if (Test-Path -LiteralPath $clonedProfileSettingsPath){
        ArchiveSettings $clonedProfile
        CompressSettings $clonedProfile
    }

    if ($profileName -eq "G.A.M.M.A"){

        # copy gamma patches
        Copy-Item -LiteralPath $pathToGAMMAReshade -Destination "$clonedProfileSettingsPath/bin" -Recurse -Exclude *.exe, alsoft.ini, soft_oal.dll, *.bak -Force

        # copy existing gamma profile settings
        Copy-Item -Path "$profileSettingsPath/bin/*" -Destination "$clonedProfileSettingsPath/bin" -Recurse -Force

        Copy-Item -LiteralPath "$profileSettingsPath/appdata" -Destination "$clonedProfileSettingsPath/appdata" -Recurse -Force

    }else{

        # copy profile settings
        Copy-Item -LiteralPath $profileSettingsPath -Destination $clonedProfileSettingsPath -Recurse -Force
    }    
}

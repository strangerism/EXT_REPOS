#ifndef	LMODEL_H
#define LMODEL_H

#include "common.h"
#include "common_brdf.h"
#include "pbr_brdf.h"

//////////////////////////////////////////////////////////////////////////////////////////
// Lighting formulas

float4 compute_lighting(float3 N, float3 V, float3 L, float4 alb_gloss, float mat_id)
{
	float3 albedo = float3(0.18, 0.18, 0.18);
	float3 specular = float3(SPECULAR_BASE, SPECULAR_BASE, SPECULAR_BASE);
	float rough = 1 - Ldynamic_color.w;
	
	calc_material(alb_gloss, mat_id, rough, albedo, specular);
	
	float3 light = Lit_BRDF(rough, albedo, specular, V, N, L );

	if(abs(mat_id-MAT_FLORA) <= MAT_FLORA_ELIPSON) //Be aware of precision loss/errors
	{
		//Simple subsurface scattering
		float subsurface = SSS(N,V,L);
		light.rgb += subsurface*albedo;
	}	

	return float4(light, 0);
}

float4 plight_infinity(float m, float3 pnt, float3 normal, float4 c_tex, float3 light_direction )
{
	//gsc vanilla stuff
	float3 N = normalize(normal);							// normal 
	float3 V = normalize(-pnt);					// vector2eye
	float3 L = normalize(-light_direction);						// vector2light

	float4 light = compute_lighting(N,V,L,c_tex,m);
	
	return light; // output (albedo.gloss)
}

float4 plight_local(float m, float3 pnt, float3 normal, float4 c_tex, float3 light_position, float light_range_rsq, out float rsqr )
{
	float3 L2P = pnt - light_position;                       		// light2point 
	rsqr = dot(L2P,L2P); // distance 2 light (squared)
	/*
	//vanilla atten - linear
	float att = saturate(1.0 - rsqr*light_range_rsq); // q-linear attenuate
	//float att = saturate(1.0 - sqrt(rsqr*light_range_rsq)); //sharper more inv quad like
	att = SRGBToLinear(att);
	*/
	//custom atten - sort of inverse square with sharpness and peak brightness control
	//float att_invquad = 1.0/(rsqr+1.0); //true inverse square
	float range = 1.0/sqrt(light_range_rsq);
	float dist = sqrt(rsqr);
	float att_lin = saturate((range-dist)/range);
	float quadsharp = 32.0;
	float quadpeak = 4.0;
	quadpeak = 1.0/quadpeak;
	float att_quad = 1.0/(quadsharp*rsqr*light_range_rsq+quadpeak);
	float att = att_lin*att_quad;
	
	float3 N = normalize(normal);							// normal 
	float3 V = normalize(-pnt);					// vector2eye
	float3 L = normalize(-L2P);					// vector2light

	float4 light = compute_lighting(N,V,L,c_tex,m);
	
	return att*light;		// output (albedo.gloss)
}

float3 specular_phong(float3 pnt, float3 normal, float3 light_direction)
{
	/*
	float3 H = normalize(pnt + light_direction );
	float nDotL = saturate(dot(normal, light_direction));
	float nDotH = saturate(dot(normal, H));
	float nDotV = saturate(dot(normal, pnt));
	float lDotH = saturate(dot(light_direction, H));
	//float vDotH = saturate(dot(pnt, H));
	return L_sun_color.rgb * Lit_Specular(nDotL, nDotH, nDotV, lDotH, 0.02, 0.1);
	*/
	return 0.0;
}

//	TODO: DX10: Remove path without blending
half4 blendp(half4 value, float4 tcp)
{
	return 	value;
}

half4 blend(half4 value, float2 tc)
{
	return 	value;
}

#endif
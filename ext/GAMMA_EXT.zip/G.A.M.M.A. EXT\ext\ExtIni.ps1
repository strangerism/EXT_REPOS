class ExtIni{

    $pathToEXTTemplates = "./ext/templates/"
    [string]$pathToExtIni
    [string]$extIni
    [pscustomobject]$properties

    [void] Load($pathToExtIni){
        
        $this.pathToExtIni = $pathToExtIni
        $this.extIni = Get-Content $pathToExtIni -Raw
        $this.properties = ConvertFrom-StringData $this.extIni

    } 

    [void] Save(){

        $this.properties.GetEnumerator() | % { "$($_.Name)=$($_.Value)" } > $this.pathToExtIni
    }

    [void] static SaveNew($pathToExtIni, $extIni){
        Set-Content -LiteralPath $pathToExtIni -Value $extIni
    }

    [void]EditProperty($propertyName, $propertyValue){

        iex "`$this.properties.$propertyName = `$propertyValue"
    }
}
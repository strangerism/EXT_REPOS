function PromptConfirmationDownloadsDisclaimer {

    Write-Host
    DisplayNoticePause " Attention, you are disabling Confirmation Downloads. Please read carefully the following disclaimer before doing so "
    Write-Host

    Write-Host
    DisplayProcessStep " What is Confirmation Downloads "
    Write-Host
    DisplayInfoText "If you have enabled Automatic Downloads, by default when automatically downloading addons it will asky for confirmation before doing so " $tabIndent
    Write-Host
    DisplayInfoText "This is to give you the option of checking the addon url before initiating a download by EXT " ($tabIndent + $tabIndent)
    DisplayInfoText "You can always refuse downloads of url that you do not feel comfortable to download from " ($tabIndent + $tabIndent)
    DisplayInfoText "The downsize is that commands that use Automatic Downloads requires prompts from you and cannot be completed unattended " ($tabIndent + $tabIndent)
    Write-Host

    DisplayProcessStep " What are the risks? "
    Write-Host
    DisplayInfoText "If you disable Confirmation Downloads, addons will be downloaded automatically without confirmation from you " $tabIndent
    Write-Host
    DisplayInfoText "As long as you are using EXT official profiles this should not be a problem" $tabIndent
    Write-Host
    DisplayWarningMessage " DO NOT DOWNLOAD profiles from anywhere else " $tabIndent

    Write-Host
    DisplayInfoMessage " You can enable confirmation downloads at any time "
    Write-Host
    DisplayInfoText ">> run .\GAMMA_EXT.ps1 -enable confirmation-dl" $tabIndent

    DisplayProcessStep " Disable Confirmation Downloads "

    $Prompt = "Do you want to disable Confirmation Downloads?"
    $Choices = [System.Management.Automation.Host.ChoiceDescription[]] @("&Yes", "&No")
    $Default = 1
    Write-Host
    # Prompt for the choice
    $Choice = $host.UI.PromptForChoice($Title, $Prompt, $Choices, $Default)
     
    # Action based on the choice
    switch($Choice)
    {
        0 { 
            ## continue
        }
        1 { 
            Write-Host
            DisplayNoticeMessage " You choose not to disable Confirmation Downloads "
            Write-Host
            exit
        }
    }
}
function PromptAutomaticDownloadsDisclaimer {

    Write-Host
    DisplayNoticePause " Attention, you are enabling Automatic Downloads. Please read carefully the following disclaimer before doing so "
    Write-Host

    Write-Host
    DisplayProcessStep " What is Automatic Downloads "
    Write-Host
    DisplayInfoText "Enabling Automatic Downloads in EXT will allows some EXT commands to do the following  " $tabIndent
    Write-Host
    DisplayInfoText "- Automatically download and update the EXT toolset to the latest version " ($tabIndent + $tabIndent)
    DisplayInfoText "- Automatically download and add to EXT the latest version of any profiles " ($tabIndent + $tabIndent)
    DisplayInfoText "- Automatically download addons when installing/updating profiles " ($tabIndent + $tabIndent)
    DisplayInfoText "- quick update of profiles can only be done if Automatic Downloads is enabled, otherwise you'll have to do a full install to udpate a profile to a new version " ($tabIndent + $tabIndent)
    Write-Host

    DisplayProcessStep " What are the risks? "
    Write-Host
    DisplayInfoText "While both EXT and profiles automatic download will happens unpromted, the addons automatic download will ask for your confirmation before downloading and saving it in the ``addons`` folder" $tabIndent
    DisplayInfoText "Before downloading any addon, EXT will prompt you with the download link and ask for confirmation if you want to proceed and download the addon file on your computer" $tabIndent
    Write-Host
    DisplayWarningMessage "It's your responsability to check the links are not suspicious " $tabIndent
    Write-Host
    DisplayInfoText "Addons download links are normally from ModDb, Discord server or any cloud drive (google drive, mega, etc) " ($tabIndent + $tabIndent)
    Write-Host
    DisplayWarningMessage "If you notice suspicious addons links prompted by a profile install, please notify this at the EXT profile page " $tabIndent
    Write-Host
    DisplayInfoText "As long as you are using EXT official profiles this should not be a problem" ($tabIndent + $tabIndent)
    Write-Host
    DisplayWarningMessage " DO NOT DOWNLOAD profiles from anywhere else " $tabIndent
    Write-Host
    DisplayNoticeMessage " Remember! When using Automatic Downloads there is always the possibility to get flagged as bot temporarily " $tabIndent
    Write-Host

    Write-Host
    DisplayInfoMessage " You can disable automatic downloads at any time "
    Write-Host
    DisplayInfoText ">> run .\GAMMA_EXT.ps1 -disable automatic-dl" $tabIndent

    DisplayProcessStep " Confirm Automatic Downloads "

    $Prompt = "Do you want to enable Automatic Downloads?"
    $Choices = [System.Management.Automation.Host.ChoiceDescription[]] @("&Yes", "&No")
    $Default = 1
    Write-Host
    # Prompt for the choice
    $Choice = $host.UI.PromptForChoice($Title, $Prompt, $Choices, $Default)
     
    # Action based on the choice
    switch($Choice)
    {
        0 { 
            ## continue
        }
        1 { 
            Write-Host
            DisplayNoticeMessage " You have not enabled Automatic Downloads "
            Write-Host
            exit
        }
    }
}
function PrintCompletionMessage {
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $profileName
    )

    DisplayBanner $Global:InstallCompletionBanner

    DisplaySuccessMessage " Congratulations! "

    if (Test-Path -Path "settings/$profileName/appdata"){
        $patchesAppdata = Get-ChildItem -Path "settings/$profileName/appdata"
    }

    if (Test-Path -Path "settings/$profileName/bin"){
        $patchesBin = Get-ChildItem -Path "settings/$profileName/bin"
    }

    Write-Host
    DisplayInfoText "Here some general tips on what you can do with the new installed profile  "
    DisplayInfoText "Some profiles have special post installation steps, that will displayed below if available. Pay attentions to them!  "
    Write-Host
    DisplaySuccessMessage " - Launch ModOrganizer and select the new profile "
    DisplayInfoText "       The profile is now installed in G.A.M.M.A. and ready to play "
    Write-Host
    DisplaySuccessMessage " - Apply or Switch Profile Settings "
    DisplayInfoText "       When this profile is selected in ModOrganizer, make sure to run the `"Apply Profile Settings`" desktop shortcut to apply the profile settings"
    DisplayInfoText "       You can switch to different profiles' settings whenever you change a profile in ModOrganizer by running `"Apply Profile Settings`" as above"
    DisplayInfoText "       Alternativelty you can run the `"Switch Profile Settings`" desktop shortcut to switch settings independently from the selected profile. You will then be prompted to choose from a list of profiles' settings"
    Write-Host
    DisplaySuccessMessage " - Save the Profile Settings "
    DisplayInfoText "       If you make any changes to the profile setting while in the game, e.g console commands (remember you need to use cfg_save to save them to the user.ltx before closing the game), or modifying reshade presets"
    DisplayInfoText "       When you exit the game run the `"Save Profile Settings`" desktop shortcut to save the settings to the profile settings to make them persist"
    DisplayInfoText "       Whenever you switch back to this profile settings the changes you made will be there"
    Write-Host
    DisplaySuccessMessage " - When to synch the GAMMA EXT Profile "
    DisplayInfoText "       When you udpdate G.A.M.M.A using Grok's Installer, use the `"GAMMA-EXT Synch Profile`" shortcut in Mod Organizer to update this custom profile with the new G.A.M.M.A updates"
    DisplayInfoText "       When you make unsaved changes to the profile (change mods' load order), run synch to rollback the last saved profile mods' load order if you need to"
    Write-Host
    DisplaySuccessMessage " - When to save the GAMMA EXT Profile "
    DisplayInfoText "       If you add new mods to this profile in ModOrganizer or change the mods load order, use the `"GAMMA-EXT Save Profile`" shortcut in Mod Organizer to add the new mods to this custom profile"
    DisplayInfoText "       Failing to do so you will loose all the changes when running synch on this profile"
    DisplayInfoText "       `"GAMMA-EXT Save Profile`" allows you to add new installed mods to the GAMMA-EXT profile"
    Write-Host
    DisplaySuccessMessage " - When to export the GAMMA EXT Profile "
    DisplayInfoText "       If you modified this profile, use the `"GAMMA-EXT Export Profile`" to add/update the profile to the GAMMA-EXT folder"
    DisplayInfoText "       this will allow you to reinstall this profile as is, whenever you want"
    Write-Host
    DisplaySuccessMessage " - Uninstall to save space "
    DisplayInfoText "       If you don't plan to play with this profile anymore just uninstall it"
    DisplayInfoText "       you can always reinstall it when you want with GAMMA-EXT"
    Write-Host
    DisplaySuccessMessage " - Mods documentation "
    DisplayInfoText "       All mods installed by this profile are linked with online documentation (ModDb, Discord, etc)"
    DisplayInfoText "       To visit a mod documentation page, right click the mod in Mod Organizer and in context menu select the `"visit`" option "
    Write-Host

    if (($patchesAppdata.Exists) -or ($patchesBin.Exists)){
        Write-Host
        DisplayNoticeMessage " This profile contains custom game settings (Reshade presets and appdata files e.g user.ltx or any .ltx files) "
        DisplayInfoText "       Make sure you read the tips above or the **GAMMA-EXT Profile Maintenance Guide** included in GAMMA-EXT"
        Write-Host
    }
    
    DisplayNoticePause " Installation is completed. Please take the time to read the notes above on how to use EXT profiles effectively "

}
function DisplayBanner{

    param (
        [Parameter(Mandatory = $true, Position = 0)]
        $bannerPath
    )

    $banner = Get-Content -Path $bannerPath -Raw

    Write-Host -ForegroundColor DarkGreen -BackgroundColor Black  $banner
    Write-Host
}

function DisplayProfileInfo {
    param (
        [Parameter(Mandatory = $true, Position = 0)]
        $info
    )
    
    if (($Null -eq $info) -or ($info -eq "")){
        return
    }

    if ($info.Count -eq 1){
        Write-Host "   "$info
    }else{
        foreach($line in $info){
            Write-Host "   "$line.line
        }
    }


}

function DisplayInstallCompletionMessage {
    param (
        $profileDefinitions, $highlightMessage
    )
    
    if($Null -ne $profileDefinitions.installCompletionMessage){
        if ($highlightMessage){
            # it's being called by the install command
            Write-Host
            Write-Host
            Write-Host
            DisplayNoticePause " !! This Profile has POST INSTALL INSTRUCTIONS they are important in order to play the game - PLEASE TAKE THE TIME TO READ THEM !! "
            $profileName = $profileDefinitions.profileName
            Write-Host
            DisplayInfoText " to see these instructions again, run .\GAMMA_EXT.ps1 -info `"$profileName`""
            Write-Host
        }
        if ($profileDefinitions.installCompletionMessage -isnot [Array]){
            if ($highlightMessage){
                DisplayNoticeMessage $profileDefinitions.installCompletionMessage
            }else{
                DisplayNoticeText $profileDefinitions.installCompletionMessage
            }
        }else{
            foreach($line in $profileDefinitions.installCompletionMessage){
                if ($highlightMessage){
                    DisplayNoticeMessage $line.line
                }else{
                    DisplayNoticeText $line.line
                }
            }
        }
    Write-Host
    }
}

function DisplaySyncCompletionMessage{
    Write-Host 
    DisplayWarningMessage "!! PAY ATTENTION !!"    
    Write-Host
    DisplayNegativeText " If you have run this synch after a G.A.M.M.A Update. You must run again `"Apply Profile Settings`" to reapply the currently MO2 selected profile game settings" $tabIndent   
    Write-Host
    DisplayNegativeText " The GAMMA update will always reset the Anomaly folder with the GAMMA default settings and reshade" $tabIndent
    Write-Host
    DisplayWarningMessage "Please do so before launching the game with this profile again"
    Write-Host
    DisplayNoticeMessage " REFRESH ModOrganizer modlist TO SEE THE CHANGES if you run this synch with MO2 open"
}

function DisplayResetCompletionMessage {
    Write-Host 
    DisplayWarningMessage "!! PAY ATTENTION !!"    
    Write-Host
    DisplayNoticeMessage " REFRESH ModOrganizer modlist TWICE to update the modslist window "
    
}

function DisplayModName {
    param (
        $modName,
        $indentation
    )
    Write-Host
    if ($null -ne $indentation){
        Write-Host $indentation -NoNewline
    }    
    Write-Host " $modName " -BackgroundColor Gray -ForegroundColor Black
}
function DisplayParentInstalledModName {
    param (
        $modName,
        $indentation
    )
    Write-Host
    if ($null -ne $indentation){
        Write-Host $indentation -NoNewline
    }        
    Write-Host " $modName " -BackgroundColor Gray -ForegroundColor Black -NoNewline
    Write-Host " already installed " -ForegroundColor DarkCyan
}

function DisplayParentSkippedModName {
    param (
        $modName,
        $indentation
    )
    Write-Host
    if ($null -ne $indentation){
        Write-Host $indentation -NoNewline
    }        
    Write-Host " $modName " -BackgroundColor Gray -ForegroundColor Black -NoNewline
    Write-Host " parent mod not required " -ForegroundColor DarkCyan
}

function DisplayParentModNameKept {
    param (
        $modName,
        $parentName,
        $indentation
    )
    Write-Host
    if ($null -ne $indentation){
        Write-Host $indentation -NoNewline
    }        
    Write-Host " $modName " -BackgroundColor Gray -ForegroundColor Black -NoNewline
    Write-Host " not deleting because this profile's parent ""$parentName"" is installed " -ForegroundColor DarkGreen
}
# function DisplayWarningMissingMod {
#     param (
#         $modName,
#         $indentation
#     )
#     Write-Host
#     if ($null -ne $indentation){
#         Write-Host $indentation -NoNewline
#     }    
#     Write-Host " $modName " -ForegroundColor Yellow -BackgroundColor DarkRed -NoNewline
#     DisplayNegativeText " already exists " -ForegroundColor Red
#     Write-Host 
# }

# function DisplayWarningMissingAddon {
#     param (
#         $modName,
#         $indentation
#     )
#     Write-Host
#     if ($null -ne $indentation){
#         Write-Host $indentation -NoNewline
#     }    
#     Write-Host -NoNewline -ForegroundColor Yellow -BackgroundColor Red $addon.addonName
#     Write-Host -ForegroundColor Red " is not available, download the addon file and save it in the addons folder"
#     Write-Host Addon Info $addon.addonUrl 
#     Write-Host -ForegroundColor Yellow click link to download --> $addon.fileUrl
#     Write-Host
# }

function DisplayAvailableAddon {
    param (
        $modName,
        $indentation
    )
    Write-Host
    if ($null -ne $indentation){
        Write-Host $indentation -NoNewline
    }    
    Write-Host  $addon.addonName -BackgroundColor Gray -ForegroundColor Black -NoNewline
    DisplayPositiveText " is available"
}
function DisplayDownloadedAddon {
    param (
        $modName,
        $indentation
    )
    Write-Host
    if ($null -ne $indentation){
        Write-Host $indentation -NoNewline
    }    
    Write-Host  $addon.addonName -BackgroundColor Gray -ForegroundColor Black -NoNewline
    DisplayPositiveText " Sucessfully downloaded and available"
}
function DisplayModSummary {
    param (
        $mod
    )
    Write-Host
    Write-Host "    " -NoNewline
    Write-Host " $($mod.modName) " -BackgroundColor Gray -ForegroundColor Black
    Write-Host "      $($mod.info) "  -ForegroundColor DarkCyan
}

function DisplayAddonName {
    param (
        $addonName,
        $indentation
    )
    if ($null -ne $indentation){
        Write-Host $indentation -NoNewline
    }
    Write-Host " $addonName " -BackgroundColor Gray -ForegroundColor Black
    Write-Host
}

function DisplayAddonSize {
    param (
        $addonName,
        $addonSizeMB,
        $indentation
    )
    if ($null -ne $indentation){
        Write-Host $indentation -NoNewline
    }
    Write-Host " $addonName " -BackgroundColor Gray -ForegroundColor Black -NoNewline
    Write-Host " $addonSizeMB MB " -ForegroundColor DarkCyan
    Write-Host
}

function DisplayProcessStep {
    param (
        $step,
        $indentation
    )
    if ($null -ne $indentation){
        Write-Host $indentation -NoNewline
    }
    Write-Host " $step " -BackgroundColor DarkMagenta -ForegroundColor Yellow
    # Write-Host " $step " -BackgroundColor Cyan -ForegroundColor Black
}

function DisplayProcessSubStep {
    param (
        $step,
        $indentation
    )
    if ($null -ne $indentation){
        Write-Host $indentation -NoNewline
    }
    # Write-Host " $step " -BackgroundColor Magenta -ForegroundColor White
    Write-Host " $step " -BackgroundColor Cyan -ForegroundColor Black
}

function DisplayGamedataPath {
    param (
        $step,
        $path,
        $indentation
    )
    if ($null -ne $indentation){
        Write-Host $indentation -NoNewline
    }
    # Write-Host " $step " -BackgroundColor Magenta -ForegroundColor White
    Write-Host " $step " -BackgroundColor Cyan -ForegroundColor Black -NoNewline
    Write-Host " $path " -BackgroundColor Black -ForegroundColor Cyan
}

function DisplayProcessStepText {
    param (
        $message,
        $indentation
    )
    if ($null -ne $indentation){
        Write-Host $indentation -NoNewline
    }
    Write-Host "$message "  -ForegroundColor DarkMagenta
    
}
function DisplayWarningMessage{
    param (
        $message,
        $indentation
    )
    if ($null -ne $indentation){
        Write-Host $indentation -NoNewline
    }
    Write-Host " $message " -ForegroundColor Yellow -BackgroundColor DarkRed 
}

function DisplayInfoMessage{
    param (
        $message,
        $indentation
    )
    if ($null -ne $indentation){
        Write-Host $indentation -NoNewline
    }
    Write-Host " $message " -ForegroundColor Black -BackgroundColor DarkGreen 
}

function DisplayErrorMessage{
    param (
        $message,
        $indentation
    )
    if ($null -ne $indentation){
        Write-Host $indentation -NoNewline
    }
    Write-Host " $message " -ForegroundColor Yellow -BackgroundColor DarkRed
    Write-Host
}

function DisplayNoticeMessage{
    param (
        $message,
        $indentation
    )
    if ($null -ne $indentation){
        Write-Host $indentation -NoNewline
    }    
    Write-Host " $message " -ForegroundColor DarkRed -BackgroundColor Yellow
}

function DisplayNoticeMessage2{
    param (
        $message
    )
    Write-Host " $message " -ForegroundColor Red -BackgroundColor Yellow
}

function DisplayNoticeText{
    param (
        $message,
        $indentation
    )
    if ($null -ne $indentation){
        Write-Host $indentation -NoNewline
    }
    Write-Host "$message "  -ForegroundColor Yellow
}

function DisplayInfoText{
    param (
        $message,
        $indentation
    )
    if ($null -ne $indentation){
        Write-Host $indentation -NoNewline
    }
    Write-Host "$message "  -ForegroundColor DarkCyan
}
function DisplayPositiveText{
    param (
        $message,
        $indentation
    )
    if ($null -ne $indentation){
        Write-Host $indentation -NoNewline
    }
    Write-Host "$message "  -ForegroundColor DarkGreen
}

function DisplayNegativeText{
    param (
        $message,
        $indentation
    )
    if ($null -ne $indentation){
        Write-Host $indentation -NoNewline
    }
    Write-Host "$message "  -ForegroundColor Red
}

function DisplayEligibleCommands{
    param (
        $profileName
    )

    $moProfile = "$Global:pathToMOProfiles/$profileName"

    $profileInstalled = Test-Path -Path $moProfile

    Write-Host
    Write-Host "    print info >> "  -ForegroundColor DarkGreen -NoNewline
    Write-Host ".\GAMMA_EXT.ps1 -info `"$profileName`"" -ForegroundColor DarkGray        
    Write-Host "    to install >> "  -ForegroundColor DarkBlue -NoNewline
    Write-Host ".\GAMMA_EXT.ps1 -install `"$profileName`"" -ForegroundColor DarkGray
    Write-Host "    to verify >> " -ForegroundColor Yellow -NoNewline  
    Write-Host ".\GAMMA_EXT.ps1 -verify `"$profileName`"" -ForegroundColor DarkGray
    if ($profileInstalled -eq $true){
        Write-Host "    to uninstall >> " -ForegroundColor Red -NoNewline
        Write-Host ".\GAMMA_EXT.ps1 -uninstall `"$profileName`"" -ForegroundColor DarkGray
    }
    Write-Host
        
}

function DisplayVerification {
    param (
        $verification
    )

    DisplayNoticeMessage " Verification Summary "
    $logs = $verification.failureLogs | Where-Object {$_.type -eq "parentdep"}
    if($logs){
        Write-Host
        DisplayWarningMessage " Parent Dependency Requirement" $tabIndent
        foreach($message in $log.message){
            DisplayNoticeText $message ($tabIndent + $tabIndent)
        }
    }
    $logs = $verification.failureLogs | Where-Object {$_.type -eq "diskspace"}
    if($logs){
        Write-Host
        DisplayWarningMessage " Disksize Requirement" $tabIndent
        foreach($message in $log.message){
            DisplayNoticeText $message ($tabIndent + $tabIndent)
        }
    }
    $logs = $verification.failureLogs | Where-Object {$_.type -eq "autodl"}
    if($logs){
        Write-Host
        DisplayWarningMessage " Automatic Downloads Error " $tabIndent
        Write-Host
        foreach($log in $logs){
            DisplayNoticeMessage $log.target ($tabIndent + $tabIndent)
            Write-Host
            DisplayNegativeText "Error: $($log.error)" ($tabIndent + $tabIndent + $tabIndent)
            foreach($message in $log.message){
                DisplayNoticeText $message ($tabIndent + $tabIndent + $tabIndent)
            }
            Write-Host
        }
        Write-Host
        DisplayNoticeMessage "There were some problems in the automatic download for these addons " $tabIndent            
        Write-Host
        DisplayInfoText "Try the install again or manually download the addons' files from the links above and save them in the ``addons`` folder" $tabIndent
        Write-Host
        DisplayInfoText "There is also the possibility that one of the addons link might have expired or changed" $tabIndent
        Write-Host            
        DisplayInfoText "Please visit to the addon page and look for the new addon link" $tabIndent
        Write-Host 
        DisplayInfoText "Update the addon link using updatedefinitions command " ($tabIndent  + $tabIndent)
        Write-Host 
        DisplayPositiveText ">> .\GAMMA_EXT.ps1 -updatedefinitions -addon `"$($addon.addonName)`"" ($tabIndent  + $tabIndent)
        Write-Host
        DisplayInfoText "Run install again afterwards" $tabIndent
    }
    $logs = $verification.failureLogs | Where-Object {$_.type -eq "manualdlchoice"}
    if($logs){
        Write-Host
        DisplayWarningMessage " Manual Downloads Preference " $tabIndent
        Write-Host
        foreach($log in $logs){
            DisplayNoticeMessage $log.target ($tabIndent + $tabIndent)
            Write-Host
            foreach($message in $log.message){
                DisplayNoticeText $message ($tabIndent + $tabIndent + $tabIndent)
                Write-Host
            }                
        }
        DisplayNoticeMessage "You have chosen to manually download the addons in this section " $tabIndent
        Write-Host
        DisplayInfoText "Click links above to download the addons' files and save them in the ``addons`` folder" $tabIndent
        Write-Host
        DisplayInfoText "Run install again afterwards" $tabIndent
    }
    $logs = $verification.failureLogs | Where-Object {$_.type -eq "wronghash"}
    if($logs){
        Write-Host
        DisplayWarningMessage " Some addons files did not download correctly and have different hash then expected " $tabIndent
        Write-Host
        foreach($log in $logs){
            DisplayNoticeMessage $log.target ($tabIndent + $tabIndent)
            Write-Host
            foreach($message in $log.message){
                DisplayNoticeText $message ($tabIndent + $tabIndent + $tabIndent)
                Write-Host
            }                
        }
        Write-Host
        DisplayNoticeMessage "There were some problems in the automatic download for these addons " $tabIndent            
        Write-Host
        DisplayInfoText "Try the install again or manually download the addons' files from the links above and save them in the ``addons`` folder" $tabIndent
        Write-Host  
        DisplayInfoText "You can check the addons folder for file with 0 KB and manually delete them or simply run the install again and such files will be identified and redownloaded automatically" $tabIndent
        Write-Host
        DisplayInfoText "Run install again afterwards" $tabIndent
    }                   
    $logs = $verification.failureLogs | Where-Object {$_.type -eq "manualdl"}
    if($logs){
        Write-Host
        DisplayWarningMessage " Manual Downloads Required " $tabIndent
        Write-Host
        foreach($log in $logs){
            DisplayNoticeMessage $log.target ($tabIndent + $tabIndent)
            Write-Host
            foreach($message in $log.message){
                DisplayNoticeText $message ($tabIndent + $tabIndent + $tabIndent)
                Write-Host
            }                
        }
        DisplayNoticeMessage "You are required to manually download all the addons in this section " $tabIndent
        Write-Host
        DisplayInfoText "Click links above to download the addons' files and save them in the ``addons`` folder" $tabIndent
        Write-Host
        DisplayInfoText "Run install again afterwards" $tabIndent
        Write-Host
        if($Global:autodl -eq $false){
            DisplayInfoMessage " You have Automatic Downloads disabled " $tabIndent
            Write-Host
            DisplayInfoText "With Automatic Downloads enabled addons can be downloaded automatically instead of manually" ($tabIndent + $tabIndent) 
            Write-Host
            DisplayInfoText "to enable this feature" ($tabIndent + $tabIndent)       
            Write-Host
            DisplayPositiveText ">> run .\GAMMA_EXT.ps1 -enable automatic-dl" ($tabIndent + $tabIndent)                          
        }
    }
    $logs = $verification.failureLogs | Where-Object {$_.type -eq "verificationdl"}
    if($logs){
        Write-Host
        DisplayWarningMessage " Addon Link Verification Failure " $tabIndent
        Write-Host
        foreach($log in $logs){
            DisplayNoticeMessage "AddonName: $($log.target)" ($tabIndent + $tabIndent)
            Write-Host
            foreach($message in $log.message){
                DisplayNoticeText $message ($tabIndent + $tabIndent + $tabIndent)
                Write-Host
            }                
        }
        DisplayNoticeMessage "The download links for the addons in this section could not verified" $tabIndent
        Write-Host
        DisplayInfoText "A possible reason could be" $tabIndent
        Write-Host 
        DisplayInfoText "- The website/cloud service where the addon is hosted is down or not available at this moment" ($tabIndent + $tabIndent)
        DisplayInfoText "- The addon dowload link stored in this profile is expired, not valid anymore" ($tabIndent + $tabIndent)
        DisplayInfoText "- The addon dowload link has changed or moved to a different hosting" ($tabIndent + $tabIndent)
        DisplayInfoText "- The addon is not available anymore" ($tabIndent + $tabIndent)
        Write-Host            
        DisplayInfoText "Please visit to the addon page and look for the new addon link" $tabIndent
        Write-Host 
        DisplayInfoText "Update the addon link using updatedefinitions command " $tabIndent
        Write-Host 
        DisplayPositiveText ">> .\GAMMA_EXT.ps1 -updatedefinitions -addon `"AddonName`"" $tabIndent
        Write-Host
        DisplayInfoText "Run install again afterwards" $tabIndent
    }  
    $logs = $verification.failureLogs | Where-Object {$_.type -eq "addondefinitions"}
    if($logs){
        #print logs
        Write-Host
        DisplayWarningMessage " Addon Definitions Error " $tabIndent
        Write-Host
        # sort logs by target
        $logs = $logs | Sort-Object -Property target
        $currentTarget = $null
        foreach($log in $logs){
            if ($null -eq $currentTarget -or ($currentTarget -ne $log.target)){
                $currentTarget = $log.target
                DisplayNoticeMessage "Version $($log.target)" ($tabIndent + $tabIndent)
            }
            foreach($message in $log.message){
                DisplayNoticeText $message ($tabIndent + $tabIndent + $tabIndent)
            }
            Write-Host           
        }
        DisplayNoticeMessage "There were some problems in the addon definitions for these addons " $tabIndent
        Write-Host
    }  
    $logs = $verification.failureLogs | Where-Object {$_.type -eq "moddefinitions"}
    if($logs){
        #print logs
        Write-Host
        DisplayWarningMessage " Mod Definitions Error " $tabIndent
        Write-Host
        # sort logs by target
        $logs = $logs | Sort-Object -Property target
        $currentTarget = $null
        foreach($log in $logs){
            if ($null -eq $currentTarget -or ($currentTarget -ne $log.target)){
                $currentTarget = $log.target
                DisplayNoticeMessage "Version $($log.target)" ($tabIndent + $tabIndent)
            }
            foreach($message in $log.message){
                DisplayNoticeText $message ($tabIndent + $tabIndent + $tabIndent)
            }
            Write-Host           
        }
        DisplayNoticeMessage "There were some problems in the mod definitions for these mods " $tabIndent
        Write-Host
    }                                         
    $verification = $null
}

function DisplayCommand {
    param (
        $title,
        $command,
        $color
    )

    if ($color -eq "Red"){
        Write-Host "$title >> " -NoNewline -ForegroundColor Red
    }else{
        Write-Host "$title >> " -NoNewline -ForegroundColor DarkGreen
    }
    Write-Host $command -ForegroundColor DarkGray 
}

function DisplayProfileSummary{
    param (
        $profileDefinitions
    )
    $profileName = $profileDefinitions.profileName
    $version = $profileDefinitions.version
    $profileCreator = $profileDefinitions.profileCreator
    $url = $profileDefinitions.url

    DisplayHeadingMessage " $profileName "   
    DisplayHeadingMessage " version $version " $tabIndent
    DisplayHeadingMessage " shared by $profileCreator " $tabIndent
    DisplayHeadingMessage " profile page $url " $tabIndent
    Write-Host

    if (!$short.IsPresent){

        if($profileDefinitions.info){
            DisplayProfileInfo $profileDefinitions.info
        }
        Write-Host
        $kits = GetSharedProfileKitsDefinitions($profileDefinitions.profileName)
        if ($kits){
            DisplayInfoMessage " This profile installs kits " $tabIndent
            DisplayInfoText "A kit is a variation of the main profile modlist, it is installed in MO alongside the main profile" ($tabIndent +$tabIndent)
            Write-Host
            foreach($kit in $kits.kits){
                DisplayPositiveText $kit.profileName ($tabIndent +$tabIndent)
            }
        }
        if($profileDefinitions.installationDiskspaceRequirementMB -or $profileDefinitions.finalDiskspaceRequirementMB){
            Write-Host
            Write-Host "$($tabIndent)Free disk space install requirements:" $profileDefinitions.installationDiskspaceRequirementMB "MB" -ForegroundColor DarkMagenta
            Write-Host "$($tabIndent)Disk space requirements after installation:" $profileDefinitions.finalDiskspaceRequirementMB "MB" -ForegroundColor DarkMagenta
        }
    }
}

function DisplayProfileSummaryShort{
    param (
        $profileDefinitions
    )
    $profileName = $profileDefinitions.profileName
    $version = $profileDefinitions.version
    $profileCreator = $profileDefinitions.profileCreator

    DisplayHeadingMessage " $profileName "   
    DisplayHeadingMessage " version $version " $tabIndent
    DisplayHeadingMessage " shared by $profileCreator " $tabIndent
    Write-Host
}

function DisplayShareableProfiles {
    Write-Host
    $shared = Get-ChildItem -Path $Global:pathToEXTShared -Exclude "G.A.M.M.A._EXT_-_Update.zip", ".gitignore", "GAMMA_EXT_Install.zip", "GAMMA_EXT.zip"

    foreach($file in $shared){

        CreateSharedProfileWorkspace $file.PSChildName
        $profileName = GetSharedProfileName $file.PSChildName
        $profileDefinitions = GetSharedProfileDefinitions $profileName

        if ($null -eq $profileDefinitions){
            PromptErrorBeforeExit " Could not find profile definitions "
        }

        DisplayAddonName $file.PSChildName
        DisplayInfoText "Adds profile:"
        Write-Host
        DisplayProfileSummary $profileDefinitions
        Write-Host
        DisplayCommand "    to add this profile " ".\GAMMA_EXT.ps1 -add `"$($file.PSChildName)`""  
        Write-Host

        ClearWorkspaces $file.PSChildName

        $path = "$Global:pathToEXTProfiles/$profileName"

        if (Test-Path $path){
            DisplayNoticeMessage " This file contains a profile which is already in GAMMA-EXT " $tabIndent
            Write-Host
        }
    }
    
}

function DisplaySuccessMessage{
    param (
        $message,
        $indentation
    )
    if ($null -ne $indentation){
        Write-Host $indentation -NoNewline
    }
    Write-Host -ForegroundColor White -BackgroundColor DarkBlue $message
}
function DisplayHeadingMessage{
    param (
        $message,
        $indentation
    )
    if ($null -ne $indentation){
        Write-Host $indentation -NoNewline
    }
    Write-Host -ForegroundColor White -BackgroundColor DarkBlue $message
}

function DisplayElementMissingMessage{
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $element,
        [Parameter(Mandatory = $true, Position = 1)]
        $message,
        [Parameter(Mandatory = $false, Position = 3)]
        $level,
        [Parameter(Mandatory = $false, Position = 4)]
        $indentation
        
    )
    if ($null -ne $indentation){
        Write-Host $indentation -NoNewline
    }
    if ($level -eq "WARNING"){
        Write-Host "$element" -BackgroundColor Red -ForegroundColor Yellow -NoNewline
        Write-Host "$message "  -ForegroundColor Red
    }elseif ($level -eq "NOTICE"){
        Write-Host "$element" -BackgroundColor Yellow -ForegroundColor Red -NoNewline
        Write-Host "$message "  -ForegroundColor DarkYellow
    }else{
        Write-Host "$element" -ForegroundColor Red -BackgroundColor Yellow -NoNewline
        Write-Host "$message "  -ForegroundColor DarkYellow
    }
}

function DisplayProfileMods{
    param (
        $profileName,
        $indentation
    )
    if ($null -ne $indentation){
        Write-Host $indentation -NoNewline
    }

    if ($profileName -eq ""){
        PromptErrorBeforeExit "cannot list a custom profile mods unless a profilename is specified - e.g. -listmods -profilename testprofile"
    }

    $profileDefinitions = GetProfileDefinitions $profileName

    if ($null -eq $profileDefinitions){
        PromptErrorBeforeExit "Could not find profile definitions "
    }

    foreach ($mod in $profileDefinitions.customMods){

        DisplayModName $mod.modName $indentation
    }
}

function PromptMessageBeforeExit{
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $message
    )
    Write-Host
    DisplaySuccessMessage $message
    Write-Host 'Press any key to end...';
    Write-Host
    $null = $Host.UI.RawUI.ReadKey('NoEcho,IncludeKeyDown');
    exit
}

function PromptMessageBeforeExitNoPause{
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $message
    )
    Write-Host
    DisplaySuccessMessage $message
    Write-Host
    exit
}

function PromptErrorBeforeExit{
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $message
    )
    Write-Host
    DisplayWarningMessage $message
    Write-Host
    if (!$dev.IsPresent){
        ClearWorkspaces
    }
    Write-Host 'Press any key to end...';
    $null = $Host.UI.RawUI.ReadKey('NoEcho,IncludeKeyDown');
    Write-Host
    exit
}
function PromptErrorBeforeExitNoPause{
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $message
    )
    Write-Host
    DisplayWarningMessage $message
    Write-Host
    if (!$dev.IsPresent){
        ClearWorkspaces
    }
    Write-Host
    exit
}
function DisplayWarningPause{
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $message
    )

    DisplayWarningMessage "                                                        "
    DisplayWarningMessage $message
    DisplayWarningMessage "                                                        "

    Write-Host 'Press any key to continue...';
    Write-Host
    $null = $Host.UI.RawUI.ReadKey('NoEcho,IncludeKeyDown');     
}

function DisplayNoticePause{
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $message
    )

    $measureObject = $message | Measure-Object -Character;
    $line = ""
    for ($i = 0; $i -lt $measureObject.Characters; $i++) {
        $line = $line + " "
    }


    DisplayNoticeMessage $line
    DisplayNoticeMessage $message
    DisplayNoticeMessage $line

    Write-Host 'Press any key to continue...';
    Write-Host
    $null = $Host.UI.RawUI.ReadKey('NoEcho,IncludeKeyDown');     
}

function DisplayModOrderRule {
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $rule,
        [Parameter(Mandatory = $true, Position = 1)]
        $modName,
        [Parameter(Mandatory = $false, Position = 2)]
        $beforeModName,
        [Parameter(Mandatory = $false, Position = 3)]
        $indentation
    )

    if ($Global:optionsList -contains "verbose"){
        $indentation = $tabIndent
        if ($null -ne $indentation){
            Write-Host $indentation -NoNewline
        }
        
        if ($rule -eq "add-disabled"){
            Write-Host "adding disabled " -ForegroundColor DarkYellow -NoNewline
            Write-Host " $modName " -BackgroundColor Gray -ForegroundColor Black -NoNewline
            Write-Host " before " -ForegroundColor DarkYellow -NoNewline 
            Write-Host " $beforeModName " -BackgroundColor Gray -ForegroundColor Black
        }elseif ($rule -eq "add"){
            Write-Host "adding " -ForegroundColor DarkGreen -NoNewline 
            Write-Host " $modName " -BackgroundColor Gray -ForegroundColor Black -NoNewline
            Write-Host " before " -ForegroundColor DarkGreen -NoNewline 
            Write-Host " $beforeModName " -BackgroundColor Gray -ForegroundColor Black
        }
        elseif($rule -eq "enable"){
            Write-Host "enabling " -ForegroundColor DarkGreen -NoNewline 
            Write-Host " $modName " -BackgroundColor Gray -ForegroundColor Black
            if ($beforeModName){
                Write-Host " before " -ForegroundColor DarkGreen -NoNewline 
                Write-Host " $beforeModName " -BackgroundColor Gray -ForegroundColor Black
            }
        }else {
            Write-Host "disabling " -ForegroundColor DarkRed -NoNewline 
            Write-Host " $modName " -BackgroundColor Gray -ForegroundColor Black
        }
        Write-Host
    }
}

function DisplayVerbose {
    param (
        $exclude,
        $indentation
    )
    $indentation = $tabIndent
    if ($null -ne $indentation){
        Write-Host $indentation -NoNewline
    }

    $verboseCopy = Get-Content -LiteralPath $Global:pathToEXTWorkspace\verbose.txt

    if ($verboseCopy){
        foreach ($currentItemName in $verboseCopy) {

            if ($exclude -eq ""){
                DisplayNoticeText $currentItemName $tabIndent 
            }elseif(!$currentItemName.Contains($exclude)){

                DisplayNoticeText $currentItemName $tabIndent 
            }
        }

        Remove-Item -LiteralPath $Global:pathToEXTWorkspace\verbose.txt
    }
}
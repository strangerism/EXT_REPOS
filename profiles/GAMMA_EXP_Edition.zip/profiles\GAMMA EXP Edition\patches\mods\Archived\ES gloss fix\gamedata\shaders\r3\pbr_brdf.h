//=================================================================================================
//Pseudo PBR shading for STALKER Anomaly 
//Roughness is controlled with r2_gloss_min
//=================================================================================================
#include "pbr_settings.h" //load settings files
#define PI 3.14159265359
//=================================================================================================
//Metalness
//

float3 debug_spec( float3 specular)
{
	float3 debug;
	float specMin = min(specular.r, min(specular.g, specular.b));
	float specMax = max(specular.r, max(specular.g, specular.b));
	float3 colLow = float3(1,0,0);
	float3 colMid = float3(0,1,0);
	float3 colHigh = float3(0,0,1);
	float3 colMetal = float3(1,1,1);
	float MinLow = 0.02;
	float MinMid = 0.04;
	float MinHigh = 0.08;
	float MinMetal = 0.25;
	
	float lerpLow =	smoothstep(MinLow, MinMid, specMin);
	float LerpHigh = smoothstep(MinMid, MinHigh, specMax);
	float LerpMetal = smoothstep(MinHigh, MinMetal, specMax);
	
	debug = lerp(colLow, colMid, lerpLow);
	debug = lerp(colMid, colHigh, LerpHigh);
	debug = lerp(colHigh, colMetal, LerpMetal);
	
	debug = lerp(lerp(lerp(colLow, colMid, lerpLow), colHigh, LerpHigh), colMetal, LerpMetal);
	
	return debug;
}
float calc_metalness(float4 alb_gloss, float material_ID)
{
	float glossMin = METALNESS_THRESHOLD - METALNESS_SOFTNESS;
	float glossMax = METALNESS_THRESHOLD + METALNESS_SOFTNESS;
	
	float metal_min = round(material_ID * 0.8);
	metal_min *= smoothstep(glossMin, glossMax, alb_gloss.a);
	
	material_ID = saturate(material_ID * 0.4);
	alb_gloss.a = pow(alb_gloss.a, 0.35);
	
	float material_weight = material_ID*2-1; //-1.0 - +1.0 range
	float gloss_weight = alb_gloss.a*2-1; //-1.0 - +1.0 range
	
	float specular_boost = material_weight + gloss_weight;
	specular_boost *= 4;
	specular_boost = exp2(SPECULAR_RANGE * specular_boost);
	specular_boost = 1.0;
	
	return saturate(metal_min * specular_boost);
}
float3 Overlay(float3 base, float3 blend)
{
	return (base <= 0.5) ? 2*base*blend : 1 - 2*(1-base)*(1-blend);
}
float3 Soft_Light(float3 base, float3 blend)
{
	return (blend <= 0.5) ? base - (1-2*blend)*base*(1-base) : base + (2*blend-1)*(sqrt(base)-base);
}
float3 Screen(float3 base, float3 blend)
{
	return (base + blend) - (base * blend);
}
float3 RGBtoHCV(float3 RGB)
{
	// Based on work by Sam Hocevar and Emil Persson
	float4 P = (RGB.g < RGB.b) ? float4(RGB.bg, -1.0, 2.0/3.0) : float4(RGB.gb, 0.0, -1.0/3.0);
	float4 Q = (RGB.r < P.x) ? float4(P.xyw, RGB.r) : float4(RGB.r, P.yzx);
	float C = Q.x - min(Q.w, Q.y);
	float H = abs((Q.w - Q.y) / (6 * C + 0.001) + Q.z);
	return float3(H, C, Q.x);
}
float3 RGBtoHSV(float3 RGB)
{
	float3 HCV = RGBtoHCV(RGB);
	float S = HCV.y / (HCV.z + 0.001);
	return float3(HCV.x, S, HCV.z);
}
float3 HUEtoRGB(in float H)
{
	float R = abs(H * 6 - 3) - 1;
	float G = 2 - abs(H * 6 - 2);
	float B = 2 - abs(H * 6 - 4);
	return saturate(float3(R,G,B));
}
float3 HSVtoRGB(float3 HSV)
{
	float3 RGB = HUEtoRGB(HSV.x);
	return ((RGB - 1) * HSV.y + 1) * HSV.z;
}

//=================================================================================================
//Material
//
#define BOOSTTYPE 2
float3 calc_albedo_boost(float3 albedo)
{
#if BOOSTTYPE == 1
	//boost based on photoshop layers
	albedo = pow(albedo, 0.4545);
	float3 blend = lerp(0.5, 1 - dot(albedo, LUMINANCE_VECTOR), ALBEDO_BOOST); //boost albedo by inv
	//albedo = Soft_Light(albedo, blend);
	albedo = Overlay(albedo, blend);
	albedo = pow(albedo, 2.2);
#endif
	
#if BOOSTTYPE == 2
	//boost in HSV space
	float3 HSV = RGBtoHSV(albedo);

	//boost saturation
	float Saturation_Boost = 0.25;
	HSV.y = pow(HSV.y, 1-Saturation_Boost);
	
	//reverse tonemap curve
	//float Contrast_Boost = 0.7;
	float Contrast_Boost = lerp(1.0, 0.35, ALBEDO_BOOST);
	HSV.z = pow(HSV.z, Contrast_Boost) * 0.18/pow(0.18,Contrast_Boost);
	
	albedo = HSVtoRGB(HSV);
#endif

	return albedo;
}

//=================================================================================================
//Rain and Foliage
//
void calc_rain(inout float3 albedo, inout float3 specular, inout float rough, in float4 alb_gloss, in float material_ID, in float rainmask)
{
	//rain based on Remember Me's implementation
	//float wetness = saturate(rain_params.x*rainmask);
	float wetness = saturate(smoothstep(0.01,0.75,rain_params.x*rainmask));

	float porosity = 1-saturate(material_ID*1.425); //metal material at 0, concrete at 1
	//porosity = saturate((porosity-0.5)/0.4); //Remember Me rain porosity

	float factor = lerp(1,0.2, porosity); //albedo darkening factor
	
	albedo *= lerp(1, factor, wetness); 
	rough = lerp(0.001, rough, lerp(1, factor, wetness)); 
	specular = lerp(specular, 0.02, wetness);
}

void calc_foliage(inout float3 albedo, inout float3 specular, inout float rough, in float4 alb_gloss, in float mat_id)
{
	float foliage = (abs(mat_id-MAT_FLORA) <= MAT_FLORA_ELIPSON) ? 1 : 0;
	
	//specular = foliage ? calc_specular(alb_gloss, 0.0) : specular;
	specular = foliage ? alb_gloss.g * 0.04 : specular;
	//specular = foliage ? pow(alb_gloss.g * 0.1414, 2) : specular;
}
//=================================================================================================
//Calc Material
//
void calc_material(in float4 alb_gloss, in float material_ID, out float rough, out float3 albedo, out float3 specular)
{
	float metalness = calc_metalness(alb_gloss, material_ID);
	
	//gamma correct
	float3 albedo_lin = SRGBToLinear(alb_gloss.rgb);
	float3 albedo_boosted_lin = calc_albedo_boost(albedo_lin);
	
	//albedo
	float3 albedo_base = albedo_boosted_lin;
	float3 albedo_metal = albedo_lin * (1 - albedo_lin);
	
	//specular
	float3 specular_base = float3(SPECULAR_BASE, SPECULAR_BASE, SPECULAR_BASE);// * calc_material_boost(alb_gloss, material_ID);
	float3 specular_metal = albedo_lin;
	
	//specular material weight
	specular_base *= exp2(-1*(material_ID*2-1));
	
	//reverse blinn brdf to get specular power
	float gloss = pow(alb_gloss.a, 2.2);
	gloss = max(0.0, (8.0*gloss/specular_base));
	
	/*
	//BLOPS gloss
	float gloss = alb_gloss.a;
	gloss = pow(8192, gloss);
	*/
	
	//convert specular power to UE4 roughness
	float roughpow = 0.5 / max(0.001, 1 - Ldynamic_color.w);
	rough = pow(2.0/(gloss+2.0),0.25);
	rough = pow(rough, roughpow);
	rough = pow(rough, 1 + (metalness * METAL_BOOST)); //metal boost
	rough = max(0.001, rough);
	
	//apply metalness
	albedo = lerp(albedo_base, albedo_metal, metalness)*ALBEDO_AMOUNT;
	specular = lerp(specular_base, specular_metal, metalness);
	
	//saturate
	albedo = saturate(albedo);
	specular = saturate(specular);
	rough = saturate(rough);
	
	//foliage
	calc_foliage(albedo, specular, rough, alb_gloss, material_ID);
	
	//ensure energy conservation
	//albedo = albedo - (albedo * specular);
	//specular = specular - (albedo * specular);
	
	//debug
	//albedo = 0.0;
	//specular = 1.0;
	//rough = max(0.001, 1-Ldynamic_color.w);
}
//=================================================================================================
//Functions
//

float F_Shlick(float f0, float f90, float vDotH)
{
	return lerp(f0, f90, pow(1-vDotH, 5));
}

float3 F_Shlick(float3 f0, float3 f90, float vDotH)
{
	return lerp(f0, f90, pow(1-vDotH, 5));
}
// We have a better approximation of the off specular peak
// but due to the other approximations we found this one performs better .
// N is the normal direction
// R is the mirror vector
// This approximation works fine for G smith correlated and uncorrelated
float3 getSpecularDominantDir(float3 N, float3 R, float roughness)
{
	float smoothness = saturate(1 - roughness);
	float lerpFactor = smoothness * (sqrt(smoothness) + roughness);
	// The result is not normalized as we fetch in a cubemap
	return lerp(N, R, lerpFactor);
}

//=================================================================================================
//Shading
//

//include BRDFs
#include "pbr_brdf_blinn.h" //brdf
#include "pbr_brdf_ggx.h" //brdf

float Lit_Burley(float nDotL, float nDotV, float vDotH, float rough)
{
	//rough *= rough;
	/*
	//DICE version
	float edgeBright = 0.5;
	float energyBias = lerp (0.0 , edgeBright, rough );
	float energyFactor = lerp (1.0 , 1.0 / (1.0 + edgeBright), rough );
	float fd90 = energyBias + 2.0 * vDotH * vDotH * rough ;
	float f0 = 1.0;
	float lightScatter = F_Shlick(f0, fd90, nDotL);
	float viewScatter = F_Shlick(f0, fd90, nDotV);
 	return (lightScatter * viewScatter * energyFactor);
	*/
	//Disney version (with black edges for smooth)
	float fd90 = rough * 0.5 + (2.0 * vDotH * vDotH * rough) ;
	float f0 = 1.0;
	float lightScatter = F_Shlick(f0, fd90, nDotL);
	float viewScatter = F_Shlick(f0, fd90, nDotV);
 	return (lightScatter * viewScatter);
}

float Lambert_Source(float nDotL,float rough)
{
	float exponent = lerp(1.4, 0.6, rough);
	return (pow(nDotL, exponent) * ((exponent + 1.0) * 0.5)) / max(1e-5, nDotL);
}

float Lit_Diffuse(float nDotL, float nDotV, float vDotH, float rough)
{
#ifdef USE_BURLEY_DIFFUSE
	return Lit_Burley(nDotL, nDotV, vDotH, rough);
#else
	return Lambert_Source(nDotL, rough);
#endif
}

float3 Lit_Specular(float nDotL, float nDotH, float nDotV, float vDotH, float3 f0, float rough)
{
#ifdef USE_GGX_SPECULAR
	return Lit_GGX(nDotL, nDotH, nDotV, vDotH, f0, rough); //GGX is much more expensive but looks nicer
#else
	return Lit_Blinn(nDotL, nDotH, nDotV, vDotH, f0, rough); //much cheaper pbr blinn 
#endif
}

float3 Lit_BRDF(float rough, float3 albedo, float3 f0, float3 V, float3 N, float3 L )
{
	float3 H = normalize(V + L );
	
	float nDotL = saturate(dot(N, L));
	float nDotH = saturate(dot(N, H));
	//float nDotV = saturate(dot(N, V));
	float nDotV = 1e-5 + abs(dot(N, V)); //DICE
	//float nDotV = max(1e-5, dot(N, V));
	float vDotH = saturate(dot(V, H));
	
	float3 diffuse_term = Lit_Diffuse(nDotL, nDotV, vDotH, rough).rrr;
	diffuse_term *= albedo;
	
	float3 specular_term = Lit_Specular(nDotL, nDotH, nDotV, vDotH, f0, rough);
	
	// horizon occlusion with falloff
	float horizon = 1.5;
	horizon = saturate(horizon* dot(N, V) + 1.0);
	horizon *= horizon;

	specular_term *= horizon; //horizon atten
	
	return (diffuse_term + specular_term) *  nDotL;
}

//=================================================================================================
//Ambient
//

float EnvBurley(float roughness, float NV)
{
    //Burley (Hill's curve)
    float d0 = 0.97619 - 0.488095 * pow(1.0 - NV, 5.0);
    float d1 = 1.55754 + (-2.02221 + (2.56283 - 1.06244 * NV) * NV) * NV;
    return lerp(d0, d1, roughness);
}

float Amb_Diffuse(float3 f0, float rough, float nDotV)
{
#ifdef USE_BURLEY_DIFFUSE
    return EnvBurley(rough, nDotV);
#else
	return 1.0; 
#endif
}

float3 Amb_Specular(float3 f0, float rough, float nDotV)
{
#ifdef USE_GGX_SPECULAR
    return EnvGGX(f0, rough, nDotV);
#else
    return EnvBlops2(f0, rough, nDotV);
#endif
}

float3 Amb_BRDF(float rough, float3 albedo, float3 f0, float3 env_d, float3 env_s, float3 V, float3 N)
{
	//float nDotV = saturate(dot(N, V));
	float nDotV = 1e-5 + abs(dot(N, V)); //DICE
	//float nDotV = max(1e-5, dot(N, V));
	
	float3 diffuse_term = Amb_Diffuse(f0, rough, nDotV);
	diffuse_term *= env_d * albedo;
	
	float3 specular_term = Amb_Specular(f0, rough, nDotV);
	specular_term *= env_s;
	
	// horizon occlusion with falloff, should be computed for direct specular too
	float horizon = 1.5;
	horizon = saturate(horizon* dot(N, V) + 1.0);
	horizon *= horizon;

	specular_term *= horizon; //horizon atten
	
	return diffuse_term + specular_term;
}
function promptContinue{
    $Prompt = "Do you want to continue or exit the installation? (C to continue, E to exit)"
    $Choices = [System.Management.Automation.Host.ChoiceDescription[]] @("&Continue", "&Exit")
    $Default = 1
    Write-Host
    # Prompt for the choice
    $Choice = $host.UI.PromptForChoice($Title, $Prompt, $Choices, $Default)
    
    # Action based on the choice
    switch($Choice)
    {
        0 { 
            # continue to install
        }
        1 { 
            Write-Host "Exiting the installation..."
            if (!$dev.IsPresent){
                ClearWorkspaces
            }
            exit
        }
    } 
    Write-Host
}

function UnpackXr{
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $files,
        [Parameter(Mandatory = $true, Position = 1)]
        $outputdir
    )

    # DisplayProcessStep " Unpacking Anomaly xdb files "

    New-Item -ItemType Directory -Force -Path $outputdir | Out-Null

    $unpacker = (Get-Item -Path $Global:unpackerPath).FullName.Replace(" ", "`` "); 
    foreach ($file in $files){
        
        $command = $unpacker + " -unpack -xdb `"$file`" -dir `"$outputdir`""
        $command += ';$?'
        $Success = Invoke-Expression $command
        if ($Success -eq $false) {
            DisplayErrorMessage "Error unpacking xdb file $file"
            DisplayNegativeText "Error message: $_"
            DisplayErrorMessage " Please check the archive integrity in addons and try install again"
            promptContinue
        }
    }
}

function UnpackSingleXr{
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $filePath,
        [Parameter(Mandatory = $true, Position = 1)]
        $outputdir
    )

    New-Item -ItemType Directory -Force -Path $outputdir | Out-Null
    $unpacker = (Get-Item -Path $Global:unpackerPath).FullName.Replace(" ", "`` "); 
    $command = $unpacker + " -unpack -xdb `"$filePath`" -dir `"$outputdir`""
    $command += ';$?'
    $Success = Invoke-Expression $command
    if ($Success -eq $false) {
        DisplayErrorMessage "Error unpacking xdb file $file"
        DisplayNegativeText "Error message: $_"
        DisplayErrorMessage " Please check the archive integrity in addons and try install again"
        promptContinue
    }
}
function PackXr{
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $gamedataDir
    )

    # converter method
    # $unpacker = (Get-Item -Path $Global:unpackerPath).FullName.Replace(" ", "`` "); 
    # $command = $unpacker + " -pack -xdb `"$gamedataDir`" -out `"$outputFile`""

    # xcompress method
    $packer = (Get-Item -Path $Global:xrCompress).FullName.Replace(" ", "`` ")
    $command = $packer + " `"$gamedataDir`" -ltx xrCompress.ltx -pack -1024 -db"    
    $command += ';$?'
    $Success = Invoke-Expression $command
    if ($Success -eq $false) {
        DisplayErrorMessage "Error creating xR archive $resourcePath"
        DisplayNegativeText "Error message: $_"
        promptContinue
    }
    Write-Host    

}
function Unpack7z{
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $resourcePath,
        [Parameter(Mandatory = $true, Position = 1)]
        $outputPath
    )
    Write-Host
    DisplayInfoText "Unpack archive $resourcePath" $($tabIndent + $tabIndent) 

    $command = ". `"$Global:7zPath`" x `"$resourcePath`" -o`"$outputPath`""
    $command += ';$?'
    $Success = Invoke-Expression $command
    if ($Success[$Success.Length - 1] -eq $false) {
        DisplayErrorMessage "Error unpacking 7z archive $resourcePath"
        DisplayNegativeText "Error message: $Success"
        DisplayErrorMessage " Please check the archive integrity in addons and try install again"
        promptContinue
    }
}

function Create7z{
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $resourcePath,
        [Parameter(Mandatory = $true, Position = 1)]
        $outputPath
    )
    
    # 7z a archive1.zip subdir\
    $command = ". `"$Global:7zPath`" a `"$outputPath`" `"$resourcePath`""
    $command += ';$?'
    $Success = Invoke-Expression $command
    if ($Success -eq $false) {
        DisplayErrorMessage "Error creating 7z archive $resourcePath"
        DisplayNegativeText "Error message: $_"
        promptContinue
    }
    Write-Host   

}

function CreateArchive{
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $resourcePath,
        [Parameter(Mandatory = $true, Position = 1)]
        $outputPath
    )
    
    if ($outputPath.EndsWith(".rar")){
        $zipOutput = $outputPath.Replace(".rar", ".zip")

        $compress = @{
            Path = $resourcePath
            CompressionLevel = "Optimal"
            DestinationPath = $zipOutput
        }        
        Compress-Archive @compress -Force
        Remove-Item -Path $outputPath -Force -ErrorAction Ignore
        Rename-Item -Path $zipOutput $outputPath -Force
    }else{
        $compress = @{
            Path = $resourcePath
            CompressionLevel = "Optimal"
            DestinationPath = $outputPath
        }        
        Compress-Archive @compress -Force        
    }



}

function CreateEXTWorkspaceFromXr{
    param (
        $resourceWorkspacePath,
        $xrdbName,
        $xrdbWorkspaceName
    )

    $resourceWorkspacePathDir = Get-Item -Path $resourceWorkspacePath

    $xrdbWorkspaceName = GetXrDbWorkspaceName $xrdbName

    $outputdir = "$($resourceWorkspacePathDir.FullName)/$xrdbWorkspaceName/gamedata"

    DisplayInfoText "Unpacking xray db files $resourceWorkspacePath/$xrdbName" ($tabIndent + $tabIndent + $tabIndent)

    $files = Get-ChildItem -Path "$resourceWorkspacePath/$xrdbName" -File
    UnpackXr $files $outputdir
}

function GetXrDbWorkspaceName {
    param (
        $xrdbName
    )
    # return ($xrdbName.substring($xrdbName.LastIndexOf('/') +1)).Replace("*","")
    return $xrdbName.Replace("*","").Replace(".db","")
}

function escapePath{
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $path
    ) 
    
    $escapedPath = $path.Replace("[","````[").Replace("]","````]")
    
    return $escapedPath
}

function CreateSharedProfile {
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $profileDefinitions,
        [Parameter(Mandatory = $true, Position = 1)]
        $profilePath        
    )
    
    $tempProfileFolder = "$Global:pathToEXTWorkspace/tmp/profiles"

    New-Item -Path $tempProfileFolder -ItemType Directory -Force | Out-Null
    Copy-Item -Path $profilePath -Destination $tempProfileFolder -Recurse

    $pathToMetaTemplate = "$Global:pathToEXTTemplates/shared-meta.ini"
    $metainiTemplate = Get-Content -Path $pathToMetaTemplate -Raw
    $metainiTemplate = $metainiTemplate.Replace('%profileName%',$profileDefinitions.profileName)
    $metaini = "$tempProfileFolder/shared-meta.ini"
    Set-Content -Path $metaini -Value $metainiTemplate

    $compress = @{
        Path = $tempProfileFolder
        CompressionLevel = "Fastest"
        DestinationPath = "$Global:pathToEXTShared/$($profileDefinitions.profileName.Replace(" ","_")).zip"
        # DestinationPath = $Global:pathToEXTShared + ($profileDefinitions.profileName).Replace(" ","_") + "_" + $profileDefinitions.version +".zip"
    }
    Compress-Archive @compress -Force

    $tmpFolder =  "$Global:pathToEXTWorkspace/tmp"
    ExitIfPathIsProhibited($tmpFolder)
    Remove-Item -LiteralPath $tmpFolder -Recurse -Force | Out-Null
    
    Write-Host "The shareable profile has been saved in: " -NoNewline
    Write-Host -BackgroundColor DarkGreen -ForegroundColor Black $compress.DestinationPath
}

function ArchiveSettings{
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $settingsProfileName
    )

    $profileSettingsBinFolder = "settings/$settingsProfileName/bin"
    $profileSettingsAppdataFolder = "settings/$settingsProfileName/appdata"

    DisplayModName " $settingsProfileName " $tabIndent

    if (Test-Path -LiteralPath "settings/$settingsProfileName"){

        $tempSettingsFolder = "$Global:pathToEXTWorkspace/tmp/settings/$settingsProfileName"
        New-Item -Path $tempSettingsFolder -ItemType Directory -Force | Out-Null
        New-Item -Path "$tempSettingsFolder/bin" -ItemType Directory -Force | Out-Null
        New-Item -Path "$tempSettingsFolder/appdata" -ItemType Directory -Force | Out-Null

        $escapedPath = [Management.Automation.WildcardPattern]::Escape($profileSettingsBinFolder) + "/*"
        Copy-Item -Path $escapedPath -Destination "$tempSettingsFolder/bin/"
        $escapedPath = [Management.Automation.WildcardPattern]::Escape($profileSettingsAppdataFolder) + "/*"
        Copy-Item -Path $escapedPath -Destination "$tempSettingsFolder/appdata/"

        ExitIfPathIsProhibited "settings/$settingsProfileName"
        Remove-Item -Recurse -Force -LiteralPath "settings/$settingsProfileName" | Out-Null
    }
}
function CompressSettings {
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $settingsProfileName
    )
    
    $tempSettingsFolder = "$Global:pathToEXTWorkspace/tmp/settings"

    if (Test-Path -LiteralPath $tempSettingsFolder){

        # $timestamp = Get-Date -Format "_MM-dd-yyyy-HH-mm"

        $archiveFile = "$pathToEXTBackups/$($settingsProfileName.Replace(" ","_")).zip"

        if (Test-Path -LiteralPath $archiveFile){
            Remove-Item -LiteralPath $archiveFile
        }

        $compress = @{
            Path = $tempSettingsFolder
            CompressionLevel = "Fastest"
            DestinationPath = $archiveFile
        }
        Compress-Archive @compress -Force
    
        $tmpFolder =  "$Global:pathToEXTWorkspace/tmp"
        ExitIfPathIsProhibited($tmpFolder)
        Remove-Item -LiteralPath $tmpFolder -Recurse -Force | Out-Null
    
        Write-Host
        DisplayInfoText "The profile's settings has been saved as backup in " $tabIndent   
        Write-Host
        DisplayInfoMessage $compress.DestinationPath ($tabIndent + $tabIndent)

    }else{
        DisplayInfoText "No profile's settings have been saved in backups " $tabIndent 
    }

}
function CreateAddonsWorkspaces{
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $addons
    )

    DisplayProcessStep " Creating addons workspace "
    Write-Host
    foreach ($addon in $addons){

        CreateAddonWorkspace $addon
    }
}

function ResolveWorkspaceSize() {

    [int]$currentWorkspaceSize = [math]::Round(((Get-ChildItem $Global:pathToEXTWorkspace -Recurse | Measure-Object -Property Length -Sum -ErrorAction Stop).Sum / 1MB),0)

    # DisplayNoticeMessage "Current Workspace size: $currentWorkspaceSize" $tabIndent
    # Write-Host
    if ($currentWorkspaceSize -gt $Global:maxWorkspaceSize) {
        $Global:maxWorkspaceSize = $currentWorkspaceSize
    }
}

function DisplayWorkspaceSize {

    Write-Host
    DisplayPositiveText " >> Workspace created"
    Write-Host
    DisplayNoticeMessage "Max Workspace size: $Global:maxWorkspaceSize"
    Write-Host
}
function CreateModWorkspace {
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $profileDefinitions,
        [Parameter(Mandatory = $true, Position = 1)]
        $customMod        
    )

    # create the mod default addon workspace if not exists
    $addon = $profileDefinitions.addons | Where-Object { $_.addonName -eq $customMod.addonName }

    if ($null -eq $addon){
        PromptErrorBeforeExit "$($customMod.modName) missing addon definitions"
    }

    CreateAddonWorkspace $addon

    if ($customMod.pathToGamedata -is [array]){

        # scan pathToGamedata for elements that override the default addon
        foreach($pathToGamedata in $customMod.pathToGamedata){

            if ($pathToGamedata.addonName){
                # pathToGamedata element requires addon
                $addon = $profileDefinitions.addons | Where-Object { $_.addonName -eq $pathToGamedata.addonName }
                if (!$addon){

                    if(!$dev.IsPresent){
                        ClearWorkspaces
                    }
                    DisplayErrorMessage " a pathToGamedata in the customMod $($customMod.name) refers to a not existing addon name: $($pathToGamedata.addonName)"
                }
                # create the mod default addon workspace if not exists
                CreateAddonWorkspace $addon
            }
        }
    }
}

function ClearModWorkspace {
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $profileDefinitions,
        [Parameter(Mandatory = $true, Position = 1)]
        $customMod        
    )
    
    # read disk space of $pathToExtWorkspace
    ResolveWorkspaceSize
    $referencedAddons = @()

    # find in profiledefinitions.addons the $addon with addonName == $customMod.addonName
    $referencedAddons += $profiledefinitions.addons | Where-Object { $_.addonName -eq $customMod.addonName -and ($null -eq $_.keepWorkspace -or $_.keepWorkspace -eq $false) }

    $pathToGamedataAddonsName = $customMod.pathToGamedata | Where-Object { $null -ne $_.addonName }

    foreach ($pathToGamedataAddonName in $pathToGamedataAddonsName){

        $referencedAddon = $profiledefinitions.addons | Where-Object { $_.addonName -eq $pathToGamedataAddonName.addonName -and ($null -eq $_.keepWorkspace -or $_.keepWorkspace -eq $false) } 

        # add the referenced addon to $referencedAddons if not already present in the list using the addonName
        foreach ($addon in $referencedAddons){
            if ($addon.addonName -eq $referencedAddon.addonName){
                $referencedAddon = $null
                break
            }
        }
        if ($referencedAddon){
            $referencedAddons += $referencedAddon
        }
    }

    foreach ($addon in $referencedAddons) {
        ClearAddonWorkspace $addon
    }
}
function CreateAddonWorkspace{
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $addon
    )

    $resourcePath = "$Global:pathToEXTAddons/$($addon.resourceFilename)"
    $resourceWorkspacePath = "$Global:pathToEXTWorkspace/$($addon.resourceWorkspace)"

    if (Test-Path -Path $resourceWorkspacePath){
        # DisplayNoticeMessage " $($addon.addonName) workspace already present. Skipping creation " $tabIndent                
        return
    }

    DisplayProcessStep " Creating $($addon.addonName) addon workspace " $tabIndent

    Unpack7z $resourcePath $resourceWorkspacePath

    Write-Host
    try {
        [int]$addonWorkspaceSize  = [math]::Round(((Get-ChildItem $resourceWorkspacePath -Recurse | Measure-Object -Property Length -Sum -ErrorAction Stop).Sum / 1MB),0)
    }
    catch {
        # do nothing
        DisplayNoticeMessage " Could not calculate workspace size" $tabIndent
    }

    if ([int]$addonWorkspaceSize -eq 0){
        $addonWorkspaceSize = 1
    }
    DisplayNoticeText " Addon Workspace size: $addonWorkspaceSize MB" $($tabIndent + $tabIndent)
    Write-Host
    if ($Global:optionsList -contains "compilesize"){
        SetAddonSize $addon $addonWorkspaceSize
    }

    Write-Host
    # DisplayPositiveText " >> $($addon.addonName) workspace created " 
}

function UpdateAddonWorkspace{
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $addon
    )

    $resourcePath = "$Global:pathToEXTAddons/$($addon.resourceFilename)"
    $resourceWorkspacePath = "$Global:pathToEXTWorkspace/$($addon.resourceWorkspace)"

    if (Test-Path -Path $resourceWorkspacePath){
        # Write-Host
        # DisplayNoticeMessage " $($addon.addonName) workspace already present. Skipping creation " $tabIndent                
        return
    }

    DisplayProcessStep " Creating $($addon.addonName) addon workspace " $tabIndent

    Unpack7z $resourcePath $resourceWorkspacePath
    
    # Write-Host
    # DisplayPositiveText " >> $($addon.addonName) workspace created " 
}

function CreateGamePatchesWorkspace {
    param (
        [Parameter(Mandatory = $true, Position = 0)]
        $profileDefinitions
    )
    
    if ($profileDefinitions.profileType -eq "clone"){
        $masterCloneDefinitions = GetProfileDefinitions($profileDefinitions.profileBaseName)
        foreach($gamePatch in $profileDefinitions.gamePatches){
            if ($gamePatch.patchType -eq "reshade" -or $gamePatch.patchType -eq "exe" -or $gamePatch.patchType -eq "shaders_cache"){
                $patchSource = "$Global:pathToEXTWorkspace/$($gamePatch.resourceWorkspace)"
                if (!(Test-Path -LiteralPath $patchSource)){
                    $addon = GetAddonDefinitions $masterCloneDefinitions $gamePatch.addonName
                    CreateAddonWorkspace $addon
                }
            }
        }
    }else{
        foreach($gamePatch in $profileDefinitions.gamePatches){
            if ($gamePatch.patchType -eq "reshade" -or $gamePatch.patchType -eq "exe" -or $gamePatch.patchType -eq "shaders_cache"){
                $patchSource = "$Global:pathToEXTWorkspace/$($gamePatch.resourceWorkspace)"
                if (!(Test-Path -LiteralPath $patchSource)){
                    $addon = GetAddonDefinitions $profileDefinitions $gamePatch.addonName
                    CreateAddonWorkspace $addon
                }
            }
        }    
    
        # create kits settings if they have game patches
        $kitsDefinitions = GetProfileKitsDefinitions($profileDefinitions.profileName) 
        if ($kitsDefinitions){
            foreach($kit in $kitsDefinitions.kits){
                if ($kit.gamePatches){
                    DisplayInfoText "Creating Kit $($kit.profileName) Gamepatches workspaces"
                    foreach ($gamePatch in $kit.gamePatches){
                        if ($gamePatch.addonName){
                            $addon = GetAddonDefinitions $profileDefinitions $gamePatch.addonName
                            if ($addon) {
                                CreateAddonWorkspace $addon
                            }
                        }
                    }
                }
            }
        }
    }
}

function ClearAddonWorkspace{
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $addon
    )

    DisplayProcessStep " Deleting $($addon.addonName) addon workspace " $tabIndent

    $workspace = "$Global:pathToEXTWorkspace/$($addon.resourceWorkspace)"
    Remove-Item -Recurse -Force -LiteralPath $workspace | Out-Null
    
    Write-Host
    # DisplayPositiveText " >> $($addon.addonName) workspace cleared" $tabIndent
    # Write-Host
}

function ClearWorkspaces{


    DisplayProcessStep " Deleting workspace "


    $workspacesList = Get-ChildItem -Directory -Path $Global:pathToEXTWorkspace

    foreach($item in $workspacesList){

        $workspace = "$Global:pathToEXTWorkspace/$item"
        Remove-Item -Recurse -Force -LiteralPath $workspace | Out-Null
    }

    Write-Host
    # DisplayPositiveText " >> Workspace cleared "
    # Write-Host
}

function ClearWorkspaceItem{
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $item
    )

    $workspace = "$Global:pathToEXTWorkspace/$item"
    Remove-Item -Recurse -Force -LiteralPath $workspace | Out-Null
    
    Write-Host
}

function CreateSharedProfileWorkspace {
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $sharedProfileFile
    )

    $pathToSharedProfile = "$Global:pathToEXTShared/$sharedProfileFile"
    if (Test-Path -Path $pathToSharedProfile){
        Expand-Archive -Path $pathToSharedProfile -Force -DestinationPath $Global:pathToEXTWorkspace 
    }else{
        Write-Host "Could not find shared profile $sharedProfileFile in ./shared" -ForegroundColor Yellow -BackgroundColor Red
        PromptMessageBeforeExit ""
    }
    
}

function GetDriveLetter {
    param (
        [string]$path
    )

    # Extract the drive letter from the path
    $driveLetter = [System.IO.Path]::GetPathRoot($path).TrimEnd(':\')
    return $driveLetter
}

function PurgeAddons {

    $addonsList = @()
    $addonsToDelete = @()
    $freedSpace = 0


    # loop through all profiles folders in pathToEXTProfiles and load the profile definitions within
    $profiles = Get-ChildItem -Path $Global:pathToEXTProfiles -Directory
    foreach ($profile in $profiles){
        $profileDefinitions = GetProfileDefinitions $profile.Name
        if ($profileDefinitions){
            $addonsList += GetAddonsResourceFileList $profileDefinitions
        }
    }


    $addons = Get-ChildItem -Path $Global:pathToEXTAddons -File
    foreach ($addon in $addons){
        if ($addonsList -notcontains $addon.Name){
            $addonsToDelete += $addon.Name
            $freedSpace += $addon.Length
        }
    }

    # print the list of the addons to delete and the freedspance and prompt the user to delete the addons
    if ($addonsToDelete){
        Write-Host
        DisplayNegativeText "The following addons are not used by any profile and can be deleted:"
        Write-Host
        foreach ($addon in $addonsToDelete){
            # display addon name and size
            $resourcePath = "$Global:pathToEXTAddons/$addon"
            [int]$addonSizeMB = [math]::Round(((Get-Item -LiteralPath $resourcePath).length / 1MB),2)
            DisplayAddonSize $addon $addonSizeMB $tabIndent
        }
        Write-Host
        $freedSpace = [math]::Round($freedSpace / 1MB, 0)
        DisplayNoticeMessage "Total space to be freed: $freedSpace MB"
        Write-Host
        DisplayHeadingMessage " Make your choice "
        $Prompt = "Do you want to delete the addons? (Y to delete, N to exit)"
        $Choices = [System.Management.Automation.Host.ChoiceDescription[]] @("&Yes", "&No")
        $Default = 1
        Write-Host
        # Prompt for the choice
        $Choice = $host.UI.PromptForChoice($Title, $Prompt, $Choices, $Default)
        
        # Action based on the choice
        switch($Choice)
        {
            0 { 
                Write-Host
                Write-Host
                DisplayHeadingMessage " Choose the deletion method "
                # prompt for delete all or confirm each addon
                $Prompt = "Do you want to delete all the addons or confirm each one? (A to delete all, C to confirm each)"
                $Choices = [System.Management.Automation.Host.ChoiceDescription[]] @("&All", "&Confirm")
                $Default = 1
                Write-Host
                # Prompt for the choice
                $Choice = $host.UI.PromptForChoice($Title, $Prompt, $Choices, $Default)

                # Action based on the choice
                switch($Choice)
                {
                    0 { 
                        foreach ($addon in $addonsToDelete){
                            $resourcePath = "$Global:pathToEXTAddons/$addon"
                            Remove-Item -LiteralPath $resourcePath -Force
                            DisplayPositiveText "Deleted $addon"
                        }
                    }
                    1 { 
                        Write-Host
                        Write-Host
                        DisplayHeadingMessage " Listing each addon for deletion "
                        Write-Host
                        foreach ($addon in $addonsToDelete){
                            $resourcePath = "$Global:pathToEXTAddons/$addon"
                            [int]$addonSizeMB = [math]::Round(((Get-Item -LiteralPath $resourcePath).length / 1MB),2)
                            DisplayAddonSize $addon $addonSizeMB $tabIndent
                            $Prompt = "Do you want to delete this file? (Y to delete, N to skip)"
                            $Choices = [System.Management.Automation.Host.ChoiceDescription[]] @("&Yes", "&No")
                            $Default = 1
                            Write-Host
                            # Prompt for the choice
                            $Choice = $host.UI.PromptForChoice($Title, $Prompt, $Choices, $Default)
                            
                            # Action based on the choice
                            switch($Choice)
                            {
                                0 { 
                                    Remove-Item -LiteralPath $resourcePath -Force
                                    DisplayPositiveText "Deleted $addon" $tabIndent
                                }
                                1 { 
                                    DisplayNegativeText "Skipped $addon" $tabIndent
                                }
                            } 
                            Write-Host
                        }
                    }
                }

            }
            1 { 
                Write-Host "Exiting the deletion..."
                exit
            }
        } 
    }else{
        Write-Host
        DisplayPositiveText "No addons to delete"
    }
}
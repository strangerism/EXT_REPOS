function GetMOProfileDefinitions{
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $profileName
    )

    $path = "$Global:pathToMOProfiles/$profileName"

    if ((Test-Path -LiteralPath $path) -eq $False) {
        return $null
    } 

    $path = "$Global:pathToMOProfiles/$profileName/profile_definitions.json"

    if ((Test-Path -LiteralPath $path) -eq $False) {
        return $null
    } 

    return Get-Content -Raw -LiteralPath $path | ConvertFrom-Json
    
}
function GetMOParentProfileDefinitions{
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $profileDefinitions
    )

    if (!$profileDefinitions.parentProfile) {
        return $null
    } 

    $path = "$Global:pathToMOProfiles/$($profileDefinitions.profileName)/parent_profile_definitions.json"

    if ((Test-Path -LiteralPath $path) -eq $False) {
        $path = "$Global:pathToMOProfiles/$($profileDefinitions.profileName)/parent_profile_definitions.json"
        if ((Test-Path -LiteralPath $path) -eq $False) {
            return $null
        }
    }

    return Get-Content -Raw -LiteralPath $path | ConvertFrom-Json
}
function GetMOParentBuildProfileDefinitions{
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $profileDefinitions
    )

    if (!$profileDefinitions.parentProfile) {
        return $null
    } 

    $path = "$Global:pathToMOProfiles/$($profileDefinitions.parentProfile.name)/build_profile_definitions.json"

    if ((Test-Path -LiteralPath $path) -eq $False) {
        $path = "$Global:pathToMOProfiles/$($profileDefinitions.parentProfile.name)/profile_definitions.json"
        if ((Test-Path -LiteralPath $path) -eq $False) {
            return $null
        }
    }

    return Get-Content -Raw -LiteralPath $path | ConvertFrom-Json
}
function isMOParentProfileDefinitions{
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $profileDefinitions
    )

    $path = "$Global:pathToMOProfiles/$($profileDefinitions.parentProfile.name)/build_profile_definitions.json"

    if ((Test-Path -LiteralPath $path) -eq $False) {
        $path = "$Global:pathToMOProfiles/$($profileDefinitions.parentProfile.name)/profile_definitions.json"
        if ((Test-Path -LiteralPath $path) -eq $False) {
            return $False
        }
    }

    return $true
}
function GetMOBuildProfileDefinitions{
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $profileName
    )

    $path = "$Global:pathToMOProfiles/$profileName"

    if ((Test-Path -LiteralPath $path) -eq $False) {
        # DisplayWarningMessage " Cannot find profile $profileName "
        return $null
    } 

    $path = "$Global:pathToMOProfiles/$profileName/build_profile_definitions.json"

    if ((Test-Path -LiteralPath $path) -eq $False) {
        $path = "$Global:pathToMOProfiles/$profileName/profile_definitions.json"
        if ((Test-Path -LiteralPath $path) -eq $False) {
            return $null
        }
    }

    return Get-Content -Raw -LiteralPath $path | ConvertFrom-Json
    
}

function GetChangeLogDefinitions{
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $profileName
    )

    $path = "$Global:pathToEXTProfiles/$profileName"

    if ((Test-Path -LiteralPath $path) -eq $False) {
        return $null
    } 

    $path = "$Global:pathToEXTProfiles/$profileName/changelog_definitions.json"

    if ((Test-Path -LiteralPath $path) -eq $False) {
        return $null
    } 

    return Get-Content -Raw -LiteralPath $path | ConvertFrom-Json
}
function GetProfileDefinitions{
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $profileName
    )

    $path = "$Global:pathToEXTProfiles/$profileName"

    if ((Test-Path -LiteralPath $path) -eq $False) {
        return $null
    } 

    $path = "$Global:pathToEXTProfiles/$profileName/profile_definitions.json"

    if ((Test-Path -LiteralPath $path) -eq $False) {
        return $null
    } 

    return Get-Content -Raw -LiteralPath $path | ConvertFrom-Json
    
}

function GetParentProfileDefinitions {
    param (
        [Parameter(Mandatory = $true, Position = 0)]
        $profileDefinitions
    )

    if ($null -ne $profileDefinitions.parentProfile){
        return GetProfileDefinitions $profileDefinitions.parentProfile.name
    }
    
}

function GetTemplateProfileDefinitions{

    $path = "ext/templates/profiles/profile-template.json"

    return Get-Content -Raw -LiteralPath $path | ConvertFrom-Json
    
}
function GetChangeLogDefinitions {
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $profileName
    )
    
    $path = "$Global:pathToEXTProfiles/$profileName"

    if ((Test-Path -LiteralPath $path) -eq $False) {
        return $null
    } 

    $path = "$Global:pathToEXTProfiles/$profileName/changelog_definitions.json"

    if ((Test-Path -LiteralPath $path) -eq $False) {
        return $null
    } 

    return Get-Content -Raw -LiteralPath $path | ConvertFrom-Json
}
function GetProfileKitsDefinitions{
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $profileName
    )

    $pathToKits = "$Global:pathToEXTProfiles/$profileName/kits/kits_definitions.json"

    if((Test-Path -LiteralPath $pathToKits) -eq $false){
        return $null
    }

    return Get-Content -Raw -LiteralPath $pathToKits | ConvertFrom-Json
    
}
function GetMOProfileKitsDefinitions{
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $profileName
    )

    $pathToKits = "$Global:pathToMOProfiles/$profileName/kits/kits_definitions.json"

    if((Test-Path -LiteralPath $pathToKits) -eq $false){
        return $null
    }

    return Get-Content -Raw -LiteralPath $pathToKits | ConvertFrom-Json
    
}
function GetSharedProfileDefinitions{
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $profileName
    )

    $path = "$Global:pathToEXTWorkspace/profiles/$profileName/profile_definitions.json"

    if ((Test-Path -LiteralPath $path) -eq $False) {
        return $null
    } 

    return Get-Content -Raw -LiteralPath $path | ConvertFrom-Json
    
}

function GetSharedProfileKitsDefinitions{
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $profileName
    )

    $pathToKits = "$Global:pathToEXTWorkspace/profiles/$profileName/kits/kits_definitions.json"

    if((Test-Path -LiteralPath $pathToKits) -eq $false){
        return $null
    }

    return Get-Content -Raw -LiteralPath $pathToKits | ConvertFrom-Json
    
}

function GetActiveMOProfile {

    $MOIni = get-content $Global:pathToMOIni
   
    foreach($line in $MOIni)
    {

        if ($line -clike "selected_profile=*"){

            $value = $line.Split('=',2)

            if ($value[1] -clike "@ByteArray(*"){

                $value = $value[1].Split('(',2)
                return $value[1].Substring(0, $value[1].Length -1)
            }
        }
    }    
}

function ProfileExistsInMO {
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $profileDefinitions
    )

    return GetMOProfileDefinitions $profileDefinitions.profileName
}

function ProfileParentExistsInMO {
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $profileDefinitions
    )

    return GetMOProfileDefinitions $profileDefinitions.parentProfile.name
}

function CheckIfExtVersionCompatible{
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $profileDefinitions
    )

    if ([decimal]$profileDefinitions.extVersion -ne $Global:version){
        Write-Host
        DisplayNoticeMessage " This Profile ext version requirement differs from your installed EXT version "
        Write-Host
        DisplayInfoText " Profile compatible EXT version $($profileDefinitions.extVersion | % { '{0:0.00}' -f $_ }) " $tabIndent
        Write-Host
        DisplayNegativeText " Installed EXT version $($Global:version | % { '{0:0.00}' -f $_ }) " $tabIndent
        Write-Host
        if ([decimal]$profileDefinitions.extVersion -gt $Global:version){
            DisplayNoticeMessage " Please update EXT, run the following command:"
            Write-Host
            DisplayNoticeText ".\ext_tools.ps1 -update" $tabIndent
            PromptErrorBeforeExit " Verification Failed "
        }else{
            DisplayInfoMessage " This EXT version can support this profile " $tabIndent
            Write-Host
            # DisplayNoticeText "Download link --> $($profileDefinitions.url)" $tabIndent
            # PromptErrorBeforeExit " Verification Failed "
        }
    }
}
function CheckIfProfileExistsInMO{
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $profileDefinitions
    )

    $profileMOPath = "$Global:pathToMOProfiles/$($profileDefinitions.profileName)"

    if (Test-Path -LiteralPath $profileMOPath) {

        $installedProfile = GetMOBuildProfileDefinitions $profileDefinitions.profileName

        if (!$installedProfile){
            # profile is not GAMMA-EXT
            DisplayWarningMessage " A non GAMMA-EXT profile with the same name already exists in GAMMA's Mod Organizer "
            Write-Host 
            DisplayNegativeText "Beware that mods in Mod Organizer belonging to other non GAMMA-EXT profiles, that share same name of mods from this profile, can be deleted as consequence" $tabIndent
            PromptErrorBeforeExit " Open Mod Organizer and change its name if you want to install this profile "
        }

        if ([int]$profileDefinitions.version -eq [int]$installedProfile.version){
            # same profile have same versions, just overwrite 
            # RemoveSettings $profileName
            return
        }elseif ([int]$profileDefinitions.version -gt [int]$installedProfile.version){
            # profile is upgrade of installed profile, uninstall
            UninstallForUpdate $installedProfile
        }else{    
            # installed profile is newer
            DisplayWarningMessage " A profile with the same name is already installed in GAMMA's Mod Organizer "
            DisplayWarningMessage " !! The installed profile version is newer $($installedProfile.version) !! "
            Write-Host
            DisplayProfileSummaryShort $installedProfile
            Write-Host
            DisplayWarningMessage " !! You are trying to install an older version. Version  $($profileDefinitions.version) !!"
            Write-Host
            $Title = ""
            $Prompt = "Enter your choice. Yes to install older version. No to abort"
            $Choices = [System.Management.Automation.Host.ChoiceDescription[]] @("&Yes", "&No")
            $Default = 1

            # Prompt for the choice
            $Choice = $host.UI.PromptForChoice($Title, $Prompt, $Choices, $Default)
            switch($Choice)
            {   0{
                    # continue
                    UninstallForUpdate $installedProfile
                }
                1{
                    PromptMessageBeforeExit " Install aborted "
                }
            }         
        }

    }

}
function CreateMOProfile{
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $profileDefinitions
    )
    
    DisplayProcessStep " Create the ModOrganizer custom profile and modlist " -ForegroundColor Yellow -BackgroundColor DarkGreen
    Write-Host

    $moProfilePath = "$Global:pathToMOProfiles/$($profileDefinitions.profileName)"

    if(Test-Path -LiteralPath $moProfilePath){
        ExitIfPathIsProhibited($moProfilePath)
        Remove-Item -Recurse -Force -LiteralPath $moProfilePath | Out-Null
    }

    Copy-Item -LiteralPath "$Global:pathToEXTProfiles/$($profileDefinitions.profileName)" -Destination $moProfilePath -Recurse -Force

    $moProfile = "$moProfilePath/profile_definitions.json"
    $buildProfile = "$moProfilePath/build_profile_definitions.json"

    Copy-Item -LiteralPath $moProfile -Destination $buildProfile

    SynchProfile $profileDefinitions

    $moModlist = "$moProfilePath/modlist.txt"

    $buildModlist = "$moProfilePath/build_modlist.txt"

    Copy-Item -LiteralPath $moModlist -Destination $buildModlist
    # add parent profile definition if not installed
    if ($profileDefinitions.parentProfile -and !(isMOParentProfileDefinitions $profileDefinitions)){
        Write-Host
        DisplayProcessStep "Adding Parent Profile definitions"
        Copy-Item -LiteralPath "$Global:pathToEXTProfiles/$($profileDefinitions.parentProfile.name)/profile_definitions.json" -Destination "$moProfilePath/parent_profile_definitions.json" -Recurse -Force
    }

    # create kits

    $kitsDefinitions = GetProfileKitsDefinitions($profileDefinitions.profileName) 

    if ($kitsDefinitions){
        foreach($kit in $kitsDefinitions.kits){

            # lets build the kit MO profile and build profile 

            # inherit the kit definition from the parent to build
            $kitMOProfileDefinitions = $profileDefinitions.PsObject.Copy()
            
            # change name and type
            $kitMOProfileDefinitions.profileName = $kit.profileName
            $kitMOProfileDefinitions | Add-Member -MemberType NoteProperty -Name "profileBaseName" -Value $profileDefinitions.profileName
            $kitMOProfileDefinitions | Add-Member -MemberType NoteProperty -Name "profileBaseVersion" -Value $profileDefinitions.version
            $kitMOProfileDefinitions.profileType = "kit"

            # add the parent
            # if ($null -eq $kitMOProfileDefinitions.parentProfile){
            #     $kitMOProfileDefinitions | Add-Member -MemberType NoteProperty -Name "parentProfile" -Value ""
            # }
            # $kitMOProfileDefinitions.parentProfile = [PSCustomObject]@{
            #     name = $profileDefinitions.profileName
            #     version = $profileDefinitions.version
            # }

            # add the kit customLoadOrderRules
            $kitMOProfileDefinitions.customLoadOrderRules += $kit.customLoadOrderRules


            # add the kit gamepatches where they exists
            if ($kit.gamePatches){
                $kitMOProfileDefinitions.gamePatches = $kit.gamePatches
            }else{
                $kitMOProfileDefinitions.gamePatches = $profileDefinitions.gamePatches
            }

            $moProfilePath = "$Global:pathToMOProfiles/$($kitMOProfileDefinitions.profileName)"

            if(Test-Path -LiteralPath $moProfilePath){
                ExitIfPathIsProhibited($moProfilePath)
                Remove-Item -Recurse -Force -LiteralPath $moProfilePath | Out-Null
            }
            New-Item -Path $Global:pathToMOProfiles -Name $kitMOProfileDefinitions.profileName -ItemType "directory" | Out-Null

            $kitMOProfile = "$moProfilePath/profile_definitions.json"

            Set-Content -LiteralPath $kitMOProfile -Value ($kitMOProfileDefinitions | ConvertTo-Json -Depth 5)

            $kitMOBuildProfile = "$moProfilePath/build_profile_definitions.json"

            Copy-Item -LiteralPath $kitMOProfile -Destination $kitMOBuildProfile

            SynchProfile $kitMOProfileDefinitions

            $moModlist = "$moProfilePath/modlist.txt"

            $buildModlist = "$moProfilePath/build_modlist.txt"
        
            Copy-Item -LiteralPath $moModlist -Destination $buildModlist

            # add parent profile definition if not installed
            if ($profileDefinitions.parentProfile -and !(isMOParentProfileDefinitions $profileDefinitions)){
                DisplayProcessSubStep "Adding Parent Profile definitions to kit"
                Copy-Item -LiteralPath "$Global:pathToEXTProfiles/$($profileDefinitions.parentProfile.name)/profile_definitions.json" -Destination "$moProfilePath/parent_profile_definitions.json" -Recurse -Force
            }

        }
    }

    Write-Host
    DisplayPositiveText " >> ModOrganizer custom profile created"
}

function isModInExludeList{
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $modName,
        [Parameter(Mandatory = $true, Position = 1)]
        $excludeMods
    )
    
    $found = $false

    $excludeMods | ForEach-Object{
        if ($_.modName -eq $modName){
            $found = $true
        }
    }
    return $found    
}

function isModInInstalledParent {
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $modName,
        [Parameter(Mandatory = $true, Position = 1)]
        $profileDefinitions
    )

    $found = $false 

    if (($null -eq $profileDefinitions.parentProfile) -or ("" -eq $profileDefinitions.parentProfile)){
        # this profile does not have a parent
        return $false 
    }

    if ((Test-Path -LiteralPath "$Global:pathToMOProfiles/$($profileDefinitions.parentProfile.name)") -eq $false){
        # this profile parent is not installed
        return $false 
    }

    $parentDefinitions = GetMOBuildProfileDefinitions $profileDefinitions.parentProfile.name

    if ($null -eq $parentDefinitions){
        return $false
    }

    # if (($null -eq $parentDefinitions.parentProfile) -or ("" -eq $parentDefinitions.parentProfile)){
    #     # the parent does not have a parent itself - irrelevant?
    #     return $found
    # }

    if ($profileDefinitions.parentProfile.version -eq $parentDefinitions.version){
        # the versions matches 
        $parentDefinitions.customMods | ForEach-Object{
            if ($_.modName -eq $modName){
                $found = $true
            }
        }
    }

    return $found

}

function isModInParent {
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $modName,
        [Parameter(Mandatory = $true, Position = 1)]
        $profileDefinitions
    )

    $found = $false 

    if (($null -eq $profileDefinitions.parentProfile) -or ("" -eq $profileDefinitions.parentProfile)){
        # this profile does not have a parent
        return $false 
    }

    $parentDefinitions = GetProfileDefinitions $profileDefinitions.parentProfile.name

    if ($profileDefinitions.parentProfile.version -eq $parentDefinitions.version){
        # the versions matches 
        $parentDefinitions.customMods | ForEach-Object{
            if ($_.modName -eq $modName){
                $found = $true
            }
        }
    }

    return $found

}

function isModInstalled {
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $modName
    )
    
    if(Test-Path -LiteralPath "$Global:pathToMOMods/$modName" -PathType Container){
        return $true
    }else{
        return $false
    }

}

function RemoveMOProfile {
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $profileDefinitions
    )

    # uninstalling kits
    $kitsDefinitions = GetMOProfileKitsDefinitions($profileDefinitions.profileName) 

    if ($kitsDefinitions){
        
        DisplayProcessStep " Deleting ModOrganizer profile kits "

        foreach($kit in $kitsDefinitions.kits){

            $moProfilePath = "$Global:pathToMOProfiles/$($kit.profileName)"
            if(Test-Path -LiteralPath $moProfilePath){
                Write-Host
                DisplayModName " $($kit.profileName) " $tabIndent
                ExitIfPathIsProhibited($moProfilePath)
                Remove-Item -Recurse -Force -LiteralPath $moProfilePath | Out-Null
            }
        }
    } 

    DisplayProcessStep " Deleting ModOrganizer profile "

    DisplayModName " $($profileDefinitions.profileName) " $tabIndent

    $profilePath = "$Global:pathToMOProfiles/$($profileDefinitions.profileName)"

    # remove base profile
    ExitIfPathIsProhibited($profilePath)
    Remove-Item -Recurse -Force -LiteralPath $profilePath | Out-Null
   
}

function CheckIfAnyDependentProfileIsInstalled {
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $profileDefinitions
    )
    
    $installedMOProfiles = Get-ChildItem -Path $Global:pathToMOProfiles -Directory
    
    $existsDependency = $false

    foreach ($installedProfile in $installedMOProfiles) {

        $installedProfileDefinitions = GetMOProfileDefinitions $installedProfile.BaseName
        # TODO remove check if not kit backward compat
        if ($installedProfileDefinitions.parentProfile -and ($installedProfileDefinitions.profileType -ne "kit" -and $installedProfileDefinitions.profileType -ne "clone")){
            if ($installedProfileDefinitions.parentProfile.name -eq $profileDefinitions.profileName){
                DisplayNoticeMessage " The installed profile [$($installedProfileDefinitions.profileName)] depends on the parent profile [$($profileDefinitions.profileName)] you are trying to uninstall "
                $existsDependency = $true
            }
        }
    }

    return $existsDependency
}

function GenerateCloneOriginLabel{
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $profileName
    )

    $cloneFromDefinitions = GetMOProfileDefinitions $profileName

    $clonedFrom = [PSCustomObject]@{
        profileName = $cloneFromDefinitions.profileName
        profileType = $cloneFromDefinitions.profileType
        version = $cloneFromDefinitions.version
    }
    return $clonedFrom
}

function GenerateGAMMAOriginLabel{

    $clonedFrom = [PSCustomObject]@{
        profileName = "G.A.M.M.A"
        profileType = "modpack"
        version = $null
    }
    return $clonedFrom
}

function CloneProfileDefinitions {
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $ancestorProfileName,        
        [Parameter(Mandatory = $true, Position = 1)]
        $clonedProfileName
    )
    # clonedFrom
    $ancestorProfilePath = "$Global:pathToMOProfiles/$ancestorProfileName"
    # clone
    $clonedProfilePath = "$Global:pathToMOProfiles/$clonedProfileName"

    if ($ancestorProfileName -eq "G.A.M.M.A"){


        # copy gamma profile definitions
        New-Item -Path $clonedProfilePath -ItemType Directory | Out-Null
        # Copy-Item -LiteralPath "$ancestorProfilePath/modlist.txt" -Destination "$clonedProfilePath/modlist.txt"
        Copy-Item -LiteralPath "$ancestorProfilePath/modlist.txt" -Destination "$clonedProfilePath/build_modlist.txt"

        # load template definitions
        $templateProfileDefinitions = GetTemplateProfileDefinitions
        
        # update profile definitions
        $templateProfileDefinitions.profileName = $clonedProfileName      
        $templateProfileDefinitions.version = 1  
        $templateProfileDefinitions.profileType = "clone"
        $clonedFrom = GenerateGAMMAOriginLabel
        $templateProfileDefinitions | Add-Member -MemberType NoteProperty -Name "clonedFrom" -Value $clonedFrom
        $templateProfileDefinitions | Add-Member -MemberType NoteProperty -Name "linkedTo" -Value $clonedFrom
        Set-Content -LiteralPath "$clonedProfilePath/build_profile_definitions.json" -Value ($templateProfileDefinitions | ConvertTo-Json -Depth 5)
        Set-Content -LiteralPath "$clonedProfilePath/profile_definitions.json" -Value ($templateProfileDefinitions | ConvertTo-Json -Depth 5)
        $clonedProfileDefinitions = $templateProfileDefinitions
    }else{

        # copy profile definitions
        New-Item -Path $clonedProfilePath -ItemType Directory | Out-Null
        Copy-Item -LiteralPath "$ancestorProfilePath/profile_definitions.json" -Destination "$clonedProfilePath/profile_definitions.json"
        # update profile build definitions
        $clonedProfileBuildDefinitions = GetMOBuildProfileDefinitions $clonedProfileName
        if ($clonedProfileBuildDefinitions){
            if ($clonedProfileBuildDefinitions.profileType -eq "standalone"){
                $clonedProfileBuildDefinitions | Add-Member -MemberType NoteProperty -Name "profileBaseName" -Value $clonedProfileBuildDefinitions.profileName
                $clonedProfileBuildDefinitions | Add-Member -MemberType NoteProperty -Name "profileBaseVersion" -Value $clonedProfileBuildDefinitions.version
            }            
            $clonedProfileBuildDefinitions.profileName = $clonedProfileName
            $clonedProfileBuildDefinitions.version = 1
            $clonedProfileBuildDefinitions.profileType = "clone"
            $clonedFrom = GenerateCloneOriginLabel $ancestorProfileName
            $clonedProfileBuildDefinitions | Add-Member -MemberType NoteProperty -Name "clonedFrom" -Value $clonedFrom
            $clonedProfileBuildDefinitions | Add-Member -MemberType NoteProperty -Name "linkedTo" -Value $clonedFrom
            $clonedProfileBuildDefinitions.customMods =  @()
            # find ancestor profile separator rule
            $separatorRule = $clonedProfileBuildDefinitions.customLoadOrderRules | Where-Object {$_.action -eq "add-profile-separator"}
            $clonedProfileBuildDefinitions.customLoadOrderRules = @()
            if($separatorRule){
                $clonedProfileBuildDefinitions.customLoadOrderRules += $separatorRule
            }
            Set-Content -LiteralPath "$clonedProfilePath/build_profile_definitions.json" -Value ($clonedProfileBuildDefinitions | ConvertTo-Json -Depth 5)
            Set-Content -LiteralPath "$clonedProfilePath/profile_definitions.json" -Value ($clonedProfileBuildDefinitions | ConvertTo-Json -Depth 5)
        }

        # update profile definitions
        $clonedProfileDefinitions = GetMOProfileDefinitions $clonedProfileName
        SynchProfile $clonedProfileDefinitions
    }  
}

function UpdateCloneDefinitions {
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $profileDefinitions,
        [Parameter(Mandatory = $true, Position = 1)]
        $ancestorProfileDefinitions        
    )
    
    $customLoadOrderRules = $profileDefinitions.customLoadOrderRules
    $customMods = $profileDefinitions.customMods
    $ancestorProfileName = $ancestorProfileDefinitions.profileName
    $updatedProfileDefinitions = $ancestorProfileDefinitions

    if ($updatedProfileDefinitions.profileType -eq "standalone"){
        $updatedProfileDefinitions | Add-Member -MemberType NoteProperty -Name "profileBaseName" -Value $updatedProfileDefinitions.profileName
        $updatedProfileDefinitions | Add-Member -MemberType NoteProperty -Name "profileBaseVersion" -Value $updatedProfileDefinitions.version
    }   

    $updatedProfileDefinitions.profileName = $profileDefinitions.profileName
    $updatedProfileDefinitions.version = $profileDefinitions.version
    $updatedProfileDefinitions.profileType = "clone"
    $linkedTo = GenerateCloneOriginLabel $ancestorProfileName
    $updatedProfileDefinitions | Add-Member -MemberType NoteProperty -Name "clonedFrom" -Value $profileDefinitions.clonedFrom
    $updatedProfileDefinitions | Add-Member -MemberType NoteProperty -Name "linkedTo" -Value $linkedTo

    $updatedProfileDefinitions.customLoadOrderRules = $customLoadOrderRules
    $updatedProfileDefinitions.customMods = $customMods

    Set-Content -LiteralPath "$Global:pathToMOProfiles/$($updatedProfileDefinitions.profileName)/build_profile_definitions.json" -Value ($updatedProfileDefinitions | ConvertTo-Json -Depth 5)
    Set-Content -LiteralPath "$Global:pathToMOProfiles/$($updatedProfileDefinitions.profileName)/profile_definitions.json" -Value ($updatedProfileDefinitions | ConvertTo-Json -Depth 5)

    $profileBuildDefinitions = GetMOBuildProfileDefinitions $profileDefinitions.profileName
    return $profileBuildDefinitions 
}  

function SetModSize{
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $modName,
        [Parameter(Mandatory = $true, Position = 1)]
        $installedSizeMB
    )
    Write-Host
    DisplayPositiveText " SetModSize Mod: $modName Size: $installedSizeMB MB " $($tabIndent + $tabIndent)

    if ([int]$installedSizeMB -eq 0){
        $installedSizeMB = 1
    }

    foreach ($i in 0..($Global:compiledProfileDefinitions.customMods.Count - 1)) {
        if ($Global:compiledProfileDefinitions.customMods[$i].modName -eq $modName) {
            if (!($Global:compiledProfileDefinitions.customMods[$i].PSObject.Properties.Name -contains 'installedSizeMB')) {
                $Global:compiledProfileDefinitions.customMods[$i] | Add-Member -NotePropertyName 'installedSizeMB' -NotePropertyValue $installedSizeMB
            } else {
                $Global:compiledProfileDefinitions.customMods[$i].installedSizeMB = $installedSizeMB
            }
        }
    }
}

function SetAddonSize{
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $addon,
        [Parameter(Mandatory = $true, Position = 1)]
        $workspaceSize        
    )
    $resourcePath = "$Global:pathToEXTAddons/$($addon.resourceFilename)"

    [int]$addonSizeMB = [math]::Round(((Get-Item -LiteralPath $resourcePath).length / 1MB),0)
    if ([int]$addonSizeMB -eq 0){
        $addonSizeMB = 1
    }

    DisplayPositiveText " SetAddonSize Addon: $($addon.addonName) Size: $addonSizeMB MB - Workspace: $workspaceSize MB " $($tabIndent + $tabIndent)

    foreach ($i in 0..($Global:compiledProfileDefinitions.addons.Count - 1)) {
        if ($Global:compiledProfileDefinitions.addons[$i].addonName -eq $addon.addonName) {
            if (!($Global:compiledProfileDefinitions.addons[$i].PSObject.Properties.Name -contains 'workspacedSizeMB')) {
                $Global:compiledProfileDefinitions.addons[$i] | Add-Member -NotePropertyName 'workspacedSizeMB' -NotePropertyValue $workspaceSize
            } else {
                $Global:compiledProfileDefinitions.addons[$i].workspacedSizeMB = $workspaceSize
            }
            if (!($Global:compiledProfileDefinitions.addons[$i].PSObject.Properties.Name -contains 'addonSizeMB')) {
                $Global:compiledProfileDefinitions.addons[$i] | Add-Member -NotePropertyName 'addonSizeMB' -NotePropertyValue $addonSizeMB
            } else {
                $Global:compiledProfileDefinitions.addons[$i].addonSizeMB = $addonSizeMB
            }
        }
    }
}

function ConvertTo-CustomJson {
    param(
        [Parameter(Mandatory=$true)]
        [PSObject]
        $InputObject
    )

    $json = $InputObject | ConvertTo-Json -Depth 100
    $json = $json -replace '\\u0026', '&'
    $json = $json -replace '\\u0027', "'"

    # Match "pathToGamedata" elements and format them
    $json = $json -replace '(?<="pathToGamedata": \[\r?\n)(\s*{\s*"priority":.*?}\s*(,\r?\n)?)+', {
        # Split the match into individual elements
        $elements = $_.Value -split ',\r?\n' | ForEach-Object {
            # Remove all newlines and extra spaces, and add the necessary indentation
            $_ -replace '\r?\n', '' -replace '\s+', ' ' -replace '^ ', '                '
        }

        # Join the elements back together with commas and newlines
        $elements -join ',`r`n'
    }

    return $json
}

function WriteUpdatedProfile{
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $profileDefinitions
    )

    $addonsSizeRequirementMB = ($profileDefinitions.addons | Measure-Object -Property addonSizeMB -Sum).Sum

    $Global:compiledProfileDefinitions.finalDiskspaceRequirementMB = $Global:installedModsSize

    DisplayInfoMessage " Workspace: $($Global:maxWorkspaceSize) - Installed Mods: $($Global:installedModsSize) MB - Addons: $addonsSizeRequirementMB MB " $tabIndent

    $Global:compiledProfileDefinitions.installationDiskspaceRequirementMB = $Global:maxWorkspaceSize + $Global:installedModsSize + $addonsSizeRequirementMB

    $json = ConvertTo-CustomJson -InputObject $Global:compiledProfileDefinitions
    Set-Content -LiteralPath "$Global:pathToEXTProfiles/$($Global:compiledProfileDefinitions.profileName)/profile_definitions.json" -Value $json

}

function SyncAll{

    DisplayProcessStep " Syncing all profiles "
    Write-Host
    Write-Host
    
    $installedMOProfiles = Get-ChildItem -Path $Global:pathToMOProfiles -Directory

    foreach ($installedProfile in $installedMOProfiles) {

        $installedProfileDefinitions = GetMOProfileDefinitions $installedProfile.BaseName

        if ($installedProfileDefinitions){
            SynchProfile $installedProfileDefinitions
        }
    }
}
$MozillaAgent = $([Microsoft.PowerShell.Commands.PSUserAgent]::InternetExplorer)

function VerifyAddonLink{
    param (
        [Parameter(Mandatory = $true, Position = 0)]
        $addon,
        [Parameter(Mandatory = $true, Position = 1)]
        $WebClient,
        [Parameter(Mandatory = $true, Position = 3)]
        $verification
    )

    if ($addon.fileUrl.StartsWith('https://mega.nz') -eq $true){
        return
    }
    try {
        # $contentType = (Invoke-WebRequest -Uri $addon.fileUrl -UserAgent $MozillaAgent -UseBasicParsing -ErrorAction Stop).Headers.'Content-Type'
        # DisplayPositiveText ">> Link Verification Succesful [DISABLED]" ($tabIndent  + $tabIndent + $tabIndent)
    }catch {
        Write-Host
        DisplayWarningMessage " Link Verification Failed " ($tabIndent  + $tabIndent)
        DisplayNegativeText "The addon download link appears to have been removed or changed" ($tabIndent  + $tabIndent + $tabIndent)
        DisplayNegativeText $Error[0] ($tabIndent  + $tabIndent + $tabIndent)
        Write-Host
        DisplayInfoText "Please visit to the addon page and look for the new addon link " ($tabIndent  + $tabIndent + $tabIndent)
        Write-Host 
        DisplayNoticeText "Addon page ->  $($addon.addonUrl)" ($tabIndent  + $tabIndent + $tabIndent)
        Write-Host 
        DisplayInfoText "Update the addon link using updatedefinitions command " ($tabIndent  + $tabIndent + $tabIndent)
        Write-Host
        DisplayPositiveText "run > .\GAMMA_EXT.ps1 -updatedefinitions -addon `"$($addon.addonName)`"" ($tabIndent  + $tabIndent + $tabIndent)
        Write-Host
        $verification.isVerifed = $false
        $errorMsg = [string]$Error[0]
        $failureLog = [PSCustomObject]@{
            type = "verificationdl"
            target = $addon.addonName
            error = $errorMsg.Trim()
            message = @(
                "Could not verify addon download url from $($addon.fileUrl)"
            )
        }
        $verification.failureLogs += $failureLog
    }
}
function VerifyAddonMD5HashModdb {
    param (
        [Parameter(Mandatory = $true, Position = 0)]
        $addon
    )
    $md5checkResults = [PSCustomObject]@{
        match = $true
        currentHash = $null
        dlHash = $null 
    }
    # save response in temp file
    $tmpMD5File = "./workspace/$($addon.resourceFilename)_md5_tmp.html"        
    Invoke-WebRequest -Uri $addon.addonUrl -UserAgent $MozillaAgent -OutFile $tmpMD5File -ErrorAction Stop
    
    # search md5 hash
    $md5Content = Get-Content -Path $tmpMD5File -Raw
    [regex]$regex = '(?<=(<h5>MD5 Hash</h5>\s+<span class="summary">\s+))[A-Za-z0-9]+(?=(\s+</span>))'
    $dlHash = $regex.Matches($md5Content).Value
    # DisplayNoticeText "MD5 Hash: $md5hash" ($tabIndent  + $tabIndent + $tabIndent)
    
    $currentHash = Get-FileHash -Path $([WildcardPattern]::Escape($(GetAddonResourcePath $addon))) -Algorithm MD5
    
    if ($dlHash -ne $currentHash.Hash){
        $md5checkResults.match = $false
        $md5checkResults.currentHash = $currentHash.Hash
        $md5checkResults.dlHash = $dlHash
    }

    # Delete _tmp.txt
    Remove-Item $tmpMD5File -ErrorAction Ignore

    return $md5checkResults
}
function BackupAddon{
    param (
        [Parameter(Mandatory = $true, Position = 0)]
        $addon
    )

    $source = GetAddonResourcePath $addon

    if (!(Test-Path "$pathToEXTBackups/addons")){
        New-Item -Path "$pathToEXTBackups/addons" -ItemType Directory | Out-Null
    }

    $extension = [System.IO.Path]::GetExtension($source)

    $timestamp = Get-Date -Format "yyyy-MM-dd_HHmmss"

    $destination = "$pathToEXTBackups/addons/$($addon.resourceFilename)_$timestamp$extension"

    DisplayInfoText "Backing up old file to $destination" ($tabIndent  + $tabIndent + $tabIndent) 

    Move-Item -Path $source -Destination $destination -Force | Out-Null
}
function DownloadAddon {
    param (
        [Parameter(Mandatory = $true, Position = 0)]
        $addon,
        [Parameter(Mandatory = $true, Position = 1)]
        $WebClient,
        [Parameter(Mandatory = $true, Position = 3)]
        $verification
    )

    if ($addon.source -eq "$Global:MO_DOWNLOADS"){
        return
    }

    try {
        if ($addon.fileUrl.StartsWith('https://www.moddb.com')){
            DownloadModDbAddon $addon
        }elseif ($addon.fileUrl.StartsWith('https://drive.google.com')){
            DownloadGDriveAddon $addon
        }elseif ($addon.fileUrl.StartsWith('https://www.dropbox.com')){
            DownloadDropBoxAddon $addon $WebClient
        }elseif ($addon.fileUrl.StartsWith('https://www.mediafire.com')){
            DownloadMediafireAddon $addon
        }elseif ($addon.fileUrl.StartsWith('https://cdn.discordapp.com' -or $addon.fileUrl.StartsWith('https://github.com'))){
            DownloadDefaultServer $addon
        }else{
            DownloadDefaultServer $addon
        }
    }
    catch {
        Write-Host
        DisplayWarningMessage " Automatic Download failed " ($tabIndent  + $tabIndent)
        DisplayInfoText "an error occurred duding the download of the addon from the remote site" ($tabIndent  + $tabIndent + $tabIndent)
        Write-Host
        DisplayNegativeText $Error[0] ($tabIndent  + $tabIndent + $tabIndent)
        Write-Host
        DisplayInfoText "Please try again later, or manually download the addon from the link provided and save it in addons" ($tabIndent  + $tabIndent + $tabIndent)
        DisplayInfoText "Check also that the addons link might have changed by visiting the addon page " ($tabIndent  + $tabIndent + $tabIndent)
        DisplayInfoText "Some addons can only be downloaded with browser download enabled" ($tabIndent  + $tabIndent + $tabIndent)
        Write-Host
        DisplayNoticeMessage " Wait for the completion of this process for a summary of errors and suggested workarounds " ($tabIndent  + $tabIndent + $tabIndent)
        Write-Host
        # Remove-Item -Path "$pathToEXTAddons\$($addon.resourceFilename)" -Force -ErrorAction Ignore
        DisplayElementMissingMessage $addon.addonName " not available " "WARNING" $tabIndent
        $verification.isVerifed = $false
        $errorMsg = [string]$Error[0]
        $failureLog = [PSCustomObject]@{
            type = "autodl"
            target = $addon.addonName
            error = $errorMsg.Trim()
            message = @(
                "Failed to automatically download from $($addon.fileUrl)"
            )
        }
        $verification.failureLogs += $failureLog
        $addonPath = "$Global:pathToEXTAddons/$($addon.resourceFilename)"
        if ((Test-Path -Path ([WildcardPattern]::Escape($addonPath))) -and !(Get-Item ([WildcardPattern]::Escape($addonPath))).length -gt 0kb){
            # delete file
            Remove-Item -LiteralPath "$pathToEXTAddons\$($addon.resourceFilename)" -Force -ErrorAction Ignore
        }
    }
}

function DownloadDefaultServer {
    param (
        [Parameter(Mandatory = $true, Position = 0)]
        $addon
    )
    DisplayInfoText "Using Default EXT client" ($tabIndent  + $tabIndent + $tabIndent)
    $addonSavePath = "$pathToEXTAddons\$($addon.resourceFilename)"

    DisplayInfoText "Downloading addon file from $($addon.fileUrl) - saving to $addonSavePath" ($tabIndent  + $tabIndent + $tabIndent)
    $maxRetries = 5
    for ($i = 0; $i -lt $maxRetries; $i++) {
        try {
            Start-BitsTransfer -Source $addon.fileUrl -Destination $addonSavePath -ErrorAction Stop
            break
        } catch {
            if ($i -eq $maxRetries - 1) {
                throw
            } else {
                DisplayWarningMessage " Download failed, retrying in 2 seconds " ($tabIndent  + $tabIndent + $tabIndent)
                Start-Sleep -Seconds (2 * $i)
            }
        }
    }    
}

function DownloadMediafireAddon {
    param (
        [Parameter(Mandatory = $true, Position = 0)]
        $addon
    )
    
    $addonSavePath = "$pathToEXTAddons\$($addon.resourceFilename)"
    $url = $addon.fileUrl

    # get addon download page respose with url 
    $contentType = (Invoke-WebRequest -Uri $url -UserAgent $MozillaAgent -Method Head -ErrorAction Stop).Headers.'Content-Type'
    if($contentType.Contains("text/html") -or $contentType.Contains("application/json")){

        # save response in temp file
        $tmpFile = "./workspace/$($addon.resourceFilename)_tmp.html"        
        Invoke-WebRequest -Uri $url -UserAgent $MozillaAgent -OutFile $tmpFile -ErrorAction Stop
        
        # search url with base https://www.moddb.com/downloads/mirror
        $content = Get-Content -Path $tmpFile -Raw
        [regex]$regex = 'https:\/\/download\d+\.mediafire\.com\/[^\s"]+'
        $url = $regex.Matches($content).Value
        
        # Delete _tmp.txt
        Remove-Item $tmpFile -ErrorAction Ignore

        # download addon with matched url
        DisplayInfoText "Downloading addon file from $url - saving to $addonSavePath" ($tabIndent  + $tabIndent + $tabIndent)
        Start-BitsTransfer -Source $url -Destination $addonSavePath -ErrorAction Stop
    }else{
        DisplayInfoText "Downloading addon file from $url - saving to $addonSavePath" ($tabIndent  + $tabIndent + $tabIndent)
        # Response from url is binary, just download as addon
        Start-BitsTransfer -Source $url -Destination $addonSavePath -ErrorAction Stop
    }
}

function DownloadWithBrowser{
    param (
        [Parameter(Mandatory = $true, Position = 0)]
        $url
    )
    # Paths
    $defaultPath = Join-Path $Global:pathToEXTBrowserProfile "Default"
    $preferencesPath = Join-Path $defaultPath "Preferences"

    # Step 1: Create download preferences
    $preferences = @{
        download = @{
            default_directory = $Global:pathToEXTAddons.Replace("/", "\")
            prompt_for_download = $false
        }
        savefile = @{
            default_directory = $Global:pathToEXTAddons.Replace("/", "\")
            prompt_for_download = $false
        }        
    } | ConvertTo-Json -Depth 10

    # Step 2: Ensure directory structure exists
    New-Item -Path $defaultPath -ItemType Directory -Force | Out-Null

    # Step 3: Write preferences to Preferences file
    Set-Content -Path $preferencesPath -Value $preferences

    # Step 4: Launch Chrome with arguments
    $arguments = @(
        "--no-first-run"
        "--disable-popup-blocking"        
        "--user-data-dir=`"$Global:pathToEXTBrowserProfile`""
        "`"$url`""
    )

    # Step 5: Run Chrome
    Start-Process -FilePath $Global:pathToUserBrowser -ArgumentList $arguments    
}

function DownloadModDbAddon {
    param (
        [Parameter(Mandatory = $true, Position = 0)]
        $addon
    )
    
    # get addon download page respose with url 
    $addonSavePath = "$pathToEXTAddons\$($addon.resourceFilename)"
    $url = $addon.fileUrl

    if (Test-Path $addonSavePath) {
        BackupAddon $addon
    }
    DisplayInfoText "Using Browser client" ($tabIndent  + $tabIndent + $tabIndent)
    DisplayInfoText "Downloading addon file from $url" ($tabIndent  + $tabIndent + $tabIndent)
    if ($Global:browserdl){
        DownloadWithBrowser $url
    }else{
        throw "Cannot download this file, please enable Browser Downloads in EXT or use manual download"
        # $contentType = (Invoke-WebRequest -Uri $url -UserAgent $MozillaAgent -Method Head -UseBasicParsing -ErrorAction Stop).Headers.'Content-Type'
        # if($contentType.Contains("text/html") -or $contentType.Contains("application/json")){

        #     # save response in temp file
        #     $tmpFile = "./workspace/$($addon.resourceFilename)_tmp.html"
        #     Invoke-WebRequest -Uri $url -UserAgent $MozillaAgent -OutFile $tmpFile -ErrorAction Stop

        #     # search url with base https://www.moddb.com/downloads/mirror
        #     $content = Get-Content -Path $tmpFile -Raw
        #     [regex]$regex = '(https)\:\/\/(www\.moddb\.com\/downloads\/mirror\/)+[a-zA-Z0-9\/]+[a-zA-Z0-9]{2,3}(\/\S*)?'
        #     $url = $regex.Matches($content).Value
        #     # Delete _tmp.txt
        #     Remove-Item $tmpFile -ErrorAction Ignore

        #     # download addon with matched url
        #     DisplayInfoText "Downloading addon file from $url" ($tabIndent  + $tabIndent + $tabIndent)
        #     DisplayNoticeText "Saving as $($addon.resourceFilename)" ($tabIndent  + $tabIndent + $tabIndent)
        #     Start-BitsTransfer -Source $url -Destination $addonSavePath -ErrorAction Stop
        # }else{
        #     DisplayInfoText "Downloading addon file from $url" ($tabIndent  + $tabIndent + $tabIndent)
        #     # Response from url is binary, just download as addon
        #     Start-BitsTransfer -Source $url -Destination $addonSavePath -ErrorAction Stop
        # }
    }
}

function CheckAddon {
    param (
        [Parameter(Mandatory = $true, Position = 0)]
        $addon
    )

    try {
        if ($addon.fileUrl.StartsWith('https://www.moddb.com')){
            # Write-Host
            # DisplayProcessSubStep " Checking Addon status on Moddb.com" ($tabIndent  + $tabIndent)
            # return CheckModDbAddon $addon
            $check = [PSCustomObject]@{
                result = $true
                reason = ""
            }            
            return $check
        }else{
            $check = [PSCustomObject]@{
                result = $true
                reason = ""
            }            
            return $check
        }
    }
    catch {
        Write-Host
        DisplayWarningMessage " Downloadable Addon Check failed " ($tabIndent  + $tabIndent)
        DisplayNegativeText "an error occurred while checking downloadable addon resource from the remote site" ($tabIndent  + $tabIndent + $tabIndent)
        DisplayNegativeText $Error[0] ($tabIndent  + $tabIndent + $tabIndent)
    }    
}

function CheckModDbAddon{
    param (
        [Parameter(Mandatory = $true, Position = 0)]
        $addon,
        [Parameter(Mandatory = $false, Position = 1)]
        $content
    )
    
    $check = [PSCustomObject]@{
        result = $true
        reason = ""
    }

    # get addon download page respose with url 
    $url = $addon.fileUrl

    if($null -eq $content){
        $contentType = (Invoke-WebRequest -Uri $url -UserAgent $MozillaAgent -Method Head -UseBasicParsing -ErrorAction Stop).Headers.'Content-Type'
        if($contentType.Contains("text/html") -or $contentType.Contains("application/json")){
            # save response in temp file
            $tmpFile = "./workspace/$($addon.resourceFilename)_tmp.html"
            Invoke-WebRequest -Uri $url -UserAgent $MozillaAgent -OutFile $tmpFile -ErrorAction Stop
            $content = Get-Content -Path $tmpFile -Raw      
        }else{
            DisplayWarningMessage " Could not check Downloadable addon resource "
            return $check
        }
    }
    # search filename
    [regex]$regex = '(?<=(>download )).*(?=(<\/a> if ))'
    $filename = $regex.Matches($content).Value

    if ($filename -ne $addon.resourceFilename){
        Write-Host
        DisplayWarningMessage " The current downloadable version of this addon ($filename) does not match the filename in this profile definitions: $($addon.resourceFilename) " ($tabIndent  + $tabIndent + $tabIndent)
        DisplayNegativeText "   Under these circumstances it appears that the version available online has been updated or changed" ($tabIndent  + $tabIndent + $tabIndent)
        DisplayNegativeText "   You should notify the profile creator [$($profileDefinitions.profileCreator)] concerning this issue " ($tabIndent  + $tabIndent + $tabIndent)
        Write-Host
        DisplayInfoText "Addon Web Page $($addon.addonUrl)" ($tabIndent  + $tabIndent + $tabIndent)
        Write-Host        
        DisplayInfoText "Download link --> $($addon.fileUrl)" ($tabIndent  + $tabIndent + $tabIndent)
        Write-Host

        $check.result = $false
        $check.reason = "version"
    }else{
        # verify hash only if exists a downloaded version already
        if (Test-Path -LiteralPath "$pathToEXTAddons/$($addon.resourceFilename)"){
            # checking hash of existing addon
            $checkResults = VerifyAddonMD5HashModdb $addon
            if ($false -eq $checkResults.match){
                Write-Host
                DisplayWarningMessage " Downloadable addon MD5 hash mismatch " ($tabIndent  + $tabIndent + $tabIndent)
                DisplayNoticeText "The version of the addon in the cloud appears to be different" ($tabIndent  + $tabIndent + $tabIndent)
                Write-Host
                DisplayInfoText "Current addon MD5 Hash: $($checkResults.currentHash)" ($tabIndent  + $tabIndent + $tabIndent)
                Write-Host
                DisplayNoticeText "Downloadable addon MD5 Hash: $($checkResults.dlHash)" ($tabIndent  + $tabIndent + $tabIndent)
                Write-Host
    
                $check.result = $false
                $check.reason = "hash"
            }else{
                DisplayPositiveText ">> Addon is up to date " ($tabIndent  + $tabIndent + $tabIndent)
            }
        }
    }
    # Delete _tmp.txt
    Remove-Item $tmpFile -ErrorAction Ignore

    return $check
}

function DownloadDropBoxAddon {
    param (
        [Parameter(Mandatory = $true, Position = 0)]
        $addon,
        [Parameter(Mandatory = $true, Position = 1)]
        $WebClient
    )
    
    $addonSavePath = "$pathToEXTAddons\$($addon.resourceFilename)"

    DisplayInfoText "Downloading addon file from $($addon.fileUrl) - saving to $addonSavePath" ($tabIndent  + $tabIndent + $tabIndent)
    $WebClient.DownloadFile($addon.fileUrl, $addonSavePath)

}
function DownloadGDriveAddon {
    param (
        [Parameter(Mandatory = $true, Position = 0)]
        $addon
    )    

    # get GoogleFileId
    $GoogleFileId = $addon.fileUrl.Replace("https://drive.google.com/file/d/","")
    $GoogleFileId = $GoogleFileId.Replace("/view?usp=share_link","")
    $GoogleFileId = $GoogleFileId.Replace("/view?usp=drive_link","")
    $GoogleFileId = $GoogleFileId.Replace("/view?usp=sharing","")
    $GoogleFileId = $GoogleFileId.Replace("/view","")

    $addonSavePath = "$pathToEXTAddons\$($addon.resourceFilename)"
    $url = "https://drive.google.com/uc?export=download&id=$GoogleFileId"

    if ($addon.forceManualDl){
        DisplayWarningMessage "Automatic download cannot be used for this addon " ($tabIndent + $tabIndent)
        DisplayNoticeMessage "Please manually download addon file from $url" ($tabIndent  + $tabIndent + $tabIndent)
        DisplayNoticeMessage "A tab was opened in the EXT browser " ($tabIndent  + $tabIndent + $tabIndent)
        DownloadWithBrowser $url
    }else{
        DisplayInfoText "Using Default EXT client" ($tabIndent  + $tabIndent + $tabIndent)
        # set protocol to tls version 1.2
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
        $contentType = (Invoke-WebRequest -Uri $url -UserAgent $MozillaAgent -Method Head -UseBasicParsing -ErrorAction Stop).Headers.'Content-Type'
        if($contentType.Contains("text/html") -or $contentType.Contains("application/json")){
            # Download the Virus Warning into _tmp.txt
            $tmpFile = "./workspace/$($addon.addonName)_tmp.html"
            Invoke-WebRequest -Uri $url -OutFile $tmpFile -ErrorAction Stop
            $response = Get-Content $tmpFile -Raw

            if ($response -match "Google Drive - Quota exceeded"){
                Remove-Item $tmpFile -ErrorAction Ignore
                throw "Google Drive Quota exceeded - This file has exceeded its download quota. Please try again later or download the file manually using the download link"
            }else{

                # Extract the value attributes
                $uuidPattern = '<input[^>]*name="uuid"[^>]*value="([^"]*)"[^>]*>'
                $idPattern = '<input[^>]*name="id"[^>]*value="([^"]*)"[^>]*>'

                $uuidMatches = [regex]::Matches($response, $uuidPattern)
                $idMatches = [regex]::Matches($response, $idPattern)

                # Print the values
                foreach ($match in $uuidMatches) {
                    $uuid = $match.Groups[1].Value
                    # Write-Output "UUID Value: $uuid"
                }

                foreach ($match in $idMatches) {
                    $id = $match.Groups[1].Value
                    # Write-Output "ID Value: $id"
                }
                # Delete _tmp.txt
                Remove-Item $tmpFile -ErrorAction Ignore
                $url = "https://drive.usercontent.google.com/download?id=$id&export=download&authuser=0&confirm=t&uuid=$uuid"
                # Download the arhive file this time
                DisplayInfoText "Downloading addon file from $url" ($tabIndent  + $tabIndent + $tabIndent)

                if ($addon.forceBrowserDl -and $Global:browserdl){
                    DownloadWithBrowser $url
                }else{
                    Start-BitsTransfer -Source $url -Destination $addonSavePath -ErrorAction Stop   
                } 
            } 
        }else{
            DisplayInfoText "Downloading addon file from $url - saving to $addonSavePath" ($tabIndent  + $tabIndent + $tabIndent)
            Start-BitsTransfer -Source $url -Destination $addonSavePath -ErrorAction Stop 
        }
    }
}

function DownloadProfile {
    param (
        [Parameter(Mandatory = $true, Position = 0)]
        $profile,
        [Parameter(Mandatory = $true, Position = 1)]
        $WebClient
    )
    Write-Host
    DisplayProcessSubStep " Downloading $($profile.name) "
    DisplayInfoText " from $($profile.url)"
    # DisplayInfoText " hold on... "
    # Invoke-WebRequest -Uri $profile.url -OutFile "./shared/$($profile.filename)" -SessionVariable googleDriveSession 
    # $WebClient.DownloadFile($profile.url,"./shared/$($profile.filename)")
    Start-BitsTransfer -Source $profile.url -Destination "./shared/$($profile.filename)" -ErrorAction Stop
    Write-Host
    DisplayInfoMessage " Profile downloaded "
}

function IsFileBinary {
    param (
        $filePath
    )
    # encoding variable
    $encoding = ""

    # Get the first 1024 bytes from the file
    $byteArray = Get-Content -Path $filePath -Encoding Byte -TotalCount 1024

    if( ("{0:X}{1:X}{2:X}" -f $byteArray) -eq "EFBBBF" )
    {
        # Test for UTF-8 BOM
        $encoding = "UTF-8"
    }
    elseif( ("{0:X}{1:X}" -f $byteArray) -eq "FFFE" )
    {
        # Test for the UTF-16
        $encoding = "UTF-16"
    }
    elseif( ("{0:X}{1:X}" -f $byteArray) -eq "FEFF" )
    {
        # Test for the UTF-16 Big Endian
        $encoding = "UTF-16 BE"
    }
    elseif( ("{0:X}{1:X}{2:X}{3:X}" -f $byteArray) -eq "FFFE0000" )
    {
        # Test for the UTF-32
        $encoding = "UTF-32"
    }
    elseif( ("{0:X}{1:X}{2:X}{3:X}" -f $byteArray) -eq "0000FEFF" )
    {
        # Test for the UTF-32 Big Endian
        $encoding = "UTF-32 BE"
    }

    if($encoding)
    {
        # File is text encoded
        return $false
    }

    # So now we're done with Text encodings that commonly have '0's
    # in their byte steams.  ASCII may have the NUL or '0' code in
    # their streams but that's rare apparently.

    # Both GNU Grep and Diff use variations of this heuristic

    if( $byteArray -contains 0 )
    {
        # Test for binary
        return $true
    }

    # This should be ASCII encoded 
    $encoding = "ASCII"

    return $false
}
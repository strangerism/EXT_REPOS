#ifndef        HMODEL_H
#define HMODEL_H
#define CUBE_MIPS 6 //mipmaps for ambient shading and specular

#include "pbr_cubemap_check.h"
#include "TintTest.h"
//gamma correction is set up to be semi gamma correct

TextureCube		env_s0;
TextureCube		env_s1;

uniform float4		env_color;        // color.w = lerp factor
float4 hmodel_stuff;  //x - hemi vibrance // y - hemi contrast // z - wet surface factor

float3 AmbientCube( TextureCube Cubemap, float3 Normal, float3 NormalSqr)
{
	const float Epsilon = 0.001;
	float3 Amb = 0;
	Amb += NormalSqr.x * (Cubemap.SampleLevel(smp_base, float3(Normal.x, Epsilon, Epsilon), CUBE_MIPS).rgb);
	Amb += NormalSqr.y * (Cubemap.SampleLevel(smp_base, float3(Epsilon, Normal.y, Epsilon), CUBE_MIPS).rgb); 
	Amb += NormalSqr.z * (Cubemap.SampleLevel(smp_base, float3(Epsilon, Epsilon, Normal.z), CUBE_MIPS).rgb); 
	return Amb;
}

void hmodel
(
	out float3 hdiffuse, out float3 hspecular, 
	float m, float h, float4 alb_gloss, float3 Pnt, float3 normal
)
{
	float3 albedo = float3(0.18, 0.18, 0.18);
	float3 specular = float3(SPECULAR_BASE, SPECULAR_BASE, SPECULAR_BASE);
	float rough = 1 - Ldynamic_color.w;
	
	calc_material(alb_gloss, m, rough, albedo, specular);
	//calc_rain(albedo, specular, rough, alb_gloss, m, h);
	
	//normal vector
	normal = normalize(normal);
	float3	nw = mul(m_inv_V, normal);
	nw = normalize(nw);
	
	//view vector
	Pnt = normalize(Pnt);
	float3	v2Pnt = mul(m_inv_V, Pnt);
	v2Pnt = normalize(v2Pnt);
	
	//reflection vector
	float3	vreflect= reflect(v2Pnt, nw);
	vreflect = getSpecularDominantDir(nw, vreflect, rough);

	//normal remap
	float3 nwRemap = nw;
	float3 vnormabs = abs(nwRemap);
	float  vnormmax = max(vnormabs.x, max(vnormabs.y, vnormabs.z));
	nwRemap /= vnormmax;
    if (nwRemap.y < 0.999) nwRemap.y = nwRemap.y*2-1;     // fake remapping 
	nwRemap = normalize(nwRemap);
	
	//reflect remap
	float3 vreflectRemap = vreflect;
	float3 vreflectabs = abs(vreflectRemap);
	float vreflectmax = max(vreflectabs.x, max(vreflectabs.y, vreflectabs.z));
	vreflectRemap /= vreflectmax;
	if (vreflectRemap.y < 0.999) vreflectRemap.y = vreflectRemap.y*2-1;	//fake remapping 
	vreflectRemap = normalize(vreflectRemap);	

	// hscale - something like diffuse reflection
	float	hscale = h;	//. * (.5h + .5h*nw.y);
	float	hspec	= .5h + .5h * dot(vreflect, v2Pnt);
	
	//TODO - make hscale normal mapped
	float4 light = s_material.SampleLevel(smp_material, float3(hscale, hspec, m), 0).xxxy;
	//float4 light = float4(hscale.xxx, 0.0);
	
	//Valve style ambient cube
	float3 nSquared = nw * nw;
	//diffuse color
	float3 e0d = AmbientCube(env_s0, nwRemap, nSquared);
	float3 e1d = AmbientCube(env_s1, nwRemap, nSquared);
	float3 env_d = SkyBlendTint(e0d, e1d, env_color.w, env_color.rgb);
	env_d = env_d * light.xyz + L_ambient.rgb; 
	
	//PBR roughness
	float roughCube = rough;
	float RoughMip = roughCube * CUBE_MIPS;
	//float RoughMip = CUBE_MIPS - ((1 - roughCube) * CUBE_MIPS);
	//specular color
	float3	e0s = env_s0.SampleLevel(smp_base, vreflectRemap, RoughMip);
	float3	e1s = env_s1.SampleLevel(smp_base, vreflectRemap, RoughMip);
	float3 env_s = SkyBlendTint(e0s, e1s, env_color.w, env_color.rgb);
	env_s = env_s * light.xyz + L_ambient.rgb; 
	
	env_d = SRGBToLinear(env_d); 
	env_s = SRGBToLinear(env_s);
	hdiffuse = Amb_BRDF(rough, albedo, specular, env_d, env_s, -v2Pnt, nw).rgb;
	hspecular = 0; //do not use hspec at all
}
#endif
function ShowHelpEXT {
    param (
        [Parameter(Mandatory = $true, Position = 0)]
        $param1,
        [Parameter(Mandatory = $true, Position = 1)]
        $param2         
    )

    if ($param1 -ne "profiles" -and $param1 -ne "moprofiles" -and $param1 -ne "" -and ($null -eq $param2 -or $param2 -eq "")){
        $param2 = $param1
        $param1 = ""

    }

    if ($null -eq $param2 -or $param2 -eq ""){
        $param2 = "<ProfileName>"
    }

    if(!($param1 -eq "profiles") -and !($param1 -eq "moprofiles")){
        DisplayProcessStep " EXT Help Basic Commands "
        Write-Host
        DisplayInfoText "Listing help for all basic EXT commands " $tabIndent
        # Show EXT Help
        Write-Host
        DisplayProcessSubStep " Show EXT Help " ($tabIndent  + $tabIndent)
        DisplayInfoText "Shows help about all EXT commands" ($tabIndent  + $tabIndent + $tabIndent)
        DisplayInfoText "add a profile name to show commands tailored with profile name" ($tabIndent  + $tabIndent + $tabIndent)        
        DisplayPositiveText ">> .\GAMMA_EXT.ps1" ($tabIndent  + $tabIndent + $tabIndent)
        DisplayPositiveText ">> .\GAMMA_EXT.ps1 -help" ($tabIndent  + $tabIndent + $tabIndent)
        DisplayPositiveText ">> .\GAMMA_EXT.ps1 -help `"<ProfileName>`"" ($tabIndent  + $tabIndent + $tabIndent)
        # Show EXT Profiles Help
        Write-Host
        DisplayProcessSubStep " Show EXT Profiles Help " ($tabIndent  + $tabIndent)
        DisplayInfoText "Shows help on commands that operate on EXT profiles" ($tabIndent  + $tabIndent + $tabIndent)
        DisplayInfoText "add a profile name to show commands tailored with profile name" ($tabIndent  + $tabIndent + $tabIndent)   
        DisplayPositiveText ">> .\GAMMA_EXT.ps1 -help profiles" ($tabIndent  + $tabIndent + $tabIndent)
        DisplayPositiveText ">> .\GAMMA_EXT.ps1 -help profiles `"<ProfileName>`"" ($tabIndent  + $tabIndent + $tabIndent)        
        # Show EXT Installed Profiles Help
        Write-Host
        DisplayProcessSubStep " Show EXT Installed Profiles Help " ($tabIndent  + $tabIndent)
        DisplayInfoText "Shows help on commands that operate on installed EXT profiles" ($tabIndent  + $tabIndent + $tabIndent)
        DisplayInfoText "add a profile name to show commands tailored with profile name" ($tabIndent  + $tabIndent + $tabIndent) 
        DisplayPositiveText ">> .\GAMMA_EXT.ps1 -help moprofiles" ($tabIndent  + $tabIndent + $tabIndent)
        DisplayPositiveText ">> .\GAMMA_EXT.ps1 -help moprofiles `"<ProfileName>`"" ($tabIndent  + $tabIndent + $tabIndent)                                       
        # Debug Info
        Write-Host
        DisplayProcessSubStep " Debug Info " ($tabIndent  + $tabIndent)
        DisplayInfoText "Display EXT debug info useful for when asking support regarding EXT issues " ($tabIndent  + $tabIndent + $tabIndent)
        DisplayInfoText "use additional flag to display brief summary instead of full summary " ($tabIndent  + $tabIndent + $tabIndent)
        DisplayPositiveText ">> .\GAMMA_EXT.ps1 -debuginfo" ($tabIndent  + $tabIndent + $tabIndent)
        DisplayPositiveText ">> .\GAMMA_EXT.ps1 -debuginfo -short" ($tabIndent  + $tabIndent + $tabIndent)
        DisplayPositiveText ">> .\GAMMA_EXT.ps1 -debuginfo -anomaly" ($tabIndent  + $tabIndent + $tabIndent)
        DisplayPositiveText ">> .\GAMMA_EXT.ps1 -debuginfo -mo" ($tabIndent  + $tabIndent + $tabIndent)
        DisplayPositiveText ">> .\GAMMA_EXT.ps1 -debuginfo -moprofiles" ($tabIndent  + $tabIndent + $tabIndent)
        DisplayPositiveText ">> .\GAMMA_EXT.ps1 -debuginfo -moini" ($tabIndent  + $tabIndent + $tabIndent)                          
        # List Profiles
        Write-Host
        DisplayProcessSubStep " List Profiles " ($tabIndent  + $tabIndent)
        DisplayInfoText "List profiles currently available in EXT " ($tabIndent  + $tabIndent + $tabIndent)
        DisplayInfoText "use -short flag to display brief summary instead of full summary " ($tabIndent  + $tabIndent + $tabIndent)
        DisplayPositiveText ">> .\GAMMA_EXT.ps1 -listprofiles" ($tabIndent  + $tabIndent + $tabIndent)
        DisplayPositiveText ">> .\GAMMA_EXT.ps1 -listprofiles -short" ($tabIndent  + $tabIndent + $tabIndent)  
        # Get Profiles
        Write-Host
        DisplayProcessSubStep " Get Profiles " ($tabIndent  + $tabIndent)
        DisplayInfoText "Download and adds all the official EXT profile to your EXT instance" ($tabIndent  + $tabIndent + $tabIndent)
        DisplayPositiveText ">> .\GAMMA_EXT.ps1 -getprofiles" ($tabIndent  + $tabIndent + $tabIndent)
        # Get Profile
        Write-Host
        DisplayProcessSubStep " Get Profile " ($tabIndent  + $tabIndent)
        DisplayInfoText "Download and adds the latest available version of a profile to your EXT instance" ($tabIndent  + $tabIndent + $tabIndent)
        DisplayPositiveText ">> .\GAMMA_EXT.ps1 -getprofiles `"$param2`"" ($tabIndent  + $tabIndent + $tabIndent) 
        # Add Profile
        Write-Host
        DisplayProcessSubStep " Add Profile " ($tabIndent  + $tabIndent)
        DisplayInfoText "Adds a shared profile that was placed in the `shared` folder into EXT making it available for install" ($tabIndent  + $tabIndent + $tabIndent)
        DisplayPositiveText ">> .\GAMMA_EXT.ps1 -add `"$param2`"" ($tabIndent  + $tabIndent + $tabIndent)  
        # Remove Profile
        Write-Host
        DisplayProcessSubStep " Remove Profile " ($tabIndent  + $tabIndent)
        DisplayInfoText "Removes an available profile from EXT" ($tabIndent  + $tabIndent + $tabIndent)
        DisplayPositiveText ">> .\GAMMA_EXT.ps1 -remove `"$param2`"" ($tabIndent  + $tabIndent + $tabIndent)     
        # Purge Old Addons
        Write-Host
        DisplayProcessSubStep " Purge Addons " ($tabIndent  + $tabIndent)
        DisplayInfoText "Lists and (optionally) purges all unused addons' files from EXT" ($tabIndent  + $tabIndent + $tabIndent)
        DisplayPositiveText ">> .\GAMMA_EXT.ps1 -purge" ($tabIndent  + $tabIndent + $tabIndent)               
        # Enable Automatic Downloads
        Write-Host
        DisplayProcessSubStep " Enable Automatic Downloads " ($tabIndent  + $tabIndent)
        DisplayInfoText "Enable the automatic download of addons when installing a profile" ($tabIndent  + $tabIndent + $tabIndent)
        DisplayPositiveText ">> .\GAMMA_EXT.ps1 -enable automatic-dl" ($tabIndent  + $tabIndent + $tabIndent)  
        # Disable Automatic Downloads
        Write-Host
        DisplayProcessSubStep " Disable Automatic Downloads " ($tabIndent  + $tabIndent)
        DisplayInfoText "Enable the automatic download of addons when installing a profile" ($tabIndent  + $tabIndent + $tabIndent)
        DisplayPositiveText ">> .\GAMMA_EXT.ps1 -disable automatic-dl" ($tabIndent  + $tabIndent + $tabIndent)      
        # Enable Confirmation Downloads
        Write-Host
        DisplayProcessSubStep " Enable Confirmation Downloads " ($tabIndent  + $tabIndent)
        DisplayInfoText "Enable the confirmation prompt before automatically downloading and addon when installing a profile" ($tabIndent  + $tabIndent + $tabIndent)
        DisplayPositiveText ">> .\GAMMA_EXT.ps1 -enable confirmation-dl" ($tabIndent  + $tabIndent + $tabIndent)  
        # Disable Confirmation Downloads
        Write-Host
        DisplayProcessSubStep " Disable Confirmation Downloads " ($tabIndent  + $tabIndent)
        DisplayInfoText "Disable the confirmation prompt before automatically downloading and addon when installing a profile" ($tabIndent  + $tabIndent + $tabIndent)
        DisplayPositiveText ">> .\GAMMA_EXT.ps1 -disable confirmation-dl" ($tabIndent  + $tabIndent + $tabIndent)  
        # Create Dummy Addon
        Write-Host
        DisplayProcessSubStep " Create Dummy Addon " ($tabIndent  + $tabIndent)
        DisplayInfoText "Create a dummy addon (empty). Useful to avoid downloading huge addons and progress through the installation" ($tabIndent  + $tabIndent + $tabIndent)
        DisplayInfoText "Use this as a temporary workaround, installation will complete but some profile mods will be installed empty as consequence" ($tabIndent  + $tabIndent + $tabIndent)
        DisplayPositiveText ">> .\GAMMA_EXT.ps1 -createdummy `"$param2`" -addon `"<AddonName>`"" ($tabIndent  + $tabIndent + $tabIndent)      
        Write-Host
        Write-Host

    }

    if(!($param1 -eq "moprofiles")){

        DisplayProcessStep " EXT Help Profile Commands "
        Write-Host
        DisplayInfoText "Listing help for profiles related commands " $tabIndent    
        # List Profile Information
        Write-Host
        DisplayProcessSubStep " List Profile Information " ($tabIndent  + $tabIndent)
        DisplayInfoText "List a summary of the profile content " ($tabIndent  + $tabIndent + $tabIndent)
        DisplayPositiveText ">> .\GAMMA_EXT.ps1 -info `"$param2`"" ($tabIndent  + $tabIndent + $tabIndent)
        # List Profile Addons
        Write-Host
        DisplayProcessSubStep " List Profile Addons " ($tabIndent  + $tabIndent)
        DisplayInfoText "List addons used by a profile " ($tabIndent  + $tabIndent + $tabIndent)
        DisplayPositiveText ">> .\GAMMA_EXT.ps1 -listaddons `"$param2`"" ($tabIndent  + $tabIndent + $tabIndent)
        DisplayInfoText "Prints the list of the addons links into a file, for JDownloader use " ($tabIndent  + $tabIndent + $tabIndent)
        DisplayPositiveText ">> .\GAMMA_EXT.ps1 -listaddons `"$param2`" dl" ($tabIndent  + $tabIndent + $tabIndent)
        
        # List Profile Mods
        Write-Host
        DisplayProcessSubStep " List Profile Mods " ($tabIndent  + $tabIndent)
        DisplayInfoText "List mods installed by a profile " ($tabIndent  + $tabIndent + $tabIndent)
        DisplayPositiveText ">> .\GAMMA_EXT.ps1 -listmods `"$param2`"" ($tabIndent  + $tabIndent + $tabIndent)    
        # Verify Profile
        Write-Host
        DisplayProcessSubStep " Verify Profile " ($tabIndent  + $tabIndent)
        DisplayInfoText "Verify the profile installation requirements. Checks also that addon links are still functional " ($tabIndent  + $tabIndent + $tabIndent)
        DisplayPositiveText ">> .\GAMMA_EXT.ps1 -verify `"$param2`"" ($tabIndent  + $tabIndent + $tabIndent)
        DisplayInfoText "Use the `"nodiskspacecheck`" option to skip the verification step - useful if you want bypass install size check for whatever reason" ($tabIndent  + $tabIndent + $tabIndent)
        DisplayPositiveText ">> .\GAMMA_EXT.ps1 -verify `"$param2`" `"nodiskspacecheck`"" ($tabIndent  + $tabIndent + $tabIndent)      
        # Veriu Profile Addons
        Write-Host
        DisplayProcessSubStep " Verify Profile Addons " ($tabIndent  + $tabIndent)
        DisplayInfoText "Verify the profile addon links are still functional " ($tabIndent  + $tabIndent + $tabIndent)
        DisplayPositiveText ">> .\GAMMA_EXT.ps1 -verify `"profileName`" -addon `"addonName`"" ($tabIndent  + $tabIndent + $tabIndent)

        # Install Profile
        Write-Host
        DisplayProcessSubStep " Install Profile " ($tabIndent  + $tabIndent)
        DisplayInfoText "Install a profile that is available in EXT " ($tabIndent  + $tabIndent + $tabIndent)
        DisplayPositiveText ">> .\GAMMA_EXT.ps1 -install `"$param2`"" ($tabIndent  + $tabIndent + $tabIndent)      
        DisplayInfoText "Use the `"nodiskspacecheck`" option to skip the verification step - useful if you want bypass install size check for whatever reason" ($tabIndent  + $tabIndent + $tabIndent)
        DisplayPositiveText ">> .\GAMMA_EXT.ps1 -install `"$param2`" `"nodiskspacecheck`"" ($tabIndent  + $tabIndent + $tabIndent)  
        # Uninstall Profile
        Write-Host
        DisplayProcessSubStep " Uninstall Profile " ($tabIndent  + $tabIndent)
        DisplayInfoText "Uninstall a profile currently installed in MO " ($tabIndent  + $tabIndent + $tabIndent)
        DisplayPositiveText ">> .\GAMMA_EXT.ps1 -uninstall `"$param2`"" ($tabIndent  + $tabIndent + $tabIndent)
        # Update definitions
        Write-Host
        DisplayProcessSubStep " Update definitions " ($tabIndent  + $tabIndent)
        DisplayInfoText "Update addons definitions " ($tabIndent  + $tabIndent + $tabIndent)
        DisplayInfoText "Use it to update the profile addon definitions (download link and addon filename) when these are outdated in the EXT profile" ($tabIndent  + $tabIndent + $tabIndent)        
        DisplayPositiveText ">> .\GAMMA_EXT.ps1 -updatedefinitions `"$param2`" -addon `"<AddonName>`"" ($tabIndent  + $tabIndent + $tabIndent)
        # Create Dummy Addon
        Write-Host
        DisplayProcessSubStep " Create Dummy Addon " ($tabIndent  + $tabIndent)
        DisplayInfoText "Create a dummy addon (empty). Useful to avoid downloading huge addons and progress through the installation" ($tabIndent  + $tabIndent + $tabIndent)
        DisplayInfoText "Use this as a temporary workaround, installation will complete but some profile mods will be installed empty as consequence" ($tabIndent  + $tabIndent + $tabIndent)
        DisplayPositiveText ">> .\GAMMA_EXT.ps1 -createdummy `"$param2`" -addon `"<AddonName>`"" ($tabIndent  + $tabIndent + $tabIndent)                   
        # compile hashes
        Write-Host
        DisplayProcessSubStep " Compiles or updates addons hash in the profile definitions. The profile definitions changes are saved " ($tabIndent  + $tabIndent)
        DisplayInfoText "Compiles or updates addons hashes " ($tabIndent  + $tabIndent + $tabIndent)
        DisplayInfoText "Use it to update the profile addons hashes from the related downloaded archives saved in the `"addons` folder`" " ($tabIndent  + $tabIndent + $tabIndent)        
        DisplayPositiveText ">> .\GAMMA_EXT.ps1 -edit `"$param2`" -hash" ($tabIndent  + $tabIndent + $tabIndent)        
        Write-Host
        # calculate addon hash
        Write-Host
        DisplayProcessSubStep " Calculate the addon hash in the profile definitions. The profile definitions are not updated " ($tabIndent  + $tabIndent)
        DisplayInfoText "Calculate and display the addon hash and other information " ($tabIndent  + $tabIndent + $tabIndent)
        DisplayInfoText "Use it to calculate and display the addon hash from related downloaded archives saved in the `"addons` folder`", displaying also addon size and workspace size " ($tabIndent  + $tabIndent + $tabIndent)        
        DisplayPositiveText ">> .\GAMMA_EXT.ps1 -edit `"$param2`" -addon `"<AddonName>`" -hash" ($tabIndent  + $tabIndent + $tabIndent)         
        Write-Host  
    }

    if(!($param1 -eq "profiles")){
        DisplayProcessStep " EXT Help Installed Profile Commands "
        Write-Host
        DisplayInfoText "Listing help for commands that operates on profiles installed in MO " $tabIndent
        # Install Profile
        Write-Host
        DisplayProcessSubStep " Install Profile " ($tabIndent  + $tabIndent)
        DisplayInfoText "Completely reinstall a profile uninstalling the version currently installed in MO" ($tabIndent  + $tabIndent + $tabIndent)
        DisplayInfoText "Can be used to update an old profile version currently installed in MO with the new version currently available in EXT" ($tabIndent  + $tabIndent + $tabIndent)
        DisplayInfoText "If both version are the same, it simply reinstall the profile to factory settings" ($tabIndent  + $tabIndent + $tabIndent)                  
        DisplayPositiveText ">> .\GAMMA_EXT.ps1 -install `"$param2`"" ($tabIndent  + $tabIndent + $tabIndent)
        # Uninstall Profile
        Write-Host
        DisplayProcessSubStep " Uninstall Profile " ($tabIndent  + $tabIndent)
        DisplayInfoText "Uninstall a profile currently installed in MO " ($tabIndent  + $tabIndent + $tabIndent)
        DisplayPositiveText ">> .\GAMMA_EXT.ps1 -uninstall `"$param2`"" ($tabIndent  + $tabIndent + $tabIndent)        
        # Update Profile
        Write-Host
        DisplayProcessSubStep " Update Profile " ($tabIndent  + $tabIndent)
        DisplayInfoText "Update a profile currently installed in MO with the version currently available in EXT" ($tabIndent  + $tabIndent + $tabIndent)
        DisplayInfoText "It can be re-run at will, it will simply redo the latest update" ($tabIndent  + $tabIndent + $tabIndent)        
        DisplayPositiveText ">> .\GAMMA_EXT.ps1 -update `"$param2`"" ($tabIndent  + $tabIndent + $tabIndent)
        DisplayInfoText "Use the `"offline`" option to skip the automatic download of addons required in the update - you must have download the addons by yourself " ($tabIndent  + $tabIndent + $tabIndent)        
        DisplayPositiveText ">> .\GAMMA_EXT.ps1 -update `"$param2`"offline" ($tabIndent  + $tabIndent + $tabIndent)
        DisplayInfoText "Use the `"local`" option to use the local ext profile definitions (instead of downloading and updating from the latest in the repository)" ($tabIndent  + $tabIndent + $tabIndent)        
        DisplayPositiveText ">> .\GAMMA_EXT.ps1 -update `"$param2`"local" ($tabIndent  + $tabIndent + $tabIndent)
        DisplayInfoText " or with both options, separated by comma" ($tabIndent  + $tabIndent + $tabIndent)
        DisplayPositiveText ">> .\GAMMA_EXT.ps1 -update `"$param2`" `"offline,local`"" ($tabIndent  + $tabIndent + $tabIndent)              
        # Update Profile Mod
        Write-Host
        DisplayProcessSubStep " Update Profile Mod " ($tabIndent  + $tabIndent)
        DisplayInfoText "Reinstall a profile mod currently installed in MO" ($tabIndent  + $tabIndent + $tabIndent)
        DisplayInfoText "Useful to restore the installed profile mod to factory settings" ($tabIndent  + $tabIndent + $tabIndent)        
        DisplayPositiveText ">> .\GAMMA_EXT.ps1 -update `"$param2`" -mod `"<ModName>`"" ($tabIndent  + $tabIndent + $tabIndent)  
        # List changelogs
        Write-Host
        DisplayProcessSubStep " List Profile changelog  " ($tabIndent  + $tabIndent)
        DisplayInfoText "List the chagelog of a particular profile version, if no version is provided it list the changelog from the latest version instead" ($tabIndent  + $tabIndent + $tabIndent)
        DisplayInfoText "Useful to check what an update is bringing" ($tabIndent  + $tabIndent + $tabIndent)        
        DisplayInfoText "version must be a number, e.g. 2,12, etc" ($tabIndent  + $tabIndent + $tabIndent)        
        DisplayPositiveText ">> .\GAMMA_EXT.ps1 -changelog `"$param2`" <version>" ($tabIndent  + $tabIndent + $tabIndent)          
        # Apply Settings
        Write-Host
        DisplayProcessSubStep " Apply Settings " ($tabIndent  + $tabIndent)
        DisplayInfoText "Applies the settings of the currently selected profile in MO to the Anomaly folders (bin/appdata) and MO overwrite folder" ($tabIndent  + $tabIndent + $tabIndent)
        DisplayInfoText "Implicitly uses the profile selected in MO to copy the content from GAMMA-EXT/settings/<profileName> into the Anomaly folders" ($tabIndent  + $tabIndent + $tabIndent)        
        DisplayPositiveText ">> .\GAMMA_EXT.ps1 -apply_settings" ($tabIndent  + $tabIndent + $tabIndent)
        # Save Settings
        Write-Host
        DisplayProcessSubStep " Save Settings " ($tabIndent  + $tabIndent)
        DisplayInfoText "Save the settings currently stored in the Anomaly folders (bin/appdata) to the GAMMA-EXT/settings/<profileName> folder" ($tabIndent  + $tabIndent + $tabIndent)
        DisplayInfoText "Use it after changing any of the main menu settings or MCM settings while in the game. Only run it after exiting the game and if you made the aforementioned changes" ($tabIndent  + $tabIndent + $tabIndent)        
        DisplayInfoText "Implicitly uses the profile selected in MO to copy the content of the Anomaly folders into GAMMA-EXT/settings/<profileName> " ($tabIndent  + $tabIndent + $tabIndent)        
        DisplayPositiveText ">> .\GAMMA_EXT.ps1 -save_settings" ($tabIndent  + $tabIndent + $tabIndent)
        # Clear Settings
        Write-Host
        DisplayProcessSubStep " Clear Settings " ($tabIndent  + $tabIndent)
        DisplayInfoText "Remove any profile settings from the Anomaly folders (bin/appdata) and MO overwrite folder" ($tabIndent  + $tabIndent + $tabIndent)
        DisplayInfoText "Use it to restore the Anomaly folders to vanilla settings" ($tabIndent  + $tabIndent + $tabIndent)        
        DisplayPositiveText ">> .\GAMMA_EXT.ps1 -clear_settings" ($tabIndent  + $tabIndent + $tabIndent)        
        # Synch Profile
        Write-Host
        DisplayProcessSubStep " Synch Profile " ($tabIndent  + $tabIndent)
        DisplayInfoText "Synch the installed profile modlist to the latest GAMMA modlist" ($tabIndent  + $tabIndent + $tabIndent)
        DisplayInfoText "Implicitly uses the profile selected in MO" ($tabIndent  + $tabIndent + $tabIndent)        
        DisplayPositiveText ">> .\GAMMA_EXT.ps1 -synch" ($tabIndent  + $tabIndent + $tabIndent)
        DisplayInfoText "Use it with the `"-all`" flag, after performing a GAMMA update, to synchronize all the installed EXT profile with the latest GAMMA modlist's changes" ($tabIndent  + $tabIndent + $tabIndent)        
        DisplayPositiveText ">> .\GAMMA_EXT.ps1 -synch -all" ($tabIndent  + $tabIndent + $tabIndent)
        # Reset Profile
        Write-Host
        DisplayProcessSubStep " Reset Profile " ($tabIndent  + $tabIndent)
        DisplayInfoText "Reset the installed profile modlist to factory settings" ($tabIndent  + $tabIndent + $tabIndent)
        DisplayInfoText "Use it to restore the installed profile modlist to the installation state" ($tabIndent  + $tabIndent + $tabIndent)        
        DisplayInfoText "Implicitly uses the profile selected in MO" ($tabIndent  + $tabIndent + $tabIndent)        
        DisplayPositiveText ">> .\GAMMA_EXT.ps1 -reset" ($tabIndent  + $tabIndent + $tabIndent)
        # Save Profile
        Write-Host
        DisplayProcessSubStep " Save Profile " ($tabIndent  + $tabIndent)
        DisplayInfoText "Saves changes made to the installed profile modlist" ($tabIndent  + $tabIndent + $tabIndent)
        DisplayInfoText "Use it to save to the installed profile modlist any new installed mods and their position in the modlist" ($tabIndent  + $tabIndent + $tabIndent)        
        DisplayInfoText "Implicitly uses the profile selected in MO" ($tabIndent  + $tabIndent + $tabIndent)        
        DisplayPositiveText ">> .\GAMMA_EXT.ps1 -save" ($tabIndent  + $tabIndent + $tabIndent)
        # Restore Profile Settings
        Write-Host
        DisplayProcessSubStep " Restore Profile Settings " ($tabIndent  + $tabIndent)
        DisplayInfoText "Restore installed profile settings to factory settings" ($tabIndent  + $tabIndent + $tabIndent)
        DisplayInfoText "Use it to restore an installed profile settings (GAMMA-EXT/settings/<ProfileName>) if they becomes corrupted or lost/deleted" ($tabIndent  + $tabIndent + $tabIndent)               
        DisplayPositiveText ">> .\GAMMA_EXT.ps1 -restore `"$param2`" settings" ($tabIndent  + $tabIndent + $tabIndent)
        # Restore Profile Modlists
        Write-Host
        DisplayProcessSubStep " Restore Profile Modlists " ($tabIndent  + $tabIndent)
        DisplayInfoText "Restore installed profiles (including kits) modlists to factory settings" ($tabIndent  + $tabIndent + $tabIndent)
        DisplayInfoText "Use it to restore an installed profile modlist and all related modlists (e.g. kits) in case they becomes corrupted or lost/deleted " ($tabIndent  + $tabIndent + $tabIndent)               
        DisplayPositiveText ">> .\GAMMA_EXT.ps1 -restore `"$param2`" moprofile" ($tabIndent  + $tabIndent + $tabIndent)                     
        # Clone Profile
        Write-Host
        DisplayProcessSubStep " Clone Profile " ($tabIndent  + $tabIndent)
        DisplayInfoText "Clone from an EXT profile or GAMMA default to create a new profile in MO which is a clone of the original" ($tabIndent  + $tabIndent + $tabIndent)
        DisplayInfoText "The cloned profile can use any EXT commands like, synch, save, reset, etc." ($tabIndent  + $tabIndent + $tabIndent)
        DisplayInfoText "Use it if you want to customize an installed EXT profile or the GAMMA one and make use of EXT commands with the new custom profile" ($tabIndent  + $tabIndent + $tabIndent)
        DisplayInfoText "Mod Organizer must be closed in order to use the clone command" ($tabIndent  + $tabIndent + $tabIndent)     
        DisplayInfoText "Prompts to enter the name of the new profile clone" ($tabIndent  + $tabIndent + $tabIndent)        
        DisplayPositiveText ">> .\GAMMA_EXT.ps1 -clone `"$param2`"" ($tabIndent  + $tabIndent + $tabIndent)
        DisplayInfoText "Using the command without specifying the profile from which to clone, it will use the GAMMA profile as the clone source" ($tabIndent  + $tabIndent + $tabIndent)        
        DisplayPositiveText ">> .\GAMMA_EXT.ps1 -clone" ($tabIndent  + $tabIndent + $tabIndent)                                                                          
    }    
}
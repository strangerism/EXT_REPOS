this patch is to make this mod compatible with Athi https://github.com/andtheherois/3DSS-A-545-


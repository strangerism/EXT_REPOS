//=================================================================================================
//Mip Fog for STALKER Anomaly 
//Inspired by Uncharted 4
//=================================================================================================
#define HEIGHTFOGOFFSET -0.25
#define HEIGHTFOGSCALE 0.1 //0.05

#define FOGMAXMIP 1
#define FOGMAXSHARPNESS 0.125
#define FOGROUGHCURVE 5.0

#define FOGDENSITY 0.5
#define HEIGHTFOGDENSITY 0.5

#define MIPFOGAMOUNT 1.0
#define SUNFOGAMOUNT 0.5
//=================================================================================================

float Calc_Exponent(float a)
{
	return 1 / (pow(2, a));
}

float Calc_Height(float3 wpos)
{
	float Height = HEIGHTFOGSCALE * wpos.y + HEIGHTFOGOFFSET;
	Height = Height * HEIGHTFOGDENSITY;
	Height = exp2(-Height);
	return Height;
}

float Calc_FinalFog(float fog, float height)
{
	float envMax = max(0.01, max(env_color.r, max(env_color.g, env_color.b))) * 0.5; //halfed to match brightness
	float fogMin = min(fog_color.r, min(fog_color.g, fog_color.b));
	
	float density = abs(fog_params.x); //0.25
	density = fogMin/envMax;
	density *= FOGDENSITY;
	float Fog = Calc_Exponent(fog * height * density);
	return saturate(1 - Fog);
}

float3 Calc_SunFog(float3 pos, float3 fog, float3 fogrough)
{
	float3 SunFog = saturate(dot(normalize(Ldynamic_dir), -normalize(pos)));

	float a = RoughToGlossExp(fogrough);
	SunFog = D_Blinn(a, SunFog)/PI;
	
	float3 FogTint = SRGBToLinear(Ldynamic_color.rgb);
	
	return SunFog * FogTint * SUNFOGAMOUNT;
}

float3 Calc_MipFog(float3 sky, float3 fog, float3 fogrough)
{
	sky = normalize(sky);
	float3 nSquared = sky * sky;
	
	//cubemap projection
	float3 skyabs = abs(sky);
	float skymax = max(skyabs.x, max(skyabs.y, skyabs.z));
	sky	  /= skymax;
	if (sky.y < 0.999) 
	sky.y = sky.y*2-1;	//fake remapping 
	
	float FogMip = fogrough * CUBE_MIPS;
	
	//srgb tint
	float3 NearTint = env_color.rgb;
	float3 FarTint = fog_color.rgb;// * 1.7; //match sky
	NearTint = min(env_color.rgb, fog_color.rgb);
	//FarTint = max(env_color.rgb, fog_color.rgb);
	float3 FogTint = lerp(NearTint, FarTint, fog); //env for close, fog for far
	
	float3 s0 = env_s0.SampleLevel(smp_base, sky, FogMip);
	float3 s1 = env_s1.SampleLevel(smp_base, sky, FogMip);
	float3 MipFog = SkyBlendTint(s0, s1, env_color.w, FogTint);
	
	//linear cubemap
	MipFog = SRGBToLinear(MipFog);	

	return MipFog * MIPFOGAMOUNT;
}

float3 Calc_Fog(float3 pos, float3 color)
{	
	color = SRGBToLinear(color.rgb);
	
	//view to world space
	float3 sky = mul(m_inv_V, pos );
	float3 wpos = sky + eye_position;

	float distance = length(pos);

	//float fog = max(0.0, distance * fog_params.w + fog_params.x);
	float fog = max(0.0, (distance * fog_params.w) / (1 - fog_params.x));
	float fogsat = saturate(fog);

	float height = Calc_Height(wpos);

	float FinalFog = Calc_FinalFog(fog, height);

	//float fogrough = 1 - fogsat;
	//fogrough = pow(fogrough , FOGROUGHCURVE);
	//fogrough = lerp(1 - FOGMAXSHARPNESS, 1, fogrough);
	
	//reverse brdf to get specular power
	float gloss = fogsat*2;
	gloss = 8.0*gloss/0.04;
	//convert specular power to UE4 roughness
	float fogrough = saturate(pow(2.0/(gloss+2.0),0.25));
	fogrough = pow(fogrough , FOGROUGHCURVE);
	fogrough = lerp(1 - FOGMAXSHARPNESS, 1, fogrough);
	
	float3 MipFog = Calc_MipFog(sky, fogsat, fogrough);
	float3 SunFog = Calc_SunFog(pos, fogsat, fogrough);
	
	float3 FogColor = MipFog + SunFog;
	
	//fog blend
	float3 FogBlend = FinalFog; 
	
	//fog alpha
	float fogalpha = fogsat * fogsat;
	FogBlend *= 1 - fogalpha; 
	FogBlend += fogalpha; 
	
	float3 Final = lerp(color, FogColor, FogBlend);
	Final = LinearTosRGB(Final);
	
	return Final;
}
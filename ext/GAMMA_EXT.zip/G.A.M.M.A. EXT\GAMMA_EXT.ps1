param (
    [Parameter(Mandatory = $false)][string]$profileName,
    # secondParam can be addonName/modName/options
    [Parameter(Mandatory = $false)][string]$secondParam,
    [Parameter(Mandatory = $false)][string]$thirdParam,    
    [Parameter(Mandatory = $false)][switch]$info,
    [Parameter(Mandatory = $false)][switch]$install,
    [Parameter(Mandatory = $false)][switch]$uninstall,
    [Parameter(Mandatory = $false)][switch]$listprofiles,
    [Parameter(Mandatory = $false)][switch]$listaddons,
    [Parameter(Mandatory = $false)][switch]$listmods,
    [Parameter(Mandatory = $false)][switch]$verify,
    [Parameter(Mandatory = $false)][switch]$reset,
    [Parameter(Mandatory = $false)][switch]$synch,
    [Parameter(Mandatory = $false)][switch]$save,
    [Parameter(Mandatory = $false)][switch]$export,
    [Parameter(Mandatory = $false)][switch]$share,
    [Parameter(Mandatory = $false)][switch]$add,
    [Parameter(Mandatory = $false)][switch]$remove,
    [Parameter(Mandatory = $false)][switch]$switch_settings,
    [Parameter(Mandatory = $false)][switch]$apply_settings,
    [Parameter(Mandatory = $false)][switch]$save_settings,
    [Parameter(Mandatory = $false)][switch]$clear_settings,    
    [Parameter(Mandatory = $false)][switch]$test,
    [Parameter(Mandatory = $false)][switch]$debuginfo,
    # [Parameter(Mandatory = $false)][switch]$full,
    [Parameter(Mandatory = $false)][switch]$anomaly,
    [Parameter(Mandatory = $false)][switch]$mo,
    [Parameter(Mandatory = $false)][switch]$moini,
    [Parameter(Mandatory = $false)][switch]$moprofiles,
    [Parameter(Mandatory = $false)][switch]$dev,
    [Parameter(Mandatory = $false)][switch]$force,
    [Parameter(Mandatory = $false)][switch]$short,
    [Parameter(Mandatory = $false)][switch]$buildkits,
    [Parameter(Mandatory = $false)][switch]$update,  
    [Parameter(Mandatory = $false)][switch]$mod,
    [Parameter(Mandatory = $false)][switch]$addon,
    [Parameter(Mandatory = $false)][switch]$clone,
    [Parameter(Mandatory = $false)][switch]$restore,
    [Parameter(Mandatory = $false)][switch]$moprofile,
    [Parameter(Mandatory = $false)][switch]$settings,
    [Parameter(Mandatory = $false)][switch]$enable,
    [Parameter(Mandatory = $false)][switch]$disable,
    [Parameter(Mandatory = $false)][switch]$getprofiles,
    [Parameter(Mandatory = $false)][switch]$updatedefinitions,
    [Parameter(Mandatory = $false)][switch]$createdummy,
    [Parameter(Mandatory = $false)][switch]$help,
    [Parameter(Mandatory = $false)][switch]$make,
    [Parameter(Mandatory = $false)][switch]$edit,
    [Parameter(Mandatory = $false)][switch]$hash,
    [Parameter(Mandatory = $false)][switch]$strict,
    [Parameter(Mandatory = $false)][switch]$changeLog,
    [Parameter(Mandatory = $false)][switch]$purge,
    [Parameter(Mandatory = $false)][switch]$all
)

. ".\ext\Globals.ps1"
. ".\ext\Workspace.ps1"
. ".\ext\Profiles.ps1"
. ".\ext\CustomMods.ps1"
. ".\ext\Addons.ps1"
. ".\ext\ModMetaIni.ps1"
. ".\ext\SelectModGamedata.ps1"
. ".\ext\Settings.ps1"
. ".\ext\SimpleUi.ps1"
. ".\ext\GAMMA_Profile_Manager.ps1"
. ".\ext\GAMMA_Settings_Manager.ps1"
. ".\ext\linked-list\LinkedList.ps1"
. ".\ext\linked-list\LinkedListNode.ps1"
. ".\ext\linked-list\utils\comparator\Comparator.ps1"
. ".\ext\Downloads.ps1"
. ".\ext\ExtIni.ps1"
. ".\ext\Help.ps1"

# $Global:modMetaIni = [ModMetaIni]::new()

function DisplayInfo {
    param (
        [Parameter(Mandatory = $true, Position = 0)]
        $profileName
    )
    
    $profileDefinitions = GetProfileDefinitions $profileName

    if (!$profileDefinitions){
        PromptErrorBeforeExit " Could not find profile definitions "
    }

    DisplayProfileSummary $profileDefinitions
    Write-Host
    DisplayHeadingMessage " Mods installed "
    foreach ($mod in $profileDefinitions.customMods){

        if (($mod.modName.EndsWith('_separator')) -eq $False){
            DisplayModSummary $mod
        }
    }
    $highlightMessage = $false
    DisplayInstallCompletionMessage $profileDefinitions $highlightMessage
    Write-Host
    $profilesInMO = Get-ChildItem -Path $Global:pathToMOProfiles -Directory
    if ($profilesInMO | Where-Object {$_.Name -eq $profileName}){
        DisplayNoticeMessage ">>> This profile appears to be already installed"
    }
    Write-Host
    DisplayNoticeMessage " Commands available: "
    DisplayEligibleCommands $profileDefinitions.profileName
}
function ListProfiles {

    DisplayBanner $Global:ListProfilesBanner

    $profiles = Get-ChildItem -Path "profiles/" -Directory -Name
    $profilesInMO = Get-ChildItem -Path $Global:pathToMOProfiles -Directory
    # Write-Host "Listing available profiles" -ForegroundColor DarkBlue
    Write-Host
    foreach ($profile in $profiles){

        if ($profile -eq ".old" -or $profile -eq "EXT"){
            continue
        }
        
        $profileDefinitions = GetProfileDefinitions($profile)

        if ($null -eq $profileDefinitions){
            PromptErrorBeforeExit " Could not find profile definitions "
        }

        DisplayProfileSummary $profileDefinitions
        DisplayEligibleCommands $profileDefinitions.profileName

        if ($profilesInMO | Where-Object {$_.Name -eq $profile}){
            DisplayNoticeMessage ">>> This profile appears to be already installed"
        }
        Write-Host
    }
    
}
function ListAddon{

    param (
        [Parameter(Mandatory = $true, Position = 0)]
        $profileName,
        [Parameter(Mandatory = $false, Position = 1)]
        $addonName        
    )

    if ($profileName -eq ""){
        PromptErrorBeforeExit "Cannot list a custom profile addons unless a profilename is specified - e.g. -listaddons -profilename testprofile"
    }
    $profileDefinitions = GetProfileDefinitions $profileName

    if ($null -eq $profileDefinitions){
        PromptErrorBeforeExit " Could not find profile definitions "
    }
    
    # loop in $profileDefinitions.addons to find the addon with the name $addonName
    foreach ($addon in $profileDefinitions.addons){
        if ($addon.addonName -eq $addonName){
            $addonPath = GetAddonResourcePath $addon
            if (Test-Path -LiteralPath $addonPath){
                DisplayAddonName $addon.addonName $tabIndent
            }else{
                DisplayElementMissingMessage $addon.addonName " is not available, download the addon file `"$($addon.resourceFilename)`" and save it in the addons folder" "WARNING" $tabIndent
                Write-Host
            }
            
            DisplayInfoText "Addon Web Page $($addon.addonUrl)" ($tabIndent  + $tabIndent)
            Write-Host
            DisplayInfoText "Addon filename `"$($addon.resourceFilename)`"" ($tabIndent  + $tabIndent)
            Write-Host        
            DisplayNoticeText "Download link --> $($addon.fileUrl)" ($tabIndent  + $tabIndent)
            Write-Host
            if ($addon.info){
                DisplayNoticeMessage $addon.info ($tabIndent  + $tabIndent)
                Write-Host
            }
    
        }
    }
    Write-Host
    DisplayNoticeMessage " Commands available: "
    DisplayEligibleCommands $profileName
    return
}
function ListAddons{

    param (
        [Parameter(Mandatory = $true, Position = 0)]
        $profileName,
        [Parameter(Mandatory = $false, Position = 1)]
        $options        
    )

    if ($profileName -eq ""){
        PromptErrorBeforeExit "Cannot list a custom profile addons unless a profilename is specified - e.g. -listaddons -profilename testprofile"
    }
    $profileDefinitions = GetProfileDefinitions $profileName

    if ($null -eq $profileDefinitions){
        PromptErrorBeforeExit " Could not find profile definitions "
    }

    if ($null -ne $options){
        $Global:optionsList = $options -split ","
    }

    if ($Global:optionsList -contains "dl"){
        Write-Host

        # Initialize an array to store the file URLs
        $fileUrls = @()

        # Process each addon in $profileDefinitions.addons
        foreach ($addon in $profileDefinitions.addons) {

            # Assuming each addon has a property 'fileUrl'
            if ($addon.PSObject.Properties['fileUrl']) {

                if ($addon.fileUrl.StartsWith('https://www.moddb.com')){
                    $fileUrl = $addon.addonUrl.Trim()
                    $fileUrls += $fileUrl
                }else{
                    $fileUrl = $addon.fileUrl.Trim()
                    $fileUrls += $fileUrl
                }
            }
        }

        # Write the file URLs to AddonsDownloadLinks.txt
        $outputPath = $profileDefinitions.profileName + " Addons Download Links.txt"
        $fileUrls | Out-File -FilePath $outputPath -Encoding utf8

        DisplayInfoMessage "The profiles addons download links have been saved to $outputPath"

    }elseif ($Global:optionsList -contains "page"){

        if ($Global:browserdl){
            foreach ($addon in $profileDefinitions.addons) {
                if($addon.addonUrl){
                    DownloadWithBrowser $addon.addonUrl
                }
            }
        }else{
            DisplayWarningMessage "You need to enable Browser Downloads to run this command "
            Write-Host
            DisplayInfoText "to enable Browser Downloads" ($tabIndent)
            Write-Host
            DisplayPositiveText "run > .\GAMMA_EXT.ps1 -enable browser-dl" ($tabIndent )             
        }

    }    
    else{
    
        DisplayInfoText "Listing $profileName profile addons"
        Write-Host
        DisplayInfoMessage " Beware! Addons file urls might change overtime in the respective addons webpage " $tabIndent
        Write-Host
        DisplayInfoText "Download link could become obsolete and this profile might stop working. Contact the creator of this profile [$($profileDefinitions.profileCreator)]" ($tabIndent + $tabIndent)
        Write-Host
        
    
        foreach ($addon in $profileDefinitions.addons){
            $addonPath = GetAddonResourcePath $addon
            if (Test-Path -LiteralPath $addonPath){
                DisplayAddonName $addon.addonName $tabIndent
            }else{
                DisplayElementMissingMessage $addon.addonName " is not available, download the addon file `"$($addon.resourceFilename)`" and save it in the addons folder" "WARNING" $tabIndent
                Write-Host
            }
            
            DisplayInfoText "Addon Web Page $($addon.addonUrl)" ($tabIndent  + $tabIndent)
            Write-Host
            DisplayInfoText "Addon filename `"$($addon.resourceFilename)`"" ($tabIndent  + $tabIndent)
            Write-Host        
            DisplayNoticeText "Download link --> $($addon.fileUrl)" ($tabIndent  + $tabIndent)
            Write-Host
            if ($addon.info){
                DisplayNoticeMessage $addon.info ($tabIndent  + $tabIndent)
                Write-Host
            }
    
        }
        Write-Host
        DisplayNoticeMessage " Commands available: "
        DisplayEligibleCommands $profileName
    }
}
function ListMods($profileName){

    if ($profileName -eq ""){
        PromptErrorBeforeExit "cannot list a custom profile mods unless a profilename is specified - e.g. -listmods -profilename testprofile"
    }

    DisplayInfoText "Listing $profileName profile mods"
    Write-Host
    $profileDefinitions = GetProfileDefinitions $profileName

    if ($null -eq $profileDefinitions){
        PromptErrorBeforeExit " Could not find profile definitions "
    }

    foreach ($mod in $profileDefinitions.customMods){

        DisplayModSummary $mod
    }
    Write-Host
    DisplayNoticeMessage " Commands available: "
    DisplayEligibleCommands $profileName
}
function VerifyParentDependency {
    param (
        $profileDefinitions,
        $verification
    )

    DisplayProcessStep  " Checking profile parent dependency "
    if($profileDefinitions.parentProfile){
        Write-Host
        DisplayInfoMessage " This profile depends on a parent profile " $tabIndent
        Write-Host
        DisplayHeadingMessage $($profileDefinitions.parentProfile.name) ($tabIndent + $tabIndent)
        DisplayHeadingMessage "Version $($profileDefinitions.parentProfile.version)" ($tabIndent + $tabIndent)
        Write-Host
        # check parent is installed in EXT and has same version
        $parentDefinitions = GetProfileDefinitions $profileDefinitions.parentProfile.name
        DisplayProcessStep  " Checking profile parent availability "
        Write-Host
        DisplayInfoText "Parent currently available in EXT" $tabIndent
        Write-Host
        DisplayHeadingMessage $($parentDefinitions.profileName) ($tabIndent + $tabIndent)
        DisplayHeadingMessage "Version $($parentDefinitions.version)" ($tabIndent + $tabIndent)
        if ($parentDefinitions.version -eq $profileDefinitions.parentProfile.version){
            Write-Host
            DisplayInfoMessage " >> Both version matches. " $tabIndent        
        }else{
            Write-Host
            $message = " The parent profile available in EXT is not same version, please update parent profile first "
            DisplayWarningMessage $message 
            $verification.isVerifed = $False
            $failureLog = [PSCustomObject]@{
                type = "parentdep"
                target = $null
                error = $null
                message = @(
                    $message
                )
            }            
            $verification.failureLogs += $failureLog
        }
    }else{
        Write-Host
        DisplayPositiveText " >> This profile has no parent " $tabIndent
    }
}
function VerifyExtCompatibility{
    param (
        $profileDefinitions
    )    
    DisplayProcessStep  " Checking profile compatibility with installed EXT "
    DisplayProcessStepText "A profile can be installed safely if both EXT versions matches or installed EXT version is greater " $tabIndent
    # it will terminate if version requirement is not meet
    CheckIfExtVersionCompatible $profileDefinitions
    Write-Host
    DisplayPositiveText ">> profile is compatible with EXT" $tabIndent
}

function VerifyProfileIsInstalled {
    param (
        $profileDefinitions
    )
    # check if profile with same name is installed already in MO
    DisplayProcessStep  " Checking installed profiles "
    Write-Host
    DisplayProcessStepText "This profile could either be already installed in Mod Organizer or a similar named profile was created" $tabIndent
    $profilePath = "$Global:pathToMOProfiles/$($profileDefinitions.profileName)"
    if (Test-Path -Path $profilePath) {
        Write-Host
        DisplayNoticeText ">> A profile already exists in GAMMA's ModOrganizer with the same name: $($profileDefinitions.profileName)" $tabIndent
        Write-Host
        DisplayInfoMessage " If you are installing a new version of the same profile, or reinstalling, you can IGNORE these warnings " $tabIndent
        Write-Host
    }else{
        Write-Host
        DisplayPositiveText ">> no profile with this name exists in GAMMA's ModOrganizer" $tabIndent
    }
    # check if profile mods are installed already in MO
    DisplayProcessStep  " Checking mod list in GAMMA's ModOrganizer "
    DisplayProcessStepText "The profile mods are checked if they are already installed in your GAMMA's ModOrganizer" $tabIndent
    Write-Host
    $modsList = Get-ChildItem -Directory -Path $Global:pathToMOMods -Name
    $modsClear = $True
    foreach ($customMod in $profileDefinitions.customMods){

        foreach ($mod in $modsList){
            
            if ($customMod.modName -eq $mod){
                DisplayElementMissingMessage $customMod.modName " already exists"  "NOTICE" $tabIndent
                Write-Host
                $modsClear = $False
            }
        }
    }
    if ($modsClear){
        DisplayPositiveText ">> no mods that conflicts do exists in GAMMA's ModOrganizer" $tabIndent
    }else{
        DisplayInfoMessage " If you are installing a new version of the same profile, or reinstalling, you can IGNORE these warnings " $tabIndent
    }    
}

function CheckDowloadableAddon{
    param (
        $addon,
        $WebClient,
        $verification
    )

    $addonFileOnlineCheck = CheckAddon $addon
    # verification is running for install - we have the addon file already but what about the version in the cloud? is it different, should we update it?
    if ($false -eq $addonFileOnlineCheck.result){
        if ($addonFileOnlineCheck.reason -eq "version"){
            DisplayProcessSubStep " Downloadable Addon New Version " ($tabIndent  + $tabIndent)
            DisplayNoticeText "You have already a downloaded version for this addon but it appears a new version is available online" ($tabIndent  + $tabIndent)
            DisplayNoticeText "BEWARE Downloading and installing with the new addon version might cause issues" ($tabIndent  + $tabIndent)
        }elseif($addonFileOnlineCheck.reason -eq "hash"){
            DisplayNoticeText "You have already downloaded the same version for this addon but the file hash appears different from the one online" ($tabIndent  + $tabIndent)
            DisplayNoticeText "This could mean the addon file you have is corrupted or that the addon file online was updated but it retained the same filename/version" ($tabIndent  + $tabIndent)
            DisplayNoticeText "Redownloading the addon should be safe, eventually you can restore it from the backups folder" ($tabIndent  + $tabIndent)
        }
        $Prompt = "Do you want to download and replace the old one? [The old version will be moved in $pathToEXTBackups]"
        $Choices = [System.Management.Automation.Host.ChoiceDescription[]] @("&Yes", "&No")
        $Default = 1
        Write-Host
        # Prompt for the choice
        $Choice = $host.UI.PromptForChoice($Title, $Prompt, $Choices, $Default)
        # Action based on the choice
        switch($Choice)
        {
            0 { 
                BackupAddon $addon
                DownloadAddon $addon $WebClient $verification
            }
            1 {
            }
        }                 
    }elseif ($null -ne $addon.alwaysDl -and $addon.alwaysDl -eq $true){
        # the addon file in the cloud is the same as they one we have downloaded but what if we are forced to download it? This is a contingency when addon filenames do not change regardless of updates
        # this enforcement is risky, ideally we should do a MD5 check
        DownloadAddon $addon $WebClient $verification
    }elseif (!(Test-Path -Path ([WildcardPattern]::Escape($addonPath))) -or !(Get-Item ([WildcardPattern]::Escape($addonPath))).length -gt 0kb){
        # the addon resource file does not exist - we should download it
        DownloadAddon $addon $WebClient $verification
    } 
}

function VerifyAddonsAvailability {
    param (
        $profileDefinitions,
        $verification
    )
    $WebClient = New-Object System.Net.WebClient

    DisplayProcessStep " Checking addons availability "
    Write-Host
    DisplayInfoText " Verify will check your addons folder and download any missing addons if you are installing the profile " $tabIndent
    Write-Host
    DisplayInfoMessage " Beware! Addons file urls might change overtime in the respective addons webpage (e.g. Moddb/gdrive) " $tabIndent
    Write-Host
    DisplayInfoText "Download link could become obsolete and this profile might stop working" ($tabIndent + $tabIndent)
    Write-Host
    DisplayInfoText "If that happens you can browse to the Addon Url page and look for the new/updated download link " ($tabIndent + $tabIndent)
    DisplayInfoText "then modify the addon definitions with the command " ($tabIndent + $tabIndent)
    Write-Host 
    DisplayPositiveText "run > .\GAMMA_EXT.ps1 -updatedefinitions -addon `"addonName`"" ($tabIndent + $tabIndent)
    Write-Host 
    DisplayInfoText "after updating the addon definitions run install again" ($tabIndent + $tabIndent)
    Write-Host    
    if ($Global:autodl){
        DisplayInfoMessage " You have Automatic Downloads enabled " $tabIndent
        Write-Host
        DisplayInfoText "to disable this feature" ($tabIndent + $tabIndent)
        Write-Host
        DisplayPositiveText "run > .\GAMMA_EXT.ps1 -disable automatic-dl" ($tabIndent + $tabIndent)        
    }else{
        DisplayInfoMessage " You have Automatic Downloads disabled " $tabIndent
        Write-Host
        DisplayInfoText "to enable this feature" ($tabIndent + $tabIndent)
        Write-Host
        DisplayPositiveText "run > .\GAMMA_EXT.ps1 -enable automatic-dl" ($tabIndent + $tabIndent)        
    }
    Write-Host
    if($Global:autodl -eq $true){
        if ($Global:confirmdl){
            DisplayInfoMessage " You have Confirmation for Downloads enabled " $tabIndent
            Write-Host
            DisplayInfoText "to disable this feature" ($tabIndent + $tabIndent)
            Write-Host
            DisplayPositiveText "run > .\GAMMA_EXT.ps1 -disable confirmation-dl" ($tabIndent + $tabIndent)            
        }else{
            DisplayInfoMessage " You have Confirmation for Downloads disabled " $tabIndent
            Write-Host
            DisplayInfoText "to enable this feature" ($tabIndent + $tabIndent)
            Write-Host
            DisplayPositiveText "run > .\GAMMA_EXT.ps1 -enable confirmation-dl" ($tabIndent + $tabIndent)            
        }  
    }
    Write-Host
    if ($Global:browserdl){
        DisplayInfoMessage " You have Browser Downloads enabled " $tabIndent
        Write-Host
        DisplayInfoText "to disable this feature" ($tabIndent + $tabIndent)
        Write-Host
        DisplayPositiveText "run > .\GAMMA_EXT.ps1 -disable browser-dl" ($tabIndent + $tabIndent)            
    }else{
        DisplayInfoMessage " You have Browser Downloads disabled " $tabIndent
        Write-Host
        DisplayInfoText "to enable this feature" ($tabIndent + $tabIndent)
        Write-Host
        DisplayPositiveText "run > .\GAMMA_EXT.ps1 -enable browser-dl" ($tabIndent + $tabIndent)            
    }  
    # loop through the addons and verify whose is missing and download them 
    foreach ($addon in $profileDefinitions.addons){
        $addonPath = [WildcardPattern]::Escape($(GetAddonResourcePath $addon))
        if ( (Test-Path -Path $addonPath) -and ((Get-Item $addonPath).length -gt 0kb) ){
            # the addon resource file already exists (previously downloaded) - we should check if the version in the cloud is different??
            DisplayAvailableAddon $addon.addonName $tabIndent
            # Write-Host
            # if verification is called directly from shell command the run the verify download link to check if the addon download url is live
            if ($verification.isForInstall -eq $false){
                # DisplayProcessSubStep " Verifying Download Link " ($tabIndent  + $tabIndent)
                VerifyAddonLink $addon $WebClient $verification
                $null = CheckAddon $addon
            }else{
                CheckDowloadableAddon $addon $WebClient $verification
            }
        }else{
            # the addon resource file does not exist - we should download it
            Write-Host
            if($Global:autodl){
                DisplayElementMissingMessage $addon.addonName " is not found in addons " "NOTICE" $tabIndent
            }else{
                DisplayElementMissingMessage $addon.addonName " is not found in addons " "WARNING" $tabIndent 
            }
            Write-Host
            DisplayInfoText "Addon file: $($addon.resourceFilename)  |  Size:  $($addon.addonSizeMB)MB" ($tabIndent  + $tabIndent + $tabIndent)                
            Write-Host
            DisplayInfoText "Addon page --> $($addon.addonUrl)" ($tabIndent  + $tabIndent + $tabIndent)
            Write-Host
            DisplayNoticeText "Download link --> $($addon.fileUrl)" ($tabIndent  + $tabIndent + $tabIndent)
            Write-Host
            if ($addon.info){
                DisplayNoticeMessage $addon.info ($tabIndent  + $tabIndent + $tabIndent)
                Write-Host
            }    
            # verify and download the addon
            if ($verification.isForInstall -eq $false){
                # we are verifying the profile
                DisplayProcessSubStep " Verifying Download Link " ($tabIndent  + $tabIndent)
                VerifyAddonLink $addon $WebClient $verification
            }elseif ($Global:autodl -and (!($addon.forceManualDl) -or ($addon.forceManualDl -eq $false))){
                # we are installing the profile 
                if ($Global:confirmdl -eq $false){
                    DisplayProcessSubStep " Automatic Download started " ($tabIndent  + $tabIndent)
                    CheckDowloadableAddon $addon $WebClient $verification
                }else{
                    DisplayProcessSubStep " Confirm Automatic Download " ($tabIndent  + $tabIndent)
                    $Prompt = "Do you confirm the automatic download of this addon?"
                    $Choices = [System.Management.Automation.Host.ChoiceDescription[]] @("&Yes", "&No")
                    $Default = 1
                    Write-Host
                    # Prompt for the choice
                    $Choice = $host.UI.PromptForChoice($Title, $Prompt, $Choices, $Default)
                     
                    # Action based on the choice
                    switch($Choice)
                    {
                        0 { 
                            CheckDowloadableAddon $addon $WebClient $verification
                        }
                        1 { 
                            Write-Host
                            DisplayElementMissingMessage $addon.addonName " is not found in addons " "WARNING" $tabIndent
                            Write-Host
                            DisplayInfoText " Please manually download the addon file `"$($addon.resourceFilename)`" by clicking the download link and save it in the addons folder" ($tabIndent  + $tabIndent)
                            DisplayNoticeText "Make sure you save with this filename $($addon.resourceFilename)" ($tabIndent  + $tabIndent + $tabIndent)
                            $verification.isVerifed = $False
                            $errorMsg = [string]$Error[0]
                            $failureLog = [PSCustomObject]@{
                                type = "manualdlchoice"
                                target = $addon.addonName
                                error = $errorMsg.Trim()
                                message = @(
                                    "You are required to manually download from $($addon.fileUrl)"
                                )
                            }
                            $verification.failureLogs += $failureLog
                        }
                    } 
                }
            }else{
                DisplayWarningMessage "Automatic download cannot be used for this addon " ($tabIndent + $tabIndent)
                DisplayNoticeMessage "Please manually download addon file from $($addon.fileUrl)" ($tabIndent  + $tabIndent + $tabIndent)
                DisplayNoticeMessage "A tab was opened in the EXT browser " ($tabIndent  + $tabIndent + $tabIndent)
                DownloadWithBrowser $addon.fileUrl
            }
            if (Test-Path -Path $addonPath){
                DisplayDownloadedAddon $addon.addonName $tabIndent
            }
        }
    }
}
function VerifyAddon{
    param (
        [Parameter(Mandatory = $true, Position = 0)]
        $verification,
        [Parameter(Mandatory = $true, Position = 1)]
        $addonName        
    )

    if ($verification.profileName -eq ""){
        PromptErrorBeforeExit "cannot verify a custom profile unless a profilename is specified - e.g. -verify -profilename testprofile"
    }
    # start verification
    DisplayProcessStep " Verifying profile ""$($verification.profileName)"" addon ""$addonName"""
    DisplayProcessStepText "Loading profile definitions" $tabIndent
    $profileDefinitions = GetProfileDefinitions $verification.profileName
    if ($null -eq $profileDefinitions){
        PromptErrorBeforeExit " Could not find profile definitions "
    }else{
        Write-Host
        DisplayPositiveText ">> profile definitions loaded" $tabIndent
    }

    $WebClient = New-Object System.Net.WebClient

    $addon = GetAddonDefinitions $profileDefinitions $addonName

    if ($null -eq $addon){
        PromptErrorBeforeExit " Could not find addon definitions "
    }

    DisplayProcessSubStep " Verifying Download Link " ($tabIndent  + $tabIndent)
    VerifyAddonLink $addon $WebClient $verification
}
function HashMatch{
    param (
        $addon
    )
    $addonPath = [WildcardPattern]::Escape($(GetAddonResourcePath $addon))
    $hash = Get-FileHash -Path $addonPath -Algorithm SHA256
    if ($hash.Hash -eq $addon.hash){
        return $true
    }else{
        return $false
    }
}
function VerifyAddonsArchives{

    param (
        [Parameter(Mandatory = $true, Position = 0)]
        $addons,
        [Parameter(Mandatory = $true, Position = 1)]
        $verification
    )

    DisplayProcessStep  " Checking downloaded addons' archives integrity "
    Write-Host

    foreach ($addon in $addons){
        
        DisplayProcessSubStep  " Verifying file $($addon.resourceFilename)" ($tabIndent + $tabIndent)
        Write-Host
        $addonPath = [WildcardPattern]::Escape($(GetAddonResourcePath $addon))
        if ( $(Test-Path -Path $addonPath) -eq $false ){
            DisplayNoticeMessage ">> Addon file $($addon.resourceFilename) is not found in the addons folder, was not downloaded" ($tabIndent + $tabIndent)
        }elseif ( (HashMatch $addon) -eq $false ){
            Write-Host
            DisplayNoticeText " The file $($addon.resourceFilename) does not match the expected hash. This could mean the file is corrupted or you downloaded a new version of the addon " ($tabIndent + $tabIndent)
            DisplayNoticeText " You can continue the installation or complete the addons verification and then exit the process " ($tabIndent + $tabIndent)
            Write-Host
        
            $Prompt = "Type yes to continue the installation or No to end the installation after the addons verification"
            $Choices = [System.Management.Automation.Host.ChoiceDescription[]] @("&Yes", "&No")
            $Default = 0
            Write-Host
            # Prompt for the choice
            $Choice = $host.UI.PromptForChoice($Title, $Prompt, $Choices, $Default)
             
            # Action based on the choice
            switch($Choice)
            {
                0 { 
                    # continue to install
                }
                1 { 
                    $verification.isVerifed = $False
                    $errorMsg = [string]$Error[0]
                    $failureLog = [PSCustomObject]@{
                        type = "wronghash"
                        target = $addon.addonName
                        error = $errorMsg.Trim()
                        message = @(
                            "The addon archive file, `"$(GetAddonResourcePath $addon)`" downloaded from $($addon.fileUrl) seems to be corrupted. Hash mismatch: $($hash.Hash) != $($addon.hash) [expected]"
                        )
                    }
                    $verification.failureLogs += $failureLog
                }
            } 
        }
    }

    Write-Host
}

function VerifyDiskspaceRequirements {
    param (
        $profileDefinitions,
        $verification
    )
    if ($profileDefinitions.installationDiskspaceRequirementMB) {

        $workspaceDrive = GetDriveLetter $Global:pathToEXTWorkspace
        $gammaDrive = GetDriveLetter $Global:pathToMOMods
        if ($workspaceDrive -ne $gammaDrive) {

            DisplayProcessStep " Checking workspace space requirements are met"
            # calculate free disk space in workspace
            $workspaceDriveInfo = Get-PSDrive -Name $workspaceDrive
            $freeSpaceWorkspaceDrive = $workspaceDriveInfo.Free / 1MB
        
            DisplayNoticeMessage ">> Workspace and GAMMA folders are on different drives" $tabIndent
            DisplayNoticeMessage ">> Free space in workspace drive: $freeSpaceWorkspaceDrive MB" $tabIndent

            $workspaceSizeRequirement = 0
            foreach ($addon in $profileDefinitions.addons) {
                $workspaceSizeRequirement += $addon.workspacedSizeMB
            }
            DisplayNoticeMessage ">> Workspace size requirement: $workspaceSizeRequirement MB" $tabIndent
        
            if ($workspaceSizeRequirement -gt $freeSpaceWorkspaceDrive) {
                $message = ">> Not enough space: $workspaceSizeRequirement MB "
                Write-Host
                DisplayWarningMessage $message $tabIndent
                $verification.isVerifed = $False
                $failureLog = [PSCustomObject]@{
                    type    = "workspace"
                    target  = $null
                    error   = $null
                    message = @(
                        $message
                    )
                }            
                $verification.failureLogs += $failureLog
            }else {
                Write-Host
                DisplayPositiveText ">> free disk space available" $tabIndent         
            }

            DisplayProcessStep " Checking final space requirements are met"
            # calculate free disk space in $gammaDrive
            $gammaDriveInfo = Get-PSDrive -Name $gammaDrive
            $freeSpaceGammaDrive = $gammaDriveInfo.Free / 1MB
            DisplayNoticeMessage ">> Free space in GAMMA drive: $freeSpaceGammaDrive MB" $tabIndent

            DisplayNoticeMessage ">> Final size requirement: $($profileDefinitions.finalDiskspaceRequirementMB) MB" $tabIndent

            if ($profileDefinitions.finalDiskspaceRequirementMB -gt $freeSpaceGammaDrive) {
                $message = ">> Not enough space: $($profileDefinitions.finalDiskspaceRequirementMB) MB "
                Write-Host
                DisplayWarningMessage $message $tabIndent
                $verification.isVerifed = $False
                $failureLog = [PSCustomObject]@{
                    type    = "workspace"
                    target  = $null
                    error   = $null
                    message = @(
                        $message
                    )
                }            
                $verification.failureLogs += $failureLog
            }else {
                Write-Host
                DisplayPositiveText ">> free disk space available" $tabIndent         
            }
        }else {
            $diskSpaceAvailable = GetAvailableSpace
            $diskSpaceAvailableMB = $diskSpaceAvailable / 1MB
            $diskSpaceAvailableGB = $diskSpaceAvailable / 1GB
            Write-Host
            DisplayProcessStep " Checking disk space requirements "

            if ($diskSpaceAvailableMB -le $profileDefinitions.installationDiskspaceRequirementMB) {
                $message = ">> Not enough space: $diskSpaceAvailableGB GB "
                Write-Host
                DisplayWarningMessage $message $tabIndent
                $verification.isVerifed = $False
                $failureLog = [PSCustomObject]@{
                    type    = "diskspace"
                    target  = $null
                    error   = $null
                    message = @(
                        $message
                    )
                }            
                $verification.failureLogs += $failureLog
            }
            else {
                Write-Host
                DisplayPositiveText ">> free disk space available" $tabIndent         
            }
        }
    }else {
        DisplayProcessStep " Skipping workspace space requirements check"
        Write-Host
        DisplayNoticeMessage ">> diskspace information not available in profile definitions" $tabIndent
    }
}

function Verify{
    param (
        $verification,
        $options
    )

    if ($null -ne $options){
        $Global:optionsList = $options -split ","
    }

    DisplayBanner $Global:VerifyBanner

    if ($profileName -eq ""){
        PromptErrorBeforeExit "cannot verify a custom profile unless a profilename is specified - e.g. -verify -profilename testprofile"
    }
    # start verification
    DisplayProcessStep " Verifying GAMMA-EXT profile ""$($verification.profileName)"" "
    DisplayProcessStepText "Loading profile definitions" $tabIndent
    $profileDefinitions = GetProfileDefinitions $verification.profileName
    if ($null -eq $profileDefinitions){
        PromptErrorBeforeExit " Could not find profile definitions "
    }else{
        Write-Host
        DisplayPositiveText ">> profile definitions loaded" $tabIndent
    }
    # EXT compatibility
    VerifyExtCompatibility $profileDefinitions
    
    DisplayProcessStep  " Checking profile dependencies "
    DisplayProcessStepText "Profiles can have dependencies like a parent profile" $tabIndent

    VerifyParentDependency $profileDefinitions $verification

    VerifyProfileIsInstalled $profileDefinitions

    if ($profileDefinitions.parentProfile) {
        $parentProfileDefinition = GetParentProfileDefinitions $profileDefinitions
        if ($null -ne $parentProfileDefinition) {
            VerifyAddonsAvailability $parentProfileDefinition $verification
        }
    }

    VerifyAddonsAvailability $profileDefinitions $verification

    if ($Global:optionsList -contains "skiphashcheck"){
        # skip hash check
    }else{
        if ($verification.isVerifed -eq $True){
            ConfirmDownloadsCompletionAndVerify
            Write-Host
            if ($profileDefinitions.parentProfile) {
                $parentProfileDefinition = GetParentProfileDefinitions $profileDefinitions
                if ($null -ne $parentProfileDefinition) {
                    VerifyAddonsArchives $parentProfileDefinition.addons $verification
                }
            }
            VerifyAddonsArchives $profileDefinitions.addons $verification
        }
    }
    if ($Global:optionsList -contains "nodiskspacecheck"){
        Write-Host
        DisplayNoticeMessage "Skipping diskspace check" $tabIndent
        Write-Host
    }else{
        Write-Host  
        VerifyDiskspaceRequirements $profileDefinitions $verification
        Write-Host        
    }
}
function InstallProfile($profileName, $options){
    
    $verification = [PSCustomObject]@{
        profileName = $profileName
        isForInstall = $true
        isVerifed = $true
        failureLogs = @()
    }

    $Global:optionsList = @()
    if ($null -ne $options){
        $Global:optionsList = $options -split ","
    }

    if ($profileName -eq ""){
        PromptErrorBeforeExit "Cannot install a custom profile unless a profilename is specified, e.g. install -profilename testprofile"
    }

    if ($Global:optionsList -notcontains "local"){
        # run getprofiles
        GetProfile $profileName
    }

    $profileDefinitions = GetProfileDefinitions $profileName
    $Global:compiledProfileDefinitions = $profileDefinitions

    Verify $verification

    if ($verification.isVerifed -eq $False){
        DisplayVerification $verification
        Write-Host
        PromptErrorBeforeExitNoPause "Installation of $profileName is not possible due to some missing preconditions" 
    }

    DisplayBanner $Global:InstallBanner

    DisplayProcessStep " Installing $profileName profile "
    if ($null -ne $options){
        Write-Host
        DisplayInfoText "With options:"
        $Global:optionsList | ForEach-Object {
            Write-Host
            DisplayInfoText $_
        }
    }

    $profileDefinitions = GetProfileDefinitions $profileName

    if ($null -eq $profileDefinitions){
        PromptErrorBeforeExit " Could not find profile definitions "
    }

    Write-Host
    DisplayProfileSummaryShort $profileDefinitions
    Write-Host
    DisplayNoticePause " Before continuing with the install CLOSE Mod Organizer "
    Write-Host

    $Prompt = "Type yes to start the installation or No to exit the installation"
    $Choices = [System.Management.Automation.Host.ChoiceDescription[]] @("&Yes", "&No")
    $Default = 1
    Write-Host
    # Prompt for the choice
    $Choice = $host.UI.PromptForChoice($Title, $Prompt, $Choices, $Default)
     
    # Action based on the choice
    switch($Choice)
    {
        0 { 
            # continue to install
        }
        1 { 
            # exit the install
            exit
        }
    } 

    $profileMOPath = "$Global:pathToMOProfiles/$($profileDefinitions.profileName)"

    if (Test-Path -LiteralPath $profileMOPath) {

        # the profile is installed in MO

        $installedProfile = GetMOBuildProfileDefinitions $profileDefinitions.profileName

        if (!$installedProfile){
            # installed profile is not an EXT profile
            DisplayWarningMessage " A non GAMMA-EXT profile with the same name already exists in GAMMA's Mod Organizer "
            Write-Host 
            DisplayNegativeText "Beware that mods in Mod Organizer belonging to other non GAMMA-EXT profiles, that share same name of mods from this profile, can be deleted as consequence" $tabIndent
            PromptErrorBeforeExit " Open Mod Organizer and change its name if you want to install this profile "
        }

        if ([int]$profileDefinitions.version -eq [int]$installedProfile.version){
            # same profile have same versions, just overwrite 

            if ($profileDefinitions.parentProfile){
                # profile has a parent

                $moParentProfileDefinitions = GetMOParentBuildProfileDefinitions $profileDefinitions
                if ($moParentProfileDefinitions){
                    # parent is fully installed

                    if ($moParentProfileDefinitions.version -eq $profileDefinitions.parentProfile.version){
                        # installed parent is compabible
                        # skip parent install

                        # reinstalling profile
                        Install $profileDefinitions
                    }else{

                        $parentProfileDefinitions = GetProfileDefinitions $profileDefinitions.parentProfile.name
                        # reinstalling parent
                        Install $parentProfileDefinitions
                        # reinstalling profile
                        Install $profileDefinitions
                    }
                }else{
                    # parent is not fully installed
                    # reinstalling profile
                    Install $profileDefinitions
                }
            }else{
                Install $profileDefinitions
            }
        }elseif ([int]$profileDefinitions.version -gt [int]$installedProfile.version){
            # profile is upgrade of installed profile, uninstall

            if ($profileDefinitions.parentProfile){
                # profile has a parent
        
                $moParentProfileDefinitions = GetMOParentBuildProfileDefinitions $profileDefinitions
                if ($moParentProfileDefinitions){

                    # parent is fully installed
                    $parentProfileDefinitions = GetProfileDefinitions $profileDefinitions.parentProfile.name
    
                    # reinstalling parent
                    UninstallForUpdate $parentProfileDefinitions
                    Install $parentProfileDefinitions

                    # reinstalling profile
                    UninstallForUpdate $profileDefinitions
                    Install $profileDefinitions
                }else{
                    # parent is not installed

                    # removing inherited parent mods
                    RemoveParentMods $profileDefinitions
                    
                    # uninstalling profile
                    UninstallForUpdate $profileDefinitions
                    
                    # reinstalling profile
                    Install $profileDefinitions
                }
            }else{
                # profile has no parent

                UninstallForUpdate $profileDefinitions
                # reinstalling profile
                Install $profileDefinitions
            }

        }else{    
            # installed profile is newer --> abort

            DisplayWarningMessage " A profile with the same name is already installed in GAMMA's Mod Organizer "
            DisplayWarningMessage " !! The installed profile version is newer $($installedProfile.version) !! "
            Write-Host
            PromptMessageBeforeExit " Install aborted "
        }
    }else{

        # the profile is not installed in MO

        # install profile as new
        Install $profileDefinitions
    }

    
    if ($Global:optionsList -contains "compilesize"){
        WriteUpdatedProfile $profileDefinitions
    }
    
    DisplayWorkspaceSize

    if(!$dev.IsPresent){
        ClearWorkspaces
    }

    PrintCompletionMessage $profileName

    $highlightMessage = $true
    DisplayInstallCompletionMessage $profileDefinitions $highlightMessage

}
function Install {
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $profileDefinitions
    )
    
    DisplayProcessStep " Installing profile $($profileDefinitions.profileName) "

    $usePlugin = RegisterPlugin $profileDefinitions.profileName

    if ($null -eq $usePlugin){
        # no plugin found
    }else{
        . $usePlugin
        PluggableCreateAddonsWorkspaces $profileDefinitions.addons
    }

    # check if profile has a parent to whom inherit installation definitions
    if ($null -ne $profileDefinitions.parentProfile){
        CreateParentMods $profileDefinitions
    }

    CreateMOMods $profileDefinitions

    CreateMOProfile $profileDefinitions

    # create gamePatches workspace
    CreateGamePatchesWorkspace $profileDefinitions

    CreateProfileSettings $profileDefinitions

}
function GetProfile{
    param (
        [Parameter(Mandatory = $true, Position = 0)]
        $profileName
    )
    $autoConfirm = $true
    DisplayProcessStep "Downloading profile definitions for $profileName "

    GetSharedProfiles $profileName $autoConfirm

    $profileDefinitions = GetProfileDefinitions $profileName

    if ($null -ne $profileDefinitions.parentProfile -and $profileDefinitions.parentProfile.name) {
        DisplayProcessStep "Downloading profile definitions for $($profileDefinitions.parentProfile.name) "
        GetSharedProfiles $profileDefinitions.parentProfile.name $autoConfirm
    }    
}
function Update{
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $profileName,
        [Parameter(Mandatory = $true, Position = 1)]
        $options
    )

    $Global:optionsList = @()
    if ($null -ne $options){
        $Global:optionsList = $options -split ","
    }

    DisplayProcessStep " Updating profile $profileName "

    if ($Global:optionsList -notcontains "local"){
        # run getprofiles
        GetProfile $profileName
    }

    $installedProfileDefinition = GetMOProfileDefinitions $profileName

    if ($null -eq $installedProfileDefinition){
        PromptErrorBeforeExit " Could not update, profile is not installed "
    }

    if ($Global:autodl -eq $false){
        DisplayNoticeMessage " You have Automatic Downloads disabled " $tabIndent
        Write-Host
        DisplayInfoText "To use Update profile you need to enable Automatic Downloads" $tabIndent
        Write-Host
        DisplayInfoText "to enable this feature " ($tabIndent + $tabIndent)
        Write-Host
        DisplayPositiveText "run > .\GAMMA_EXT.ps1 -enable automatic-dl" ($tabIndent + $tabIndent)        
        PromptMessageBeforeExitNoPause " Update Profile Aborted "
    }

    $downloadChangelog = @()
    $deleteChangelog = @()
    $updateChangelog  = @()

    $profileDefinitions = GetProfileDefinitions $profileName

    CheckIfExtVersionCompatible $profileDefinitions

    $changeLogDefinitions = GetChangeLogDefinitions $profileName

    # Assuming $changeLogDefinitions is a hashtable where the keys are the version numbers
    if ($installedProfileDefinition.version -eq $profileDefinitions.version){
        Write-Host
        DisplayWarningMessage " The profile installed in MO2 is already updated to the latest version: $($profileDefinitions.version) "
        Write-Host

        $Prompt = "Do you want to re-run the latest update"
        $Choices = [System.Management.Automation.Host.ChoiceDescription[]] @("&Yes", "&No")
        $Default = 1
         
        # Prompt for the choice
        $Choice = $host.UI.PromptForChoice($Title, $Prompt, $Choices, $Default)
         
        # Action based on the choice
        switch($Choice){
            0 {
                # continue to update
            }
            1{
                Write-Host
                PromptErrorBeforeExit " Update Profile Aborted "
            }
        }  
        $startingVersion = $profileDefinitions.version
    }else{
        $startingVersion = $installedProfileDefinition.version + 1
    
    }
    $endingVersion = $profileDefinitions.version
    Write-Host
    DisplayProcessStep " Creating the full change log from version $startingVersion to $endingVersion"
    Write-Host
    # initialize the $verification object
    $verification = [PSCustomObject]@{
        profileName = $profileName
        isForInstall = $true
        isVerifed = $true
        failureLogs = @()
    }

    for ($version = $startingVersion; $version -le $endingVersion; $version++) {

        $changeLog = $changeLogDefinitions.changeLog | Where-Object {$_.version -eq $version}
        DisplayProcessStep "Collating changeLog $($changeLog.version)" $Global:tabIndent
        if ($null -ne $changeLog) {

            # collating addons for download
            DisplayProcessSubStep "Collating downloadChangelog" ($Global:tabIndent + $Global:tabIndent)
            foreach ($addon in $changeLog.download) {
                $foundAddon = $downloadChangelog | Where-Object {$_.addonName -eq $addon.addonName}
                if (!$foundAddon) {
                    DisplayAddonName $addon.addonName ($Global:tabIndent + $Global:tabIndent + $Global:tabIndent)
                    $addonDefinitions = GetAddonDefinitions $profileDefinitions $addon.addonName 
                    if($null -eq $addonDefinitions){
                        DisplayNegativeText " Addon definitions notfound: $($addon.addonName)" ($tabIndent + $tabIndent + $tabIndent) 
                        $failureLog = [PSCustomObject]@{
                            type = "addondefinitions"
                            target = $changeLog.version
                            error = $null
                            message = @(
                                $($addon.addonName)
                            )
                        }
                        $verification.failureLogs += $failureLog
                    }else{
                        $downloadChangelog += $addon
                    }
                }
            }

            # collating mods for delete
            DisplayProcessSubStep "Collating deleteChangelog" ($Global:tabIndent + $Global:tabIndent)
            foreach ($mod in $changeLog.delete) {
                $foundMod = $deleteChangelog | Where-Object {$_.modName -eq $mod.modName}
                if (!$foundMod) {
                    DisplayModName $mod.modName ($Global:tabIndent + $Global:tabIndent + $Global:tabIndent)
                    $deleteChangelog += $mod
                }
            }

            # collating mods for update
            DisplayProcessSubStep "Collating updateChangelog" ($Global:tabIndent + $Global:tabIndent)
            foreach ($mod in $changeLog.update){
                $foundMod = $updateChangelog | Where-Object {$_.modName -eq $mod.modName}
                if (!$foundMod) {
                    DisplayModName $mod.modName ($Global:tabIndent + $Global:tabIndent + $Global:tabIndent)
                    $modDefinitions = GetModDefinitions $profileDefinitions $mod.modName 
                    if($null -eq $modDefinitions){
                        DisplayNegativeText " Mod definitions notfound: $($mod.modName)" ($tabIndent + $tabIndent + $tabIndent) 
                        $failureLog = [PSCustomObject]@{
                            type = "moddefinitions"
                            target = $changeLog.version
                            error = $null
                            message = @(
                                $($mod.modName)
                            )
                        }
                        $verification.failureLogs += $failureLog
                    }else{
                        $updateChangelog += $mod
                    }
                }
            }
        }
    }


    if ($Global:optionsList -notcontains "offline"){

        DisplayProcessStep " Downloading updated Addons "
        # download addons
        $WebClient = New-Object System.Net.WebClient
        foreach ($addon in $downloadChangelog) {
            # DisplayProcessSubStep " GetAddonDefinitions $($addon.addonName) " $tabIndent
            $addonDefinitions = GetAddonDefinitions $profileDefinitions $addon.addonName 
            if ($Global:optionsList -contains "verify"){
                Write-Host
                DisplayProcessSubStep " Verifying Download Link " $tabIndent
                VerifyAddonLink $addonDefinitions $WebClient $verification
            }else{

                $addonPath = [WildcardPattern]::Escape($(GetAddonResourcePath $addon))
                $addonFileExists = Test-Path -Path $addonPath
                if (!$addonFileExists -or ($addonFileExists -and $addonDefinitions.alwaysDl)){
                    # download the addon
                    Write-Host
                    DisplayElementMissingMessage $addonDefinitions.addonName " will be updated " "NOTICE" $tabIndent
                    DownloadAddon $addonDefinitions $WebClient $verification                      
                }else{
                    DisplayAvailableAddon $addonDefinitions.addonName $tabIndent
                }                    
            }
        }
        ConfirmDownloadsCompletion
    }

    DisplayProcessStep " Verifying Addons Archives "
    Write-Host
    # Initialize the $changeLogAddons array if not already initialized
    if (-not $changeLogAddons) {
        $changeLogAddons = @()
    }

    # Iterate through the $changeLog.download array
    foreach ($downloadAddon in $downloadChangelog) {
        # Find the corresponding addon in $profileDefinitions.addons using addonName
        $matchedAddon = $profileDefinitions.addons | Where-Object { $_.addonName -eq $downloadAddon.addonName }
        
        # Add the matched addon to the $changeLogAddons array
        if ($matchedAddon) {
            $changeLogAddons += $matchedAddon
        }
    }

    VerifyAddonsArchives $changeLogAddons $verification

    if ($Global:optionsList -contains "verify" -or $verification.isVerifed -eq $False){
        DisplayVerification $verification
        if ($Global:optionsList -contains "verify"){
            PromptMessageBeforeExit " Update Verifcation Complete "
        }elseif($verification.isVerifed -eq $False){
            Write-Host
            PromptErrorBeforeExitNoPause "Installation of $profileName is not possible due to some missing preconditions" 
        }
    }

    DisplayWarningPause " Before continuing with the update CLOSE Mod Organizer "

    RemoveProfileSeparatorMod $installedProfileDefinition

    DisplayProcessStep " Deleting Mod Organizer Mods "
    # deleting mods
    foreach ($mod in $deleteChangelog) {
        RemoveMOMod $mod $profileDefinitions  
    }
    Write-Host
    DisplayProcessStep " Updating Mod Organizer Mods "
    Write-Host
    # updating mods
    foreach ($mod in $updateChangelog){
        UpdateMod $profileName $mod.modName
    }

    CreateProfileSeparatorMod $(GetProfileSeparatorModName $profileDefinitions)

    CreateMOProfile $profileDefinitions

    # create gamePatches workspace
    CreateGamePatchesWorkspace $profileDefinitions

    # RemoveSettings $profileDefinitions.profileName

    CreateProfileSettings $profileDefinitions

}

function UpdateClones{
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $profileName
    )

    # for each profile folder in the pathtoMOProfiles folder
    $installedProfiles = Get-ChildItem $Global:pathToMOProfiles -Directory
    foreach ($installedProfileFolder in $installedProfiles) {
        if ($installedProfileFolder.Name -eq "G.A.M.M.A"){
            continue
        }
        # get the profile definitions if the file is found
        $profileDefinitions = GetMOProfileDefinitions $installedProfileFolder.Name
        if ($null -eq $profileDefinitions){
            continue
        }

        # check if the profile is a clone of the profileName
        if ($profileDefinitions.profileType -eq "clone" -and $profileDefinitions.profileBaseName -eq $profileName){
            # synch the clone
            SynchProfile $profileDefinitions

            SynchSettings $profileDefinitions
        }

    }
}

function UninstallForUpdate{
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $profileDefinitions
    )

    DisplayProcessStep " Uninstalling old profile $($profileDefinitions.profileName) "

    $profilePath = "$Global:pathToMOProfiles/$($profileDefinitions.profileName)"

    if (Test-Path -Path $profilePath) {

        $profileBuildDefinitions = GetMOBuildProfileDefinitions $profileDefinitions.profileName

        if ($null -eq $profileBuildDefinitions){
            PromptErrorBeforeExit " Could not find old profile "
        }

        Write-Host
        DisplayProfileSummaryShort $profileBuildDefinitions
        Write-Host
        RemoveMOMods $profileBuildDefinitions
        RemoveMOProfile $profileBuildDefinitions
    }else{
        PromptErrorBeforeExit " Could not find old profile "
    }
    Write-Host
    DisplaySuccessMessage " Uninstall profile $($profileDefinitions.profileName) completed "
}
function CheckOtherInstalledProfileDependency {
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $profileName
    )
    
    DisplayProcessStep " Cheking current installed profiles dependecies "

    $installedProfiles = Get-ChildItem $Global:pathToMOProfiles
    $match = $false
    $profilesDependent = @()
    foreach ($installedProfileFolder in $installedProfiles) {

        if ($installedProfileFolder.Name -eq "G.A.M.M.A"){
            continue
        }

        $installedProfileDefinition = GetMOProfileDefinitions $installedProfileFolder.Name
        if ($null -eq $installedProfileDefinition){
            continue
        }

        if (($installedProfileDefinition.profileType -ne "kit" -and $installedProfileDefinition.profileType -ne "clone") -and $installedProfileDefinition.parentProfile.name -eq $profileName){
            $match = $true
            $profilesDependent += $installedProfileDefinition.profileName
        }
    }

    if ($match){
        DisplayNoticeMessage " The following profiles are using this profile as parent dependency "

        foreach ($currentItemName in $profilesDependent) {
            Write-Host
            DisplayElementMissingMessage $currentItemName "" "WARNING" $tabIndent
        }
        Write-Host
        DisplayNoticeMessage " You must uninstall these profile if you want to uninstall this one "
        
        PromptMessageBeforeExit " Uninstall was aborted "
    }

    Write-Host
    DisplayPositiveText ">> no installed profiles exists that reference this profile as parent " $tabIndent
}
function Uninstall{
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $profileName
    )

    DisplayBanner $Global:UninstallBanner

    $profilePath = "$Global:pathToMOProfiles/$profileName"

    if (Test-Path -Path $profilePath) {

        $profileDefinitions = GetMOBuildProfileDefinitions $profileName

        if ($null -eq $profileDefinitions){
            PromptErrorBeforeExit " Could not find old profile "
        }

        $existingDependencies = CheckIfAnyDependentProfileIsInstalled $profileDefinitions

        if ($existingDependencies){
            Write-Host
            DisplayWarningMessage " There are other profiles installed in MO that depends on this profile "
            Write-Host
            PromptErrorBeforeExit " Uninstall Aborted "
        }

        Write-Host
        DisplayProfileSummaryShort $profileDefinitions
        Write-Host
        CheckOtherInstalledProfileDependency $profileName
        Write-Host
        DisplayProcessStep " Uninstalling profile "
        Write-Host
        DisplayWarningMessage "You are about to unistall the profile ($profileName) from GAMMA's ModOrganizer"
        Write-Host
        DisplayNegativeText "All mods associated to it will be also deleted from the GAMMA's ModOrganizer mods folder"
        Write-Host
        DisplayNoticeText "If you are unsure how to proceed, abort and run command"
        Write-Host
        DisplayCommand "" ".\GAMMA_EXT.ps1 -listmods ""$profileName"""
        DisplayNoticeText "     to see all the mods associated to this profile"
        $Title = "Do you wish to continue and unistall this profile?"
        $Prompt = "Enter your choice"
        $Choices = [System.Management.Automation.Host.ChoiceDescription[]] @("&Yes", "&No")
        $Default = 1
            
        # Prompt for the choice
        $Choice = $host.UI.PromptForChoice($Title, $Prompt, $Choices, $Default)

        # Action based on the choice
        switch($Choice)
        {
            0 { 
                # remove this profile mods first
                RemoveMOMods $profileDefinitions
                # check if this profile has a parent profile and it is installed
                if ($null -ne $profileDefinitions.parentProfile){
                    # it has a parent profile
                    $parentDefinitions = GetMOParentBuildProfileDefinitions $profileDefinitions

                    if ($parentDefinitions){
                        # parent is installed
                        # do not delete it's mods
                    }else{
                        # parent is not installed we can delete it's mods. 
                        # TODO This only works if old parent profile is still in ext. 
                        # Issues: 
                        # - Cannot use install to corretly update profile by removing old parent mods
                        # - Cannot use uninstall to corretly removed old parent mods
                        # Workaround - Uninstall profile before updating definitions
                        DisplayProcessStep " Uninstalling parent profile mods "
                        $parentDefinitions = GetProfileDefinitions $profileDefinitions.parentProfile.name
                        RemoveMOMods $parentDefinitions
                    }
                }
                
                RemoveSettings $profileName
                RemoveMOProfile $profileDefinitions

                DisplayProcessStep " Switching Settings to GAMMA default settings "
                Write-Host
                SwitchSettings "G.A.M.M.A"
            }
            1 { PromptMessageBeforeExit "Uninstall was aborted"}
        }
    }else{
        PromptErrorBeforeExit " Could not find old profile "
    }
    Write-Host
    DisplaySuccessMessage " Uninstall completed "
    Write-Host
    DisplayInfoText "remember you can reinstall this profile anytime" $tabIndent
    Write-Host
    DisplayNoticeMessage " Commands available: "
    DisplayEligibleCommands $profileName
}

# function UpdateAddonsMods {
#     Param
#     (
#         [Parameter(Mandatory = $true, Position = 0)]
#         $profileDefinitions,
#         [Parameter(Mandatory = $true, Position = 1)]
#         $addonName        
#     )
#     $modList = @()
#     $modList = $profileDefinitions.customMods | Where-Object { 
#         if ($_.addonName -eq $addonName){
#             $modList += $_
#         } 
#     }

#     foreach ($mod in $modListn) {
#         UpdateMod $profileDefinitions.profileName 
#     }

# }

function UpdateModWithAddons{
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $profileName,
        [Parameter(Mandatory = $true, Position = 1)]
        $modName,
        [Parameter(Mandatory = $true, Position = 2)]
        $optionsList      
    )

    $profileDefinitions = GetProfileDefinitions $profileName

    $modDefinitions = GetModDefinitions $profileDefinitions $modName

    if ($modDefinitions){

        # initialize the $verification object
        $verification = [PSCustomObject]@{
            profileName = $profileName
            isForInstall = $true
            isVerifed = $true
            failureLogs = @()
        }

        $downloadChangelog = @()

        # collating addons for download
        DisplayProcessSubStep "Collating downloadChangelog" ($Global:tabIndent + $Global:tabIndent)
        
        $addon = @{
            addonName = $modDefinitions.addonName
        }
        $downloadChangelog += $addon

        if ($modDefinitions.pathToGamedata -is [System.Collections.IEnumerable] -and $modDefinitions.pathToGamedata[0] -is [PSCustomObject]) {

            foreach ($pathToGamedata in $modDefinitions.pathToGamedata) {
                if ($pathToGamedata.addonName){

                    $foundAddon = $downloadChangelog | Where-Object {$_.addonName -eq $pathToGamedata.addonName}
                    if (!$foundAddon) {

                    $addon = @{
                        addonName = $pathToGamedata.addonName
                    }                        

                        $downloadChangelog += $addon
                    }
                }
            }
        }

        DisplayProcessStep " Downloading updated Addons "
        # download addons
        $WebClient = New-Object System.Net.WebClient
        foreach ($addon in $downloadChangelog) {
            $addonDefinitions = GetAddonDefinitions $profileDefinitions $addon.addonName

            $addonPath = [WildcardPattern]::Escape($(GetAddonResourcePath $addon))
            $addonFileExists = Test-Path -Path $addonPath
            if (!$addonFileExists -or ($addonFileExists -and ($addonDefinitions.alwaysDl -or ($optionsList -contains "force")))){
                # download the addon
                Write-Host
                DisplayElementMissingMessage $addonDefinitions.addonName " will be updated " "NOTICE" $tabIndent
                DownloadAddon $addonDefinitions $WebClient $verification                      
            }else{
                DisplayAvailableAddon $addonDefinitions.addonName $tabIndent
            } 
        }

        ConfirmDownloadsCompletion

        DisplayProcessStep " Verifying Addons Archives "
        Write-Host
        # Initialize the $changeLogAddons array if not already initialized
        if (-not $changeLogAddons) {
            $changeLogAddons = @()
        }

        # Iterate through the $changeLog.download array
        foreach ($downloadAddon in $downloadChangelog) {
            # Find the corresponding addon in $profileDefinitions.addons using addonName
            $matchedAddon = $profileDefinitions.addons | Where-Object { $_.addonName -eq $downloadAddon.addonName }
            
            # Add the matched addon to the $changeLogAddons array
            if ($matchedAddon) {
                $changeLogAddons += $matchedAddon
            }
        }

        VerifyAddonsArchives $changeLogAddons $verification


        if ($verification.isVerifed -eq $False){
            DisplayVerification $verification
            if($verification.isVerifed -eq $False){
                Write-Host
                PromptErrorBeforeExitNoPause "Installation of $profileName is not possible due to some missing preconditions" 
            }
        }

        $modProfileDefinitions = $profileDefinitions.PsObject.Copy()

        $newCustomMods = @()
        $newCustomMods += $modDefinitions
        $modProfileDefinitions.customMods = $newCustomMods

        CreateMOMods $modProfileDefinitions

    }else{
        PromptErrorBeforeExitNoPause "Could not find mod definitions for $modName " 
    }
    

}

function UpdateMod {
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $profileName,
        [Parameter(Mandatory = $true, Position = 1)]
        $modName        
    )
    
    $moProfileDefinitions = GetMOProfileDefinitions $profileName

    if ($null -eq $moProfileDefinitions){
        PromptErrorBeforeExit " Profile $($profileDefinitions.profileName) is not installed "
    }

    $profileDefinitions = GetProfileDefinitions $profileName

    $modDefinitions = GetModDefinitions $profileDefinitions $modName

    if ($null -eq $modDefinitions){
        # mod can't be found in profile
        if ($null -ne $profileDefinitions.parentProfile){
            # look into parent mod definitions
            $parentDefinitions = GetProfileDefinitions $profileDefinitions.parentProfile.name

            if ($null -ne $parentDefinitions){
                $modDefinitions = GetModDefinitions $parentDefinitions $modName
                if ($null -eq $modDefinitions){
                    # mod can't be found in parent either
                    DisplayErrorMessage " $modName is not in profile $($parentDefinitions.profileName) "
                    return
                }
            }else{
                # no parent available
                DisplayErrorMessage " $modName is not in profile $($profileDefinitions.profileName) "
                return
            }
        }else{
            # no parent available
            DisplayErrorMessage " $modName is not in profile $($profileDefinitions.profileName) "
            return
        }
    }

    $modProfileDefinitions = $profileDefinitions.PsObject.Copy()

    $newCustomMods = @()
    $newCustomMods += $modDefinitions
    $modProfileDefinitions.customMods = $newCustomMods

    CreateMOMods $modProfileDefinitions
}

function ExportAsEXTProfile{
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $moProfileName
    )

    if ($profileName -eq ""){
        $moProfileName = GetActiveMOProfile
        Write-Host
        Write-Host "A profile was not specified!" -ForegroundColor White -BackgroundColor DarkCyan
        Write-Host
        Write-Host "The currently selected profile in GAMMA's ModOrganizer ""$moProfileName"" will be exported " -ForegroundColor DarkRed -BackgroundColor Yellow
        Write-Host         
    }else{

        $moProfilePath = "$Global:pathToMOProfiles/$moProfileName"
        if ((Test-Path -Path $moProfilePath) -eq $False) {
            Write-Host 
            Write-Host "This profile ""$moProfileName"" does not exists in GAMMA's ModOrganizer" -ForegroundColor DarkRed -BackgroundColor Yellow
            Write-Host 
            PromptMessageBeforeExit ""
        }
    }

    $extProfile = "profiles/" + $moProfileName

    $newExtProfileName = $moProfileName

    if (Test-Path -Path $extProfile) {
        Write-Host 
        Write-Host "A profile with the same name ""$moProfileName"" already exists in GAMMA EXT" -ForegroundColor DarkRed -BackgroundColor Yellow
        Write-Host 
        Write-Host "    If ""$moProfileName"" is a GAMMA-EXT release profile or a downloaded shared profile, it's recommended to export it with a new name" -ForegroundColor Yellow
        Write-Host 

        $Prompt = "Do you want to overwrite it?"
        $Choices = [System.Management.Automation.Host.ChoiceDescription[]] @("&Yes", "&No")
        $Default = 1
         
        # Prompt for the choice
        $Choice = $host.UI.PromptForChoice($Title, $Prompt, $Choices, $Default)
         
        # Action based on the choice
        switch($Choice)
        {
            0 { 
                ## keep name
            }
            1 { 
                $newExtProfileName = Read-Host "Please enter a new name: "
        
                $continue = $True
                while ($continue){
        
                    $Title = "The profile will be saved as ""$newExtProfileName"" in GAMMA-EXT"
                    $Prompt = "Do you confirm this name?"
                    $Choices = [System.Management.Automation.Host.ChoiceDescription[]] @("&Yes", "&No")
                    $Default = 1
                     
                    # Prompt for the choice
                    $Choice = $host.UI.PromptForChoice($Title, $Prompt, $Choices, $Default)
                     
                    # Action based on the choice
                    switch($Choice)
                    {
                        0 { 
                            $extProfile = "profiles/" + $newExtProfileName
                            if (Test-Path -Path $extProfile) {
                                Write-Host 
                                Write-Host "A profile with the same name ""$newExtProfileName"" already exists in GAMMA EXT" -ForegroundColor DarkRed -BackgroundColor Yellow
                                Write-Host 
                                $newExtProfileName = Read-Host "Please enter a new name: "
                            }else{
                                $continue = $False
                            }
                        }
                        1 { $newExtProfileName = Read-Host "Please enter a new name: " }
                    }
                }            
            }
        }
    }

    ExportProfile $moProfileName $newExtProfileName

}
function VerifyExportable{
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $moProfileName
    )    

    $profileDefinitions = GetMOProfileDefinitions $moProfileName

    if ($null -eq $profileDefinitions){
        PromptMessageBeforeExit " This profile is $profileName not installed in MO "
    }

    foreach ($addon in $profileDefinitions.addons){
        if (($addon.addonUrl -eq "") -or ($addon.fileUrl -eq "")){
            
            Write-Host 
            Write-Host "Cannot Export the profile" -ForegroundColor Yellow -BackgroundColor Red
            Write-Host 
            Write-Host "This custom profile has incomplete addons definitions, please use the `"save profile`" or run `"export`" again and complete the missing information" -ForegroundColor Yellow -BackgroundColor Red
            Write-Host 
            PromptMessageBeforeExit ""            

        }
    }

    foreach ($customMod in $profileDefinitions.customMods){
        if (($customMod.pathToGamedata -eq "")){
            
            Write-Host 
            Write-Host "Cannot Export the profile" -ForegroundColor Yellow -BackgroundColor Red
            Write-Host 
            Write-Host "This custom profile has incomplete customMods definitions, please use the `"save profile`" or run `"export`" again and complete the missing information" -ForegroundColor Yellow -BackgroundColor Red
            Write-Host 
            PromptMessageBeforeExit ""            

        }
    }
}
function ExportProfile {
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $moProfileName,
        [Parameter(Mandatory = $false, Position = 1)]
        $newExtProfileName
    )

    New-Item -Path $Global:pathToEXTProfiles -Name $newExtProfileName -ItemType "directory" -Force | Out-Null

    $profileDefinitions = GetMOProfileDefinitions $moProfileName

    if ($null -eq $profileDefinitions){
        PromptMessageBeforeExit " This profile is $profileName not installed in MO "
    }

    $forExport = $true

    SaveProfile $profileDefinitions $forExport

    VerifyExportable $moProfileName

    $profileDefinitions.profileName = $newExtProfileName

    $profileDefinitionsFile = "$Global:pathToEXTProfiles/$newExtProfileName/profile_definitions.json"

    Set-Content -Path $profileDefinitionsFile -Value ($profileDefinitions | ConvertTo-Json -Depth 5)

    Write-Host
    Write-Host "The profile has been exported in: " -NoNewline
    Write-Host -BackgroundColor DarkGreen -ForegroundColor Black "profiles/$newExtProfileName"
    Write-Host "You can now reinstall this profile in G.A.M.M.A. anytime you desire"


    Write-Host
    Write-Host "Create a shareable version of this profile"
    Write-Host "    to share >> "  -ForegroundColor DarkGreen -NoNewline
    Write-Host ".\GAMMA_EXT.ps1 -share `"$newExtProfileName`"" -ForegroundColor Blue 
}
function ShareProfile {
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $profileName
    )
    
    if ((Test-Path $Global:pathToEXTShared) -eq $False){
        New-Item -Path $Global:pathToEXTShared -ItemType Directory | Out-Null
    }

    if ($profileName -eq ""){
        $profileName = @(Get-ChildItem $Global:pathToEXTProfiles | Out-GridView -Title 'Choose a profile to share:' -PassThru)
    }else{

        $profilePath = "$Global:pathToEXTProfiles/$profileName"
        if ((Test-Path -Path $profilePath) -eq $False) {
            Write-Host 
            Write-Host "This profile ($profileName) does not exists in GAMMA EXT" -ForegroundColor Red -BackgroundColor Yellow
            Write-Host 
            PromptMessageBeforeExit ""
        }
    }
    $profileDefinitions = GetProfileDefinitions $profileName

    if ($null -eq $profileDefinitions){
        PromptErrorBeforeExit " Could not find profile definitions "
    }

    CreateSharedProfile $profileDefinitions $profilePath
}
function GetSharedProfileName {
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $sharedProfileFileName
    )

    $pathToMetaIni = "$Global:pathToEXTWorkspace/profiles/shared-meta.ini"
    
    $modMetaIni = [ModMetaIni]::new()
    $modMetaIni.Load($pathToMetaIni)
    $profileName = $modMetaIni.properties.'profileName'

    return $profileName

}
function AddProfile {
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $sharedProfileFileName,
        [Parameter(Mandatory = $true, Position = 1)]
        $allowExit,
        [Parameter(Mandatory = $false, Position = 2)]
        $autoConfirm        
    )
    

    if (($null -eq $sharedProfileFileName) -or ($sharedProfileFileName -eq "")){
        DisplayProcessStep " Listing shared profiles files"
        DisplayShareableProfiles
        exit
    }
    DisplayProcessStep " Adding shared profile "

    if (($sharedProfileFileName.Contains(".\shared\")) -or ($sharedProfileFileName.Contains("./shared/"))){

        $sharedFile = Get-Item -Path $sharedProfileFileName
        if ($sharedFile){
            $sharedProfileFileName = $sharedFile.PSChildName
        }
        
    }

    CreateSharedProfileWorkspace $sharedProfileFileName
    $profileName = GetSharedProfileName $sharedProfileFileName
    $sharedProfileDefinitions = GetSharedProfileDefinitions $profileName
    ClearWorkspaceItem "profiles"

    if ($null -eq $sharedProfileDefinitions){
        PromptErrorBeforeExit " Could not find profile definitions "
    }
    
    DisplayAddonName $sharedProfileFileName
    DisplayProfileSummary $sharedProfileDefinitions

    $extProfile = "$Global:pathToEXTProfiles/$profileName"
    if ((Test-Path -Path $extProfile) -and $autoConfirm -eq $false ){
        Write-Host
        DisplayWarningMessage " A profile with the same name ""$profileName"" already exists in GAMMA EXT "
        Write-Host
        $profileDefinitions = GetProfileDefinitions $profileName
        DisplayProfileSummaryShort $profileDefinitions
        DisplayNoticeText "Adding the profile from this file will overwrite the existing one" $tabIndent
        Write-Host 

        $Prompt = "Do you want to overwrite it? Type Yes to replace the profile, No to abort"
        $Choices = [System.Management.Automation.Host.ChoiceDescription[]] @("&Yes", "&No")
        $Default = 1
         
        # Prompt for the choice
        $Choice = $host.UI.PromptForChoice($Title, $Prompt, $Choices, $Default)
         
        # Action based on the choice
        switch($Choice){
            0 {
                # remove existing profile
                ExitIfPathIsProhibited($extProfile)
                Remove-Item -LiteralPath $extProfile -Force -Recurse
            }
            1{
                if ($allowExit){
                    Write-Host
                    DisplayProcessStep "Adding shared profile was aborted"
                    Write-Host
                    exit
                }
                Write-Host
                DisplayProcessStep "Adding shared profile was skipped"
                Write-Host
            }
        }        
    }else{
        # remove existing profile
        if (Test-Path -Path $extProfile){
            ExitIfPathIsProhibited($extProfile)
            Remove-Item -LiteralPath $extProfile -Force -Recurse
        }
    }

    $pathToProfile = "$Global:pathToEXTShared/$sharedProfileFileName"
    if (Test-Path -Path $pathToProfile){
        Expand-Archive -Path $pathToProfile -Force -DestinationPath .
        Remove-Item -LiteralPath "$Global:pathToEXTProfiles/shared-meta.ini"
    }else{
        Write-Host "Could not find shared profile $profileName in ./shared" -ForegroundColor Yellow -BackgroundColor Red
        DisplayCommand "        to see the shared profiles that can be added >> " ".\GAMMA_EXT.ps1 -add "
        PromptMessageBeforeExit ""
    }

    
}
function RemoveProfile {
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $profileName
    )

    $profilePath = "$Global:pathToEXTProfiles/$profileName"

    if (Test-Path -Path $profilePath){
        ExitIfPathIsProhibited($profilePath)
        Remove-Item -Force -Recurse -LiteralPath $profilePath | Out-Null
    }else{
        Write-Host "Could not find profile $profileName in ./profiles" -ForegroundColor Yellow -BackgroundColor Red
    }
}

function UpdateAddon {
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $profileName
    )
    
    UpdateAddonProfile $profileName

}

function BuildKits {
    param (
        $profileName
    )
    
    $profileDefinitions = GetProfileDefinitions $profileName

    if ($null -eq $profileDefinitions){
        PromptErrorBeforeExit " Could not find profile definitions "
    }

    $kitsDefinitions = GetProfileKitsDefinitions $profileDefinitions.profileName

    if(!$kitsDefinitions){
        PromptErrorBeforeExit " Profile does not have kits " 
    }

    $buildDefinitions = Get-Content -Raw -LiteralPath "./profiles/$profileName/build.json" | ConvertFrom-Json

    if(!$buildDefinitions){
        PromptErrorBeforeExit " Profile does not have a build definitions " 
    }

    # create workspace folder
    $buildKitsWorkspace = "$Global:pathToEXTWorkspace/buildkits"
    New-Item -Path $buildKitsWorkspace -ItemType Directory

    foreach($buildProfile in $buildDefinitions.profiles){
        # inherit base profile definitions and common build properties
        $buildProfileDefinitions = $profileDefinitions.PsObject.Copy()
        $buildProfileDefinitions.profileName = $buildProfile.profileName
        $buildProfileDefinitions.info = $buildProfile.info
        $buildProfileDefinitions.installationDiskspaceRequirementMB = $buildProfile.installationDiskspaceRequirementMB
        $buildProfileDefinitions.finalDiskspaceRequirementMB = $buildProfile.finalDiskspaceRequirementMB
        $buildProfileDefinitions.installCompletionMessage = $buildProfile.installCompletionMessage

        # create profile build workspace
        $profileBuildWorkspace = "$buildKitsWorkspace/$($buildProfileDefinitions.profileName)"
        New-Item -Path $profileBuildWorkspace -ItemType Directory

        # build the addons for this new profile
        $buildAddonsList = @()
        foreach($addon in $buildProfile.addons){
        
            $profileDefinitions.addons | ForEach-Object { 
                if ($_.addonName -eq $addon.addonName){
                    $buildAddonsList += $_
                    continue 
                }
            }
        }
        $buildProfileDefinitions.addons = $buildAddonsList

        # build the customMods for this new profile
        $buildCustomModsList = @()
        foreach($customMod in $buildProfile.customMods){
        
            $profileDefinitions.customMods | ForEach-Object { 
                if ($_.modName -eq $customMod.modName){
                    $buildCustomModsList += $_
                    continue 
                }
            }
        }
        $buildProfileDefinitions.customMods = $buildCustomModsList

        Set-Content -LiteralPath "$profileBuildWorkspace/profile_definitions.json" -Value ($buildProfileDefinitions | ConvertTo-Json -Depth 5) -Force

        Copy-Item -LiteralPath "$Global:pathToEXTProfiles/$profileName/patches" -Destination "$profileBuildWorkspace" -Recurse

        # create kits for build profile
        New-Item -Path "$profileBuildWorkspace/kits" -ItemType Directory

        $buildKitsDefinitions = [PSCustomObject]@{
            profileName = $buildProfileDefinitions.profileName
        }

        $buildKitsList = @()
        foreach($kit in $buildProfile.kits){
            $kitsDefinitions.kits | ForEach-Object{
                if ($_.profileName -eq $kit.kitName){
                    $_.profileName = $kit.profileName
                    $buildKitsList += $_
                    continue 
                }
            } 
        }
        $buildKitsDefinitions | Add-Member -MemberType NoteProperty -Name "kits" -Value $buildKitsList

        Set-Content -LiteralPath "$profileBuildWorkspace/kits/kits_definitions.json" -Value ($buildKitsDefinitions | ConvertTo-Json -Depth 5) -Force

        # create the build profile shareable zip
        CreateSharedProfile $buildProfileDefinitions $profileBuildWorkspace
    }

    Remove-Item $buildKitsWorkspace -Force

}

function CloneProfile{
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $profileName     
    )

    DisplayProcessStep " Cloning Profile "

    if ($profileName -eq ""){
        Write-Host
        DisplayNoticeMessage " A profile from wich to clone was not specified! Cloning from G.A.M.M.A default profile "
        Write-Host
        $profileName = "G.A.M.M.A"    
    }else{
        $moProfilePath = "$Global:pathToMOProfiles/$profileName"
        if ((Test-Path -LiteralPath $moProfilePath) -eq $False) {
            Write-Host 
            DisplayWarningMessage " The profile ""$profileName"" you want to clone from does not exists in ModOrganizer "
            Write-Host 
            PromptMessageBeforeExit " Cloning was aborted "
        }
    }

    Write-Host 
    DisplayInfoText "You are cloning the profile $profileName as a new profile in Mod Organizer"
    Write-Host 
    DisplayInfoText "You must choose a name for this new profile making sure no other profile with the same name exists in Mod Organizer already "
    Write-Host 

    $clonedProfile = Read-Host "Enter the profile name: "

    $continue = $True
    while ($continue){

        $Title = "The new profile will be cloned as ""$clonedProfile"" in Mod Organizer"
        $Prompt = "Do you confirm this name?"
        $Choices = [System.Management.Automation.Host.ChoiceDescription[]] @("&Yes", "&No")
        $Default = 1
            
        # Prompt for the choice
        $Choice = $host.UI.PromptForChoice($Title, $Prompt, $Choices, $Default)
            
        # Action based on the choice
        switch($Choice)
        {
            0 { 
                $clonedProfilePath = "$Global:pathToMOProfiles/$clonedProfile"
                if (Test-Path -LiteralPath $clonedProfilePath) {
                    Write-Host 
                    DisplayNoticeMessage "A profile with the same name ""$clonedProfile"" already exists in Mod Organizer"
                    Write-Host 
                    $clonedProfile = Read-Host "Please enter a new name: "
                }else{
                    $continue = $False
                }
            }
            1 { $clonedProfile = Read-Host "Please enter a new name: " }
        }
    }   

    CloneProfileDefinitions $profileName $clonedProfile

    CloneProfileSettings $profileName $clonedProfile

    Write-Host
    DisplayInfoMessage " Cloning successful! "
    Write-Host
    DisplayInfoMessage " New profile created "
    DisplayInfoText "A new profile was created in Mod Organizer named $clonedProfile using $profileName as template" $tabIndent
    DisplayInfoText "Open Mod Organizer to select the new profile or check the new profile files at $pathToMOProfiles/$clonedProfile" $tabIndent
    DisplayInfoText "You are free to modify this profile modlist (add/remove mods, enable/disable mods, etc) any way you like" $tabIndent
    DisplayInfoText "You can use any EXT profile management shorcuts in MO like Reset Profile, Synch Profile, Save Profile" $tabIndent
    Write-Host
    DisplayInfoMessage " New settings created "
    DisplayInfoText "New profile settings have been created to support this new profile at $pathToEXTSettings/$clonedProfile" $tabIndent
    DisplayInfoText "Use these settings or edit them if you want to change something" $tabIndent
    DisplayInfoText "Make sure you apply these settings before launching this profile using the apply_settings, and the save_settings command to save them whenever you change someting [Settings/MCM Settings] in-game" $tabIndent
}

function RestoreProfile {
    param (
        [Parameter(Mandatory = $true, Position = 0)]
        $profileName,
        [Parameter(Mandatory = $true, Position = 1)]
        $target        
    )

    $profileDefinitions = GetProfileDefinitions $profileName

    if($null -eq $profileDefinitions){
        PromptErrorBeforeExit " Profile could not be found "
    } 

    $moProfileDefinitions = GetMOBuildProfileDefinitions $profileDefinitions.profileName

    if($null -eq $moProfileDefinitions){
        PromptErrorBeforeExit " Profile is not installed in MO "
    } 

    if ($moProfileDefinitions.version -ne $profileDefinitions.version){
        PromptErrorBeforeExit " Profile definitions in EXT has a different version [$($profileDefinitions.version)] from the installed profile version [$($moProfileDefinitions.version)]. Cannot restore $target "
    }

    if ($target -eq "settings"){
        # create gamePatches workspace
        CreateGamePatchesWorkspace $profileDefinitions
        CreateProfileSettings $profileDefinitions
        if(!$dev.IsPresent){
            ClearWorkspaces
        }
    }
    if ($target -eq "moprofile"){

        CreateMOProfile $profileDefinitions
    }
}

function RegisterPlugin {
    param (
        [Parameter(Mandatory = $true, Position = 0)]
        $profileName
    )
    
    $plugin_path = "$Global:pathToEXTProfiles/$profileName/plugin.ps1"

    if (Test-Path -Path $plugin_path){
        return $plugin_path
    }else{
        return $null
    }
}

function EnableAutomaticDownload {

    Write-Host
    if ($Global:autodl -eq $true){
        DisplayNoticeMessage " Automatic Downloads is already enabled in EXT " $tabIndent
        Write-Host
        DisplayInfoText "to disable this feature " ($tabIndent + $tabIndent)
        Write-Host
        DisplayPositiveText "run > .\GAMMA_EXT.ps1 -disable automatic-dl" ($tabIndent + $tabIndent)                  
    }else{
        PromptAutomaticDownloadsDisclaimer
        Write-Host
        $extIni = [ExtIni]::new()
        $extIni.Load($Global:pathToExtIni)
        $extIni.EditProperty("automatic_dl", $true)
        $extIni.EditProperty("confirmation_dl", $true)
        $extIni.Save()   
        DisplayInfoMessage " EXT is now configured with Automatic Downloads enabled " $tabIndent
        $Global:autodl = $true
        $Global:confirmdl = $true
        Write-Host
        DisplayInfoText "to disable this feature" ($tabIndent + $tabIndent)
        Write-Host
        DisplayPositiveText "run > .\GAMMA_EXT.ps1 -disable automatic-dl" ($tabIndent + $tabIndent)
        Write-Host
        DisplayInfoText "Automatic Downloads by default will ask for confirmation before proceeding to download any addons" $tabIndent
        Write-Host
        DisplayInfoText "to disable this prompt" ($tabIndent + $tabIndent)
        Write-Host
        DisplayPositiveText "run >  .\GAMMA_EXT.ps1 -disable confirmation-dl" ($tabIndent + $tabIndent)          
    }
}

function DisableAutomaticDownload {

    Write-Host
    if ($Global:autodl -eq $false){
        DisplayNoticeMessage " Automatic Downloads is already disabled in EXT " $tabIndent
    }else{

        $extIni = [ExtIni]::new()
        $extIni.Load($Global:pathToExtIni)
        $extIni.EditProperty("automatic_dl", $false)
        $extIni.EditProperty("confirmation_dl", $true)
        $extIni.Save()   
        DisplayInfoMessage " EXT is now configured with Automatic Downloads disabled " $tabIndent
        $Global:autodl = $false
        $Global:confirmdl = $true
    }
    Write-Host
    DisplayInfoText "to enable this feature" ($tabIndent + $tabIndent)
    Write-Host
    DisplayPositiveText "run > .\GAMMA_EXT.ps1 -enable automatic-dl" ($tabIndent + $tabIndent)           
}

function EnableConfirmationDownload {

    Write-Host
    if ($Global:confirmdl -eq $true){
        DisplayNoticeMessage " Confirmation Downloads is already enabled in EXT " $tabIndent
    }else{
        Write-Host
        $extIni = [ExtIni]::new()
        $extIni.Load($Global:pathToExtIni)
        $extIni.EditProperty("confirmation_dl", $true)
        $extIni.Save()   
        DisplayInfoMessage " EXT is now configured with Confirmation Downloads enabled " $tabIndent
        $Global:confirmdl = $true
    }
    Write-Host
    DisplayInfoText "to disable this feature" ($tabIndent + $tabIndent)
    Write-Host
    DisplayPositiveText "run > .\GAMMA_EXT.ps1 -disable confirmation-dl" ($tabIndent + $tabIndent)    
}

function DisableConfirmationDownload {

    Write-Host
    if ($Global:confirmdl -eq $false){
        DisplayNoticeMessage " Confirmation Downloads is already disabled in EXT " $tabIndent
    }else{
        PromptConfirmationDownloadsDisclaimer
        Write-Host
        $extIni = [ExtIni]::new()
        $extIni.Load($Global:pathToExtIni)
        $extIni.EditProperty("confirmation_dl", $false)
        $extIni.Save()   
        DisplayInfoMessage " EXT is now configured with Confirmation Downloads disabled " $tabIndent
        $Global:confirmdl = $false
    }
    Write-Host
    DisplayInfoText "to enable this feature" ($tabIndent + $tabIndent)
    Write-Host
    DisplayPositiveText "run > .\GAMMA_EXT.ps1 -enable confirmation-dl" ($tabIndent + $tabIndent)    
}

function EnableBrowserDownload {

    Write-Host
    if ($Global:browserdl -eq $true){
        DisplayNoticeMessage " Browser Downloads is already enabled in EXT " $tabIndent
    }else{
        PromptBrowserDownloadsDisclaimer

        Write-Host
        $extIni = [ExtIni]::new()
        $extIni.Load($Global:pathToExtIni)
        $extIni.EditProperty("browser_dl", $true)
        $extIni.Save()   
        DisplayInfoMessage " EXT is now configured with Browser Downloads enabled " $tabIndent
        DisplayInfoMessage " You can close the EXT session browser window again " $tabIndent
        $Global:browserdl = $true
    }
    Write-Host
    DisplayInfoText "to disable this feature" ($tabIndent + $tabIndent)
    Write-Host
    DisplayPositiveText "run > .\GAMMA_EXT.ps1 -disable browser-dl" ($tabIndent + $tabIndent)    
}

function DisableBrowserDownload {

    Write-Host
    if ($Global:browserdl -eq $false){
        DisplayNoticeMessage " Browser Downloads is already disabled in EXT " $tabIndent
    }else{

        Write-Host
        DisplayNoticePause " Attention, you are disabling Browser Downloads. Close any EXT session open browser windows before doing so "
        Write-Host
        if (Test-Path $Global:pathToEXTBrowserProfile) {
            Remove-Item -Force -Recurse -Path $Global:pathToEXTBrowserProfile | Out-Null
        }
        Write-Host
        $extIni = [ExtIni]::new()
        $extIni.Load($Global:pathToExtIni)
        $extIni.EditProperty("browser_dl", $false)
        $extIni.Save()   
        DisplayInfoMessage " EXT is now configured with Browser Downloads disabled " $tabIndent
        $Global:browserdl = $false
    }
    Write-Host
    DisplayInfoText "to enable this feature" ($tabIndent + $tabIndent)
    Write-Host
    DisplayPositiveText "run > .\GAMMA_EXT.ps1 -enable browser-dl" ($tabIndent + $tabIndent)    
}

function GetSharedProfiles {
    param (
        [Parameter(Mandatory = $true, Position = 0)]
        $profileName,
        [Parameter(Mandatory = $false, Position = 1)]
        $autoConfirm   
    )

    DisplayProcessStep " Get Profiles "
    
    $WebClient = New-Object System.Net.WebClient

    $extDefinitions = GetProfileDefinitions "EXT Profiles"

    if ($null -eq $extDefinitions){
        PromptErrorBeforeExit " Could not find EXT profiles definitions "
    }

    if ($profileName){
        $extProfile = $extDefinitions.profiles | Where-Object {$_.name -eq $profileName}
        if ($null -eq $extProfile){
            PromptErrorBeforeExit " Could not find download profiles definitions for $profileName "
        }
        try{
            DownloadProfile $extProfile $WebClient
            $allowExit = $false
            AddProfile $extProfile.filename $allowExit $autoConfirm
        }
        catch {
            Write-Host
            DisplayWarningMessage " Profile download failed "
            Write-Host
            DisplayNegativeText "The profile could not be downloaded from the EXT repositories "
            DisplayNegativeText "Error message: $_"
            PromptErrorBeforeExit " Could not find download profiles definitions "
        }

    }else{
        foreach ($extProfile in $extDefinitions.profiles) {
            try{
                DownloadProfile $extProfile $WebClient
                $allowExit = $false
                AddProfile $extProfile.filename $allowExit $autoConfirm
            }
            catch {
                Write-Host
                DisplayWarningMessage " Profile download failed "
                Write-Host
                DisplayNegativeText "The profile could not be downloaded from the EXT repositories "
                DisplayNegativeText "Error message: $_"
                PromptErrorBeforeExit " Could not find download profiles definitions "
            }
        }
    }
}

function UpdateAddonDefinitions {
    param (
        [Parameter(Mandatory = $true, Position = 0)]
        $profileName,
        [Parameter(Mandatory = $true, Position = 1)]
        $addonName          
    )

    $profileDefinitions = GetProfileDefinitions $profileName

    if($null -eq $profileDefinitions){
        PromptErrorBeforeExit " Profile could not be found "
    } 

    $addon = GetAddonDefinitions $profileDefinitions $addonName

    if($null -eq $addon){
        PromptErrorBeforeExit " Addon could not be found "
    } 

    DisplayProcessStep " Update Addon Definitions "
    Write-Host
    DisplayAddonName $addon.addonName $tabIndent
    Write-Host
    DisplayInfoText "Addon file: $($addon.resourceFilename)" ($tabIndent + $tabIndent)                
    Write-Host
    DisplayInfoText "Addon page: $($addon.addonUrl)" ($tabIndent + $tabIndent)
    Write-Host
    DisplayInfoText "Download link: $($addon.fileUrl)" ($tabIndent + $tabIndent)
    Write-Host     

    Write-Host 
    DisplayInfoText "You are updating this addon definitions"
    Write-Host 

    DisplayProcessSubStep " Addon file " ($tabIndent)
    Write-Host 
    $resourceFilename = Read-Host "Enter the new value for Addon file: "
    $continue = $True
    while ($continue){

        $Title = "the new value for Addon file will be as ""$resourceFilename"""
        $Prompt = "Do you confirm this value?"
        $Choices = [System.Management.Automation.Host.ChoiceDescription[]] @("&Yes", "&No")
        $Default = 1
            
        # Prompt for the choice
        $Choice = $host.UI.PromptForChoice($Title, $Prompt, $Choices, $Default)
            
        # Action based on the choice
        switch($Choice)
        {
            0 { 
                $addon.resourceFilename = $resourceFilename
                $continue = $False
            }
            1 { $resourceFilename = Read-Host "Enter the new value for Addon file: " }
        }
    }     

    Write-Host 
    DisplayProcessSubStep " Download link " ($tabIndent)
    Write-Host 
    $fileUrl = Read-Host "Enter the new value for Download link: "
    $continue = $True
    while ($continue){

        $Title = "the new value for Download link will be as ""$fileUrl"""
        $Prompt = "Do you confirm this value?"
        $Choices = [System.Management.Automation.Host.ChoiceDescription[]] @("&Yes", "&No")
        $Default = 1
            
        # Prompt for the choice
        $Choice = $host.UI.PromptForChoice($Title, $Prompt, $Choices, $Default)
            
        # Action based on the choice
        switch($Choice)
        {
            0 { 
                $addon.fileUrl = $fileUrl
                $continue = $False
            }
            1 { $fileUrl = Read-Host "Enter the new value for Download link: " }
        }
    } 

    Set-Content -LiteralPath "$pathToEXTProfiles/$profileName/profile_definitions.json" -Value ($profileDefinitions | ConvertTo-Json -Depth 5)

    Write-Host 
    DisplayInfoMessage " Updated Addon Definitions "
    Write-Host
    DisplayAddonName $addon.addonName $tabIndent
    Write-Host
    DisplayNoticeText "Addon file: $($addon.resourceFilename)" ($tabIndent + $tabIndent)                
    Write-Host
    DisplayInfoText "Addon page: $($addon.addonUrl)" ($tabIndent + $tabIndent)
    Write-Host
    DisplayNoticeText "Download link: $($addon.fileUrl)" ($tabIndent + $tabIndent)
    Write-Host  

}

function CreateDummy {
    param (
        [Parameter(Mandatory = $true, Position = 0)]
        $profileName,
        [Parameter(Mandatory = $true, Position = 1)]
        $addonName          
    )
    
    DisplayProcessStep " CreateDummy "

    $profileDefinitions = GetProfileDefinitions $profileName

    if($null -eq $profileDefinitions){
        PromptErrorBeforeExit " Profile could not be found "
    } 

    $addon = GetAddonDefinitions $profileDefinitions $addonName

    if($null -eq $addon){
        PromptErrorBeforeExit " Addon could not be found "
    } 

    New-Item -Path "$pathToEXTWorkspace/$($addon.addonName)" -ItemType Directory | Out-Null
    New-Item -Path "$pathToEXTWorkspace/$($addon.addonName)/gamedata" -ItemType Directory | Out-Null
    New-Item -Path "$pathToEXTWorkspace/$($addon.addonName)/gamedata/dummy.txt" -ItemType File | Out-Null

    $destination = GetAddonResourcePath $addon

    if ($addon.resourceFilename.EndsWith(".7z")){
        Create7z "$pathToEXTWorkspace\$($addon.addonName)\*" $destination 
    }else{
        CreateArchive "$pathToEXTWorkspace/$($addon.addonName)/gamedata" $destination 
    }

    Remove-Item -Path "$pathToEXTWorkspace\$($addon.addonName)" -Recurse -Force

    Write-Host
    DisplayPositiveText ">> dummy archive created at $destination"
}

function MakeProfile {
    param (
        [Parameter(Mandatory = $true, Position = 0)]
        $profileName,
        [Parameter(Mandatory = $true, Position = 1)]
        $option        
    )

    DisplayProcessStep " Make Profile $option"
    Write-Host
    DisplayInfoText "You are making a build of the current profile: $profileName"
    DisplayInfoText "This might take some time, minutes or few hours depending on your pc and the lenght of the modlist"
    Write-Host

    $Title = "Make Profile starting"
    $Prompt = "Do you want to continue?"
    $Choices = [System.Management.Automation.Host.ChoiceDescription[]] @("&Yes", "&No")
    $Default = 1
        
    # Prompt for the choice
    $Choice = $host.UI.PromptForChoice($Title, $Prompt, $Choices, $Default)
        
    # Action based on the choice
    switch($Choice)
    {
        0 { 
            # continue
        }
        1 { 
            DisplayNoticeMessage "Make Profile Aborted "
            return
     }
    }

    if ($profileName.StartsWith("[ EXT MAKE ]")){
        PromptErrorBeforeExit " Cannot Make Profile "
    }

    $moprofile = "[ EXT MAKE ] " + $profileName 
    
    Write-Host
    DisplayProcessStep " Make Profile Name choice "
    Write-Host
    DisplayInfoText "Make Profile will create a build of your current profile (a merge of the currently selected mods) to a new profile named $moprofile" $tabIndent
    DisplayInfoText "if the profile exists (you have made previous builds) it will be overwritten" $tabIndent
    Write-Host
    DisplayInfoText "The build of Make Profile, the gamedata files or xray archives, depeding on the option chosen, will be placed into a dedicated mod called $moprofile" $tabIndent
    DisplayInfoText "The mod will be the only active mod in the new profile $moprofile thus created" $tabIndent
    Write-Host
    $Title = "The new profile will be created as ""$moprofile"" in Mod Organizer but you can choose another name or profile if you wish"
    $Prompt = "Do you confirm this choice?"
    $Choices = [System.Management.Automation.Host.ChoiceDescription[]] @("&Yes", "&No")
    $Default = 1
        
    # Prompt for the choice
    $Choice = $host.UI.PromptForChoice($Title, $Prompt, $Choices, $Default)
        
    # Action based on the choice
    switch($Choice)
    {
        1 { 
            $customProfileName = Read-Host "Enter the profile name: "

            $moprofile = "[ EXT MAKE ] " + $customProfileName
            Write-Host
            $continue = $True
            while ($continue){
        
                $Title = "The made profile will be created as ""$moprofile"" in Mod Organizer but you can choose another name or profile if you wish"
                $Prompt = "Do you confirm this choice?"
                $Choices = [System.Management.Automation.Host.ChoiceDescription[]] @("&Yes", "&No")
                $Default = 1
                    
                # Prompt for the choice
                $Choice = $host.UI.PromptForChoice($Title, $Prompt, $Choices, $Default)
                    
                # Action based on the choice
                switch($Choice)
                {
                    0 { 
                        # you confirm the name, lets carry on
                        $continue = $false
                    }
                    1 { 
                        $customProfileName = Read-Host "Enter the profile name: "
                        $moprofile = "[ EXT MAKE ] " + $customProfileName
                        Write-Host                        
                    }
                }
            }   
        }
        0 { 
            # you have accepted default name
         }
    }

    DisplayProcessStep " creating the made profile in MO "
    # create MO profile
    if((Test-Path -LiteralPath "$Global:pathToMOProfiles/$moprofile") -eq $false){

        New-Item -Path "$Global:pathToMOProfiles/$moprofile" -ItemType Directory | Out-Null
        New-Item -Path "$Global:pathToMOProfiles/$moprofile/modlist.txt" -ItemType File | Out-Null
        Add-Content -LiteralPath "$Global:pathToMOProfiles/$moprofile/modlist.txt" "`n+$moprofile"
        # load template definitions
        $templateProfileDefinitions = GetTemplateProfileDefinitions
        # update profile definitions
        $templateProfileDefinitions.profileName = $moprofile
        $customModDefinition = [PSCustomObject]@{
            modName = $moprofile
            info = ""
            modType = "mod"
            addonName = ""
        }
        $templateProfileDefinitions.customMods += $customModDefinition
        $customLoadOrderRule = [PSCustomObject]@{
            modName = $moprofile
            action = "add"
        }
        $templateProfileDefinitions.customLoadOrderRules += $customLoadOrderRule
        # save profiles definitions
        Set-Content -LiteralPath "$Global:pathToMOProfiles/$moprofile/build_profile_definitions.json" -Value ($templateProfileDefinitions | ConvertTo-Json -Depth 5)
        Set-Content -LiteralPath "$Global:pathToMOProfiles/$moprofile/profile_definitions.json" -Value ($templateProfileDefinitions | ConvertTo-Json -Depth 5)
    }

    DisplayProcessStep " creating made profile mod "
    # create made profile mod
    if ((Test-Path -LiteralPath "$Global:pathToMOMods/$moprofile") -eq $false){
        New-Item -Path "$Global:pathToMOMods/$moprofile" -ItemType Directory | Out-Null
        New-Item -Path "$Global:pathToMOMods/$moprofile/db" -ItemType Directory | Out-Null
        New-Item -Path "$Global:pathToMOMods/$moprofile/db/mods" -ItemType Directory | Out-Null
        New-Item -Path "$Global:pathToMOMods/$moprofile/db/addons" -ItemType Directory | Out-Null
        New-Item -Path "$Global:pathToMOMods/$moprofile/appdata" -ItemType Directory | Out-Null
    }

    DisplayProcessStep " creating made profile settings "
    # create profile settings
    Copy-Item -LiteralPath "$Global:pathToEXTSettings/$profileName" -Destination "$Global:pathToEXTSettings/$moprofile"  -Recurse -Force

    if ($option -eq "build"){
        
        # compressing gamedata
        DisplayProcessStep " Packing profile files "
        PackXr "..\Anomaly\gamedata"

        DisplayProcessStep " packaging made profile mod "
        # packaging gamedata xr archives
        DisplayProcessSubStep " adding xr archives to made profile mod " $tabIndent
        $modDbMods = "$Global:pathToMOMods/$moprofile/db/mods"
        $destination =  [WildcardPattern]::Escape($modDbMods)
        Move-Item -Path "..\Anomaly\*.db*" -Destination $destination -Force
        
        # packaging mods
        DisplayProcessSubStep " adding mods to made profile mod " $tabIndent
        $destination = "$Global:pathToMOMods/$moprofile/db/mods"
        Copy-Item -Path (Get-Item -Path "..\Anomaly\db\mods\*" -Exclude ('000_shader_placeholder.db0')).FullName -Destination $destination -Recurse -Force
    
        # packaging addons
        DisplayProcessSubStep " adding addons to made profile mod " $tabIndent
        $destination = "$Global:pathToMOMods/$moprofile/db/addons"
        Copy-Item -Path (Get-Item -Path "..\Anomaly\db\addons\*").FullName -Destination $destination -Recurse -Force
    
    }elseif ($option -eq "src"){
        if (Test-Path -LiteralPath "$Global:pathToMOMods/$moprofile/gamedata" ){
            DisplayProcessSubStep " removing previous gamedata make files " $tabIndent
            Remove-Item "$Global:pathToMOMods/$moprofile/gamedata" -Force -Recurse
        }
        DisplayProcessSubStep " copying profile gamedata source " $tabIndent
        Copy-Item -Path "..\Anomaly\gamedata" -Destination "$Global:pathToMOMods/$moprofile" -Recurse -Force
    }else{
        DisplayErrorMessage "Please specify if you want to make a build or source"
        exit
    }

    # packaging appdata
    DisplayProcessSubStep " adding appdata to made profile mod " $tabIndent
#     $destination = "$Global:pathToMOMods/$moprofile/appdata"
#     Copy-Item -Path (Get-Item -Path "..\Anomaly\appdata\*" -Exclude ('logs', 'savedgames', 'screenshots', 'shader_cache', 'manual_edits_settings.ltx', 'saved_settings.ltx', 'mcm_saved_settings.ltx', 'profile.ltx', 'user.ltx')).FullName -Destination $destination -Recurse -Force
    $modAppdata = "$Global:pathToMOMods/$moprofile/appdata"
    $vfsAppdata =  Get-Item -Path "..\Anomaly\appdata\*" -Exclude ('logs', 'savedgames', 'screenshots', 'shaders_cache', 'manual_edits_settings.ltx', 'saved_settings.ltx', 'mcm_saved_settings.ltx', 'profile.ltx', 'user.ltx')
    if ($null -ne $vfsAppdata){
        Copy-Item -Path $vfsAppdata.FullName -Destination $modAppdata -Recurse -Force
    }
}

function CompileAddonsHashes {
    param (
        [Parameter(Mandatory = $true, Position = 0)]
        $profileName
    )

    $profileDefinitions = GetProfileDefinitions $profileName

    if($null -eq $profileDefinitions){
        PromptErrorBeforeExit " Profile could not be found "
    } 

    $addons = $profileDefinitions.addons

    if($null -eq $addons){
        PromptErrorBeforeExit " Profile does not have addons "
    } 

    DisplayProcessStep " Compiling Addons Hashes "

    $addons | ForEach-Object {
        $addon = $_
        # escape this path below
        $addonPath = [WildcardPattern]::Escape($(GetAddonResourcePath $addon))
        
        if (Test-Path -Path $addonPath){

            $hash = Get-FileHash -Path $addonPath -Algorithm SHA256
            DisplayInfoText "Addon: $($addon.addonName) hash: $($hash.Hash)" $tabIndent

            if (!($addon.PSObject.Properties.Name -contains 'hash')) {
                $addon | Add-Member -NotePropertyName 'hash' -NotePropertyValue $hash.Hash
            } else {
                $addon.hash =  $addon.hash
            }
        }
    }

    Set-Content -LiteralPath "$pathToEXTProfiles/$profileName/profile_definitions.json" -Value ($profileDefinitions | ConvertTo-Json -Depth 5)
}
function CompileAddonHash {
    param (
        [Parameter(Mandatory = $true, Position = 0)]
        $profileName,
        [Parameter(Mandatory = $true, Position = 1)]
        $addonName
    )

    $profileDefinitions = GetProfileDefinitions $profileName

    if($null -eq $profileDefinitions){
        PromptErrorBeforeExit " Profile could not be found "
    } 

    $addon = GetAddonDefinitions $profileDefinitions $addonName

    if($null -eq $addon){
        PromptErrorBeforeExit " Addon could not be found "
    } 

    $addonPath = [WildcardPattern]::Escape($(GetAddonResourcePath $addon))
    if (Test-Path -Path $addonPath){
        # display size of the addon file
        $addonSize = (Get-Item -Path $addonPath).length / 1MB
        DisplayInfoText "Addon: $($addon.addonName) size: $([math]::Round($addonSize, 2)) MB" $tabIndent
        
        # Unpack addon in workspace and calculate size of the folder
        CreateAddonWorkspace $addon
        # escape this path below
        $addonWorkspace = [WildcardPattern]::Escape("$pathToEXTWorkspace/$($addon.resourceWorkspace)")
        $addonWorkspaceSize = (Get-ChildItem -LiteralPath $addonWorkspace -Recurse | Measure-Object -Property length -Sum).Sum / 1MB
        DisplayInfoText "Addon: $($addon.addonName) workspace size: $([math]::Round($addonWorkspaceSize, 2)) MB" $tabIndent
        Remove-Item -LiteralPath $addonWorkspace -Recurse -Force
        
        # calculate hash of the addon file
        $hash = Get-FileHash -Path $addonPath -Algorithm SHA256
        if (!($addon.PSObject.Properties.Name -contains 'hash')) {
            $addon | Add-Member -NotePropertyName 'hash' -NotePropertyValue $hash.Hash
        } else {
            $addon.hash =  $addon.hash = $hash.Hash
        }
    }else{
        DisplayWarningMessage " Addon could not be found " $tabIndent
    }

    DisplayInfoText "Addon: $($addon.addonName) hash: $($hash.Hash)" $tabIndent
}
function GetAvailableSpace{

    $folder = Get-Item -Path $AppProps.'gammafolder'
    $thisDrive = ($folder.FullName).Substring(0,1)
    $volumeInfo = Get-Volume -DriveLetter $thisDrive | Select-Object -Property SizeRemaining
    return $volumeInfo.SizeRemaining
}

function DisplaychangeLogEntry($changeLogEntry) {

    DisplayInfoMessage "Latest changelog version: $($changeLogEntry.version)"
    # Process the download section
    DisplayProcessStep "Addons to download:"
    Write-Host
    foreach ($downloadEntry in $changeLogEntry.download) {
        $addonName = $downloadEntry.addonName
        $addon = $profileDefinitions.addons | Where-Object { $_.addonName -eq $addonName }
        if ($null -ne $addon) {
            DisplayAddonName $addon.addonName $tabIndent
            DisplayInfoText "Addon URL: $($addon.addonUrl)" ($tabIndent + $tabIndent)
            DisplayInfoText "File URL: $($addon.fileUrl)" ($tabIndent + $tabIndent)
        } else {
            DisplayWarningMessage "Addon $addonName not found in profile definitions."
        }
        Write-Host
    }
    # Process the delete section
    DisplayProcessStep "Mods to Delete:"
    foreach ($deleteEntry in $changeLogEntry.delete) {
        DisplayModName $deleteEntry.modName $tabIndent
    }

    # Process the update section
    DisplayProcessStep "Mods to update/install :"
    foreach ($updateEntry in $changeLogEntry.update) {
        DisplayModName $updateEntry.modName $tabIndent
    }
}

function ListChangeLog {
    param (
        [Parameter(Mandatory = $true, Position = 0)]
        $profileName,
        [Parameter(Mandatory = $true, Position = 1)]
        $version
    )

    $profileDefinitions = GetProfileDefinitions $profileName

    if ($null -eq $profileDefinitions) {
        PromptErrorBeforeExit " Profile could not be found "
    }

    $changeLogDefinitions = GetChangeLogDefinitions $profileName

    if ($null -eq $changeLogDefinitions) {
        PromptErrorBeforeExit " ChangeLog could not be found "
    }

    if (($null -eq $version) -or ("" -eq $version)) {
        # Find the changelog entry with the greatest version
        $greatestVersionEntry = $null
        foreach ($entry in $changeLogDefinitions.changelog) {
            if ($null -eq $greatestVersionEntry -or $entry.version -gt $greatestVersionEntry.version) {
                $greatestVersionEntry = $entry
            }
        }

        if ($null -ne $greatestVersionEntry) {
            DisplaychangeLogEntry $greatestVersionEntry
        } else {
            DisplayWarningMessage "No changelog entries found."
        }
    }else{
        $versionEntry = $changeLogDefinitions.changelog | Where-Object { $_.version -eq $version }
        if ($null -ne $versionEntry) {
            DisplaychangeLogEntry $versionEntry
        } else {
            DisplayWarningMessage "No changelog entries found for version $version."
        }
    }
}

####################    MAIN    ####################

$banner = Get-Content -Path $Global:WelcomeBanner -Raw

Write-Host -ForegroundColor DarkGreen -BackgroundColor Black $banner

Write-Host -ForegroundColor DarkGreen -BackgroundColor Black "Version $($Global:version | % { '{0:0.00}' -f $_ }) "

Write-Host


if ($info.IsPresent){

    DisplayInfo $profileName

    PromptMessageBeforeExitNoPause " DisplayInfo Completed! "
}
if ($install.IsPresent){

    if(!$dev.IsPresent){
        ClearWorkspaces
    }

    InstallProfile $profileName $secondParam

    PromptMessageBeforeExitNoPause " InstallProfile Completed! "
}

if ($listprofiles.IsPresent){

    ListProfiles

    PromptMessageBeforeExitNoPause " ListProfiles Completed! "
}

if ($listaddons.IsPresent){

    if ($addon.IsPresent){
        ListAddon $profileName $secondParam
    }else{
        ListAddons $profileName $secondParam
    }
    

    PromptMessageBeforeExitNoPause " ListAddons Completed! "
}

if ($listmods.IsPresent){

    ListMods $profileName

    PromptMessageBeforeExitNoPause " ListMods Completed! "
}

if ($verify.IsPresent){

    $verification = [PSCustomObject]@{
        profileName = $profileName
        isForInstall = $false
        isVerifed = $true
        failureLogs = @()
    }

    if ($addon.IsPresent){
        Write-Host addon verification
        $verification = VerifyAddon $verification $secondParam
    }else{
        Verify $verification $secondParam
    }

    If ($verification.isVerifed -eq $false){
        DisplayVerification $verification
        Write-Host
        PromptErrorBeforeExitNoPause "Installation of $profileName is not possible due to some missing preconditions" 
    }else{
        DisplaySuccessMessage " Verification Passed "
        Write-Host
        DisplayNoticeMessage " Commands available: "
        DisplayEligibleCommands $profileName
    }

    PromptMessageBeforeExitNoPause " Verify Completed! "
}

if ($uninstall.IsPresent){

    if(!$dev.IsPresent){
        ClearWorkspaces
    }

    Uninstall $profileName
    
    PromptMessageBeforeExitNoPause "Uninstall Completed!"
}

if ($reset.IsPresent){

    $profileName = GetActiveMOProfile
    ResetProfile $profileName

    PromptMessageBeforeExit "ResetProfile Completed!"
}

if ($save.IsPresent){

    $profileName = GetActiveMOProfile
    $profileDefinitions = GetMOProfileDefinitions $profileName
    $forExport = $false 
    SaveProfile $profileDefinitions $forExport
    PromptMessageBeforeExit "SaveProfile Completed!"
}

if ($synch.IsPresent){

    if ($all.IsPresent){
        SyncAll
    }else{

        $profileName = GetActiveMOProfile
        $profileDefinitions = GetMOProfileDefinitions $profileName

        if ($null -eq $profileDefinitions){
            PromptMessageBeforeExit " This profile is $profileName not installed in MO "
        }

        SynchProfile $profileDefinitions

        if ("clone" -eq $profileDefinitions.profileType){
            SynchSettings $profileDefinitions

            if(!$dev.IsPresent){
                ClearWorkspaces
            }
        }
    }
    Write-Host
    DisplaySyncCompletionMessage
    PromptMessageBeforeExit "SynchProfile Completed!"
}

if ($export.IsPresent){

    #ExportAsEXTProfile $profileName
    PromptMessageBeforeExit "Export Not Implemented Yet!"
}

if ($share.IsPresent){

    if(!$dev.IsPresent){
        ClearWorkspaces
    }    

    ShareProfile $profileName
    PromptMessageBeforeExitNoPause "Share Completed!"
}

if ($apply_settings.IsPresent){
    
    ApplySettings
    PromptMessageBeforeExit ""
}

if ($switch_settings.IsPresent){

    #SwitchSettings
    PromptMessageBeforeExit "SwitchSettings Not Implemented Yet!"
}

if ($save_settings.IsPresent){

    SaveSettings
    PromptMessageBeforeExit "SaveSettings Completed!"
}
if ($clear_settings.IsPresent){
    ClearSettings
    PromptMessageBeforeExitNoPause "ClearSettings Completed!"
}
if ($add.IsPresent){
    $allowExit = $true
    AddProfile $profileName $allowExit
    PromptMessageBeforeExitNoPause "Add profile Completed! "
}

if ($remove.IsPresent){

    RemoveProfile $profileName
    DisplayNoticeMessage " Profile Settings have been kept for future use "
    PromptMessageBeforeExitNoPause " Remove profile Completed! "
}

if ($buildkits.IsPresent){

    BuildKits $profileName

    PromptMessageBeforeExitNoPause " BuildKits Completed! "
}
if ($update.IsPresent){

    if(!$dev.IsPresent){
        ClearWorkspaces
    }

    if ($mod.IsPresent){

        $Global:optionsList = @()
        if ($null -ne $thirdParam){
            $Global:optionsList = $thirdParam -split ","
        }        
        if ($Global:optionsList -contains "offline"){
            UpdateMod $profileName $secondParam
        }else{
            UpdateModWithAddons $profileName $secondParam $Global:optionsList
        }
    }else{
        Update $profileName $secondParam

        UpdateClones $profileName
    }
    
    if(!$dev.IsPresent){
        ClearWorkspaces
    }
    
    PromptMessageBeforeExitNoPause " Update Completed! "
}

if($changeLog.IsPresent){

    ListChangeLog $profileName $secondParam

    PromptMessageBeforeExitNoPause " ChangeLog Completed! "
}

if($updatedefinitions.IsPresent){

    if($addon.IsPresent){
        UpdateAddonDefinitions $profileName $secondParam
    }

    PromptMessageBeforeExitNoPause " Update Definitions Completed! "
}

if ($debuginfo.IsPresent){

    if ($short.IsPresent){
        DisplayDebugInfo
    }elseif($anomaly.IsPresent){
        DisplayDebugInfoAnomaly
    }elseif($mo.IsPresent){
        DisplayDebugInfoMO
    }elseif($moprofiles.IsPresent){
        DisplayDebugInfoMOProfiles
    }elseif($moini.IsPresent){
        DisplayDebugInfoMOIni
    }else{
        DisplayDebugInfoFull
    }

    PromptMessageBeforeExitNoPause " Debug Info Completed! "
}

if ($clone.IsPresent){

    if(!$dev.IsPresent){
        ClearWorkspaces
    }

    CloneProfile $profileName
    PromptMessageBeforeExitNoPause " Clone profile Completed! "
}

if ($restore.IsPresent){

    if ($secondParam -eq "moprofile"){
        RestoreProfile $profileName "moprofile"
    }elseif($secondParam -eq "settings"){
        RestoreProfile $profileName "settings"
    }else{
        DisplayNoticeMessage " A wrong parameter was entered "
        Write-Host
        DisplayProcessSubStep " Restore Profile Settings Quick Help " ($tabIndent  + $tabIndent)        
        DisplayPositiveText "run > .\GAMMA_EXT.ps1 -restore `"$profileName`" settings" ($tabIndent  + $tabIndent + $tabIndent)
        Write-Host
        DisplayProcessSubStep " Restore Profile Modlists Quick Help " ($tabIndent  + $tabIndent)        
        DisplayPositiveText "run > .\GAMMA_EXT.ps1 -restore `"$profileName`" moprofile" ($tabIndent  + $tabIndent + $tabIndent)
    }
    
    PromptMessageBeforeExitNoPause " Restore Completed! "
}

if ($enable.IsPresent){

    if ($profileName -eq "automatic-dl"){
        DisplayProcessStep " Enabling Automatic Downloads "
        EnableAutomaticDownload
    }
    if ($profileName -eq "confirmation-dl"){
        DisplayProcessStep " Enabling Confirmation Downloads "
        EnableConfirmationDownload
    }

    if ($profileName -eq "browser-dl"){
        DisplayProcessStep " Enabling Browser Downloads "
        EnableBrowserDownload
    }    

    PromptMessageBeforeExitNoPause " Enable $profileName feature Completed! "
}

if ($disable.IsPresent){

    if ($profileName -eq "automatic-dl"){
        DisplayProcessStep " Disabling Automatic Downloads "
        DisableAutomaticDownload
    }
    if ($profileName -eq "confirmation-dl"){
        DisplayProcessStep " Disabling Confirmation Downloads "
        DisableConfirmationDownload
    }
    if ($profileName -eq "browser-dl"){
        DisplayProcessStep " Disabling Browser Downloads "
        DisableBrowserDownload
    }        
    PromptMessageBeforeExitNoPause " Disable $profileName feature Completed! "
}

if ($getprofiles.IsPresent){

    GetSharedProfiles $profileName

    PromptMessageBeforeExitNoPause " Get Profile Completed! "
}

if ($createdummy.IsPresent){

    if($null -eq $profileName -and $profileName -eq ""){
        PromptMessageBeforeExitNoPause " A profile was not specified "
    }

    if ($addon.IsPresent){

        if($null -eq $secondParam -and $secondParam -eq ""){
            PromptMessageBeforeExitNoPause " The addon name was not specified "
        }

        CreateDummy $profileName $secondParam
    }

    PromptMessageBeforeExitNoPause " Create Dummy Completed! "
}

if ($help.IsPresent){

    ShowHelpEXT $profileName $secondParam

    PromptMessageBeforeExitNoPause " Displying Help Completed! "
}

if($make.IsPresent){

    if(!$dev.IsPresent){
        ClearWorkspaces
    }

    $option = $profileName

    $profileName = GetActiveMOProfile

    MakeProfile $profileName $option

    PromptMessageBeforeExit " Make Profile Completed! "

}

if ($edit.IsPresent){

    if ($hash.IsPresent){
        if ($addon.IsPresent){
            CompileAddonHash $profileName $secondParam
        }else{
            CompileAddonsHashes $profileName
        }
    }
    PromptMessageBeforeExit " Edit Profile Completed! "

}

if ($purge.IsPresent){

    PurgeAddons
    PromptMessageBeforeExit " Purge Addons Completed! "
}


ShowHelpEXT "" ""

# if ($test.IsPresent){

#     $WebClient = New-Object System.Net.WebClient

#     $addonDefinition = [PSCustomObject]@{
#         addonName = "Expedition 2.3 Graphics Only Textures  (Part 2"
#         addonType = "mod"
#         addonUrl = "https://drive.google.com/file/d/1eHZFbD-rLxWaDZmqut9bfOPfbwA8PGvk/view?usp=sharing"
#         fileUrl = "https://www.dropbox.com/s/fmwvwceyk104tgj/Patch.7z?dl=1"
#         resourceFilename = "Patch.7z"
#         resourceWorkspace = "Aydin's Grass Tweaks 3.0"
#     }
#     $tmpFile = "./workspace/test_tmp.html"
#     $addonSavePath = "$pathToEXTAddons\$($addonDefinition.resourceFilename)"

#     $WebClient.DownloadFile($addonDefinition.fileUrl, $addonSavePath)
#     Write-Host $filesize
# }
function CreateSeparatorMetaIni {
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $modFolderPath
    )
    $metaini = "$modFolderPath/meta.ini"
    $pathToMetaTemplate = "$Global:pathToEXTTemplates/separator-meta.ini"

    $metainiTemplate = Get-Content -Path $pathToMetaTemplate -Raw

    
    $metainiTemplate = $metainiTemplate.Replace('%resourceWorkspace%',(Get-Item -Path $modFolderPath).BaseName)
    
    [ModMetaIni]::SaveNew($metaini, $metainiTemplate)
}

function CreateModMetaIni {
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $customMod,
        [Parameter(Mandatory = $true, Position = 1)]
        $addon
    )
    $modFolderPath = "$Global:pathToMOMods/$($customMod.modName)"

    $metaini = "$modFolderPath/meta.ini"
    $pathToMetaTemplate = "$Global:pathToEXTTemplates/mod-meta.ini"
    $metainiTemplate = Get-Content -Path $pathToMetaTemplate -Raw
    
    $filePath = GetAddonResourcePath $addon
    $filePath = [WildcardPattern]::Escape($filePath)
    $file = Get-Item -Path $filePath
    if ($file){
        $metainiTemplate = $metainiTemplate.Replace('%installationFile%', $file.FullName.Replace("\","/"))
    }
    $metainiTemplate = $metainiTemplate.Replace('%url%',$addon.addonUrl)
    $metainiTemplate = $metainiTemplate.Replace('%addonInfo%',$addon.info)
    $metainiTemplate = $metainiTemplate.Replace('%addonName%',$addon.addonName)
    $metainiTemplate = $metainiTemplate.Replace('%addonUrl%',$addon.addonUrl)
    $metainiTemplate = $metainiTemplate.Replace('%fileUrl%',$addon.fileUrl)
    $metainiTemplate = $metainiTemplate.Replace('%resourceFilename%',$addon.resourceFilename)
    $metainiTemplate = $metainiTemplate.Replace('%resourceWorkspace%',$addon.resourceWorkspace)
    $metainiTemplate = $metainiTemplate.Replace('%modType%',$customMod.modType) 
    $metainiTemplate = $metainiTemplate.Replace('%info%',$customMod.info)
    if (($customMod.modType -eq "fomod") -or ($customMod.modType -eq "xrdbmod")){
        $metainiTemplate = $metainiTemplate.Replace('%pathToGamedata%',($customMod.pathToGamedata | ConvertTo-Json -Compress)) 
    }else{
        $metainiTemplate = $metainiTemplate.Replace('%pathToGamedata%',$customMod.pathToGamedata) 
    }
    if ($customMod.excludePaths){
        $metainiTemplate = $metainiTemplate.Replace('%excludePaths%',$customMod.excludePaths)
    }else{
        $metainiTemplate = $metainiTemplate.Replace('%excludePaths%',"")
    }


    [ModMetaIni]::SaveNew($metaini, $metainiTemplate)    
}

function CreateModPatchMetaIni {
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $customMod,
        [Parameter(Mandatory = $true, Position = 1)]
        $modFolderPath
    )

    $metaini = "$modFolderPath/meta.ini"
    $pathToMetaTemplate = "$Global:pathToEXTTemplates/patch-meta.ini"
    $metainiTemplate = Get-Content -Path $pathToMetaTemplate -Raw

    $metainiTemplate = $metainiTemplate.Replace('%pathToGamedata%',$customMod.pathToGamedata)
    $metainiTemplate = $metainiTemplate.Replace('%info%',$customMod.info)
    if ($customMod.excludePaths){
        $metainiTemplate = $metainiTemplate.Replace('%excludePaths%',$customMod.excludePaths)
    }else{
        $metainiTemplate = $metainiTemplate.Replace('%excludePaths%',"")
    }
    [ModMetaIni]::SaveNew($metaini, $metainiTemplate)
}

function BuildModMetaIni{
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $modName,
        [Parameter(Mandatory = $true, Position = 1)]
        $profileModAction,      
        [Parameter(Mandatory = $true, Position = 2)]
        $forExport     
    )
   
    $pathToMetaIni = "$Global:pathToMOMods/$modName/meta.ini"
    
    $modMetaIni = [ModMetaIni]::new()
    $modMetaIni.Load($pathToMetaIni)

    Write-Host
    Write-Host "$modName" -BackgroundColor Red -ForegroundColor White
    Write-Host

    if ($modMetaIni.isNewMod -eq $False){

        if ($modMetaIni.properties.'modType' -eq "local"){
            return
        }

        if ($modMetaIni.properties.'modType' -eq "separator"){
            return
        }
        
    }else{

        if (!$forExport){
            # $metainiTemplate = Get-Content -Path "./ext/templates/meta.ini" -Raw
            # make the mod local automalically
            $metainiTemplate = Get-Content -Path "./ext/templates/default-meta.ini" -Raw       
            [ModMetaIni]::SaveNew($pathToMetaIni, $metainiTemplate)
            return
        }
        Write-Host "!! This mod appears to be new. Do you want to save this mod definitions as part of of the GAMMA-EXT custom profile. Some mods can be kept locally in your Mod Organizer and never shared in GAMMA-EXT." -ForegroundColor Yellow
        Write-Host
        $Title = ""
        $Prompt = "Type `"Yes`" to add information required for the GAMMA-EXT profile, `"No`" to make this mod local to this instance of Mod Organizer"
        $Choices = [System.Management.Automation.Host.ChoiceDescription[]] @("&Yes", "&No")
        $Default = 0
         
        # Prompt for the choice
        $Choice = $host.UI.PromptForChoice($Title, $Prompt, $Choices, $Default)
         
        # Action based on the choice
        switch($Choice)
        {
            0 { 
                ## continue
            }
            1 { 
                ## Mod is Local
                $metainiTemplate = Get-Content -Path "./ext/templates/local-meta.ini" -Raw
                $metainiTemplate = $metainiTemplate.Replace('%addonName%',$modName)
                $metainiTemplate = $metainiTemplate.Replace('%url%',$modMetaIni.'url')
                $metainiTemplate = $metainiTemplate.Replace('%installationFile%',$modMetaIni.properties.'installationFile')
                # if ($profileModAction -eq "enable"){
                # $profiles = @()
                # $currentProfile = [PSCustomObject]@{
                #     name = $profileName
                # }
                # $profiles += $currentProfile
                # $metainiTemplate = $metainiTemplate.Replace('%profiles%',($profiles | ConvertTo-Json -Compress))
                # }else{
                #     $metainiTemplate = $metainiTemplate.Replace('%profiles%',($profiles = @() | ConvertTo-Json -Compress))
                # }
                [ModMetaIni]::SaveNew($pathToMetaIni, $metainiTemplate)
                return
            }
        }
    }

    if($modName.EndsWith("_separator")){
        $modFolderPath = "$Global:pathToMOMods/$modName"
        CreateSeparatorMetaIni $modFolderPath
        return
    }
    $pathToMetaTemplate = "$Global:pathToEXTTemplates/mod-meta.ini"
    $metainiTemplate = Get-Content -Path $pathToMetaTemplate -Raw
    $metainiTemplate = $metainiTemplate.Replace('%addonName%',$modName)
    $metainiTemplate = $metainiTemplate.Replace('%resourceWorkspace%',$modName)
    Write-Host
    DisplayNoticeMessage "Please fill the required information about the mod addon" -ForegroundColor Red

    $installationFile = $modMetaIni.properties.'installationFile'
    if ($installationFile -eq ""){
        Write-Host
        DisplayNoticeMessage " - installation file "
        Write-Host
        DisplayNoticeText "Please enter the path to this addon installation file" $tabIndent
        DisplayNoticeText "Paths must be ABSOLUTE" $tabIndent
        DisplayNoticeText "for example C:/games/Stalker GAMMA/G.A.M.M.A. EXT-TEST/addons/Anomaly Expedition 2.2.1 Modpack.7z" $tabIndent
        Write-Host 
        DisplayNoticeMessage " !! You cannot skip this step !! "
        Write-Host 
        $installationFile = Read-Host ">> enter a valid path to the installation file"
        $continue = $true
        while($continue){
            if (Test-Path -LiteralPath $installationFile){
                $continue = $false
            }else{
                Write-Host
                DisplayWarningMessage " Path is not correct "
                Write-Host
                $installationFile = Read-Host ">> enter a valid path to the installation file"
            }
        }
    }
    $installationFile = $installationFile.Replace("\","/")
    $metainiTemplate = $metainiTemplate.Replace('%installationFile%',$installationFile)
    $resourceFilename = Split-Path $installationFile -Leaf
    $metainiTemplate = $metainiTemplate.Replace('%resourceFilename%',$resourceFilename)
    Write-Host     
    DisplayNoticeMessage " - addonUrl "
    Write-Host
    DisplayNoticeText "Please enter an url that documents the mod's original addon - For example the ModDb page from which this mod's addon was downloaded originally" $tabIndent
    DisplayNoticeText "!! You can skip this step but doing so you won't be able to export the profile in GAMMA EXT" $tabIndent
    Write-Host 
    $addonUrl = Read-Host ">> enter a value for addonUrl [Enter to skip]"
    $metainiTemplate = $metainiTemplate.Replace('%addonUrl%',$addonUrl)
    $metainiTemplate = $metainiTemplate.Replace('%url%',$addonUrl)
    Write-Host
    DisplayNoticeMessage " - fileUrl "
    Write-Host
    DisplayNoticeText "Please enter the url used to download the mod's original addon file ($resourceFilename)" $tabIndent
    DisplayNoticeText "For example an addon downloaded from ModDb will have these kind of links `"https://www.moddb.com/addons/start/223134`"" $tabIndent 
    DisplayNoticeText "if not have not downloaded from ModDb then specify the download url used to download the file originally" $tabIndent 
    DisplayNoticeText "!! You can skip this step but doing so you won't be able to export the profile in GAMMA EXT" $tabIndent 
    Write-Host 
    $fileUrl = Read-Host ">> enter a value for fileUrl [Enter to skip]"
    $metainiTemplate = $metainiTemplate.Replace('%fileUrl%',$fileUrl)
    Write-Host
    $selectModGamedata = [SelectModGamedata]::new()
    $gamedataModDefinitions = $selectModGamedata.Parse($modName, $installationFile)
    if($gamedataModDefinitions.modType -eq "fomod"){
        $metainiTemplate = $metainiTemplate.Replace('%pathToGamedata%',($gamedataModDefinitions.pathToGamedata | ConvertTo-Json -Compress -Depth 5))
    }else{
        $metainiTemplate = $metainiTemplate.Replace('%pathToGamedata%',$gamedataModDefinitions.pathToGamedata.path)
    }
    $metainiTemplate = $metainiTemplate.Replace('%modType%', $gamedataModDefinitions.modType) 
    $metainiTemplate = $metainiTemplate.Replace('%excludePaths%',"")
    Write-Host
    DisplayNoticeMessage " - info "
    Write-Host
    DisplayNoticeText "Please enter some info about the mod" $tabIndent
    Write-Host 
    $info = Read-Host ">> enter a value [Enter to skip]"
    $metainiTemplate = $metainiTemplate.Replace('%info%',$info)
    Write-Host

    [ModMetaIni]::SaveNew($pathToMetaIni, $metainiTemplate)
}

class ModMetaIni{

    $pathToEXTTemplates = "./ext/templates/"
    [string]$pathToMetaIni
    [string]$modMetaIni
    [pscustomobject]$properties
    [bool]$isNewMod

    [void] Load($pathToMetaIni){
        
        $this.pathToMetaIni = $pathToMetaIni

        $modMetaIniRaw = (Get-Content -LiteralPath $pathToMetaIni -Raw)
        if ($modMetaIniRaw.Contains("[GAMMA-EXT]")){
            $this.isNewMod = $False
        }else{
            $this.isNewMod = $True
        }
        $this.modMetaIni = $modMetaIniRaw

        $formattedIni = $modMetaIniRaw.Replace("[General]","").Replace("[installedFiles]","").Replace("[Plugins]","")

        if ($this.isNewMod -eq $False){
            $formattedIni = $formattedIni.Replace("[GAMMA-EXT]","")
        }

        $this.properties = ConvertFrom-StringData $formattedIni

    }  

    [void] Save(){
        
        if ($null -eq $this.pathToMetaIni){
            Write-Host "invalid call to ModMetaIni - not initialized" -ForegroundColor Yellow -BackgroundColor Red
        }

        $pathToMetaTemplate = $this.pathToEXTTemplates + "mod-meta.ini"
        $metainiTemplate = Get-Content -Path $pathToMetaTemplate -Raw

        # $metainiTemplate = $metainiTemplate.Replace('%profiles%', $this.properties.profiles)
        $metainiTemplate = $metainiTemplate.Replace('%installationFile%', $this.properties.installationFile)
        $metainiTemplate = $metainiTemplate.Replace('%url%',$this.properties.url)
        $metainiTemplate = $metainiTemplate.Replace('%addonInfo%',$this.properties.addonInfo)
        $metainiTemplate = $metainiTemplate.Replace('%addonName%',$this.properties.addonName)
        $metainiTemplate = $metainiTemplate.Replace('%addonUrl%',$this.properties.addonUrl)
        $metainiTemplate = $metainiTemplate.Replace('%fileUrl%',$this.properties.fileUrl)
        $metainiTemplate = $metainiTemplate.Replace('%resourceFilename%',$this.properties.resourceFilename)
        $metainiTemplate = $metainiTemplate.Replace('%resourceWorkspace%',$this.properties.resourceWorkspace)
        $metainiTemplate = $metainiTemplate.Replace('%modType%',$this.properties.modType) 
        $metainiTemplate = $metainiTemplate.Replace('%info%',$this.properties.info)
        $metainiTemplate = $metainiTemplate.Replace('%pathToGamedata%',$this.properties.pathToGamedata)
        $metainiTemplate = $metainiTemplate.Replace('%excludePaths%',$this.properties.excludePaths)
        $this.modMetaIni = $metainiTemplate
        
        [ModMetaIni]::SaveNew($this.pathToMetaIni, $metainiTemplate)

        $this.Load($this.pathToMetaIni)

    } 

    [void] SaveLocal(){
        
        if ($null -eq $this.pathToMetaIni){
            Write-Host "invalid call to ModMetaIni - not initialized" -ForegroundColor Yellow -BackgroundColor Red
        }

        $metainiTemplate = Get-Content -Path "./ext/templates/local-meta.ini" -Raw
        $metainiTemplate = $metainiTemplate.Replace('%addonName%',$this.properties.addonInfo)
        $metainiTemplate = $metainiTemplate.Replace('%url%',$this.properties.url)
        $metainiTemplate = $metainiTemplate.Replace('%installationFile%',$this.properties.installationFile)
        $metainiTemplate = $metainiTemplate.Replace('%profiles%',$this.properties.profiles)
        $this.modMetaIni = $metainiTemplate
        
        [ModMetaIni]::SaveNew($this.pathToMetaIni, $metainiTemplate)

        $this.Load($this.pathToMetaIni)

    }

    [void] static SaveNew($pathToMetaIni, $metaini){
        Set-Content -LiteralPath $pathToMetaIni -Value $metaini
    }


    [void]EditProperty($propertyName){

        # $Global:tabIndent = "    "

        if ($null -eq $this.pathToMetaIni){
            Write-Host "invalid call to ModMetaIni - not initialized" -ForegroundColor Yellow -BackgroundColor Red
        }

        if ($propertyName -eq "addonUrl"){
            Write-Host
            $modName = $this.properties.modName
            DisplayModName "$modName"
    
            Write-Host
            DisplayNoticeMessage " Please fill the required information about the mod addon "
            Write-Host
            DisplayNoticeMessage " - addonUrl "
            Write-Host
            DisplayNoticeText "Please enter an url that documents the mod's original addon - For example the ModDb page from which this mod's addon was downloaded originally" $Global:tabIndent
            DisplayNoticeText "!! You can skip this step but doing so you won't be able to export the profile in GAMMA EXT" $Global:tabIndent
            Write-Host 
            $this.properties.addonUrl = Read-Host ">> enter a value for addonUrl [Enter to skip]"
        }
    
        if ($propertyName -eq "fileUrl"){
            $resourceFilename = $this.properties.resourceFilename
            Write-Host
            DisplayNoticeMessage " - fileUrl "
            Write-Host
            DisplayNoticeText "Please enter the url used to download the mod's original addon file ($resourceFilename)" $Global:tabIndent
            DisplayNoticeText "For example an addon downloaded from ModDb will have these kind of links `"https://www.moddb.com/addons/start/223134`"" $Global:tabIndent
            DisplayNoticeText "if not have not downloaded from ModDb then specify the download url used to download the file originally" $Global:tabIndent
            DisplayNoticeText "!! You can skip this step but doing so you won't be able to export the profile in GAMMA EXT" $Global:tabIndent
            Write-Host 
            $this.properties.fileUrl = Read-Host ">> enter a value for fileUrl [Enter to skip]"
        } 

        if ($propertyName -eq "info"){
            Write-Host
            DisplayNoticeMessage " - info "
            Write-Host
            DisplayNoticeText "    Please enter some info about the mod" $Global:tabIndent
            Write-Host 
            $this.properties.info = Read-Host ">> enter a value [Enter to skip]"
        }
    }
}
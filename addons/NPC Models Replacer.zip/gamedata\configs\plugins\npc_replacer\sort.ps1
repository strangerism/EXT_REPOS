# Define the path to the input file
$inputFilePath = 'npc_replacer_exp_hdmodels.ltx'

# Define the path to the output file
$outputFilePath = 'sorted_npc_replacer_exp_hdmodels.ltx'

# Read the content of the input file
$content = Get-Content -Path $inputFilePath

# Initialize an array to store the pairs
$pairs = @()

# Extract the name = value pairs
foreach ($line in $content) {
    if ($line -match ';===============') {
        # Skip the comment lines
    }elseif ($line -match '^\s*([^=]+)\s*=\s*(.+)$') {
        $pairs += @{
            Name = $matches[1].Trim()
            Value = $matches[2].Trim()
        }
    }
}

# print all names
# foreach ($pair in $pairs) {
#     Write-Host $pair.Name
# }

# Sort the pairs by name
$sortedPairs = $pairs | Sort-Object -Property Name -Descending

# Initialize an array to store the sorted lines
$sortedLines = @()

# Prepare the sorted lines
foreach ($pair in $sortedPairs) {
    $sortedLines += "$($pair.Name) = $($pair.Value)"
}

# Write the sorted lines to the output file
$sortedLines | Out-File -FilePath $outputFilePath -Encoding utf8

Write-Host "Sorted content has been written to $outputFilePath"
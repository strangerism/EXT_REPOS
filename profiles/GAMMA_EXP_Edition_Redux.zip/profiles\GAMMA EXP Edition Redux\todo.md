on next gamma update

- remove headgear anim
- remove paw
- replace ui_actor_menu.dds

**__Before launching the game after the update/install__**

```diff
-- PAY ATTENTION HERE
```
Follow this step (**New Demonized Exes**) before you continue

https://imgur.com/a/6rbeMdg

> https://discord.com/channels/912320241713958912/1080180246038446080/1289613752714662010



https://keyboard-layout-editor.com/##@@=Esc&_x:1&c=%235dcde3%3B&=Quick%20Slot%201&=Quick%20Slot%202&_c=%23bfbad1%3B&=Quick%20Slot%203&=Quick%20Slot%204&_x:0.5&c=%23cccccc%3B&=Quick%0A%0A%0A%0A%0A%0ASave&=F6&=F7&=F8&_x:0.5%3B&=F9&=F10&=F11&_c=%23a09888%3B&=Take%0A%0A%0A%0A%0A%0APic&_x:0.25&c=%23cccccc%3B&=PrtSc&=Scroll%20Lock&=Pause%0ABreak%3B&@_y:0.5%3B&=%C2%AC%0A%60&_c=%23ffe08d%3B&=Melee%0APistol&=Primary&=Second%0A%0A%0A%0A%0A%0Aary&=Alt&_c=%23e5dbca%3B&=Bolt&_c=%23cccccc%3B&=%5E%0A6&=%2F&%0A7&=*%0A8&=(%0A9&=)%0A0&=%2F_%0A-&=+%0A%2F=&_w:2%3B&=Backspace&_x:0.25%3B&=Insert&_c=%23b4b2ab%3B&=Reshade%0A%0A%0A%0A%0A%0AMenu&_c=%2334a4b9%3B&=NV%20Up&_x:0.25&c=%23cccccc%3B&=Num%20Lock&=%2F%2F&=*&=-%3B&@_c=%23857eb1&w:1.5%3B&=Bag&_c=%23cccccc%3B&=Q&_c=%23c8c4b6%3B&=W&_c=%23cccccc%3B&=E&_c=%239b6482&t=%23cde30b%3B&=Reload&_c=%23d5d54b&t=%23000000%3B&=Clear%20Visor&_c=%237adabd%3B&=Ammo%0A%0A%0A%0A%0A%0AWheel&_c=%23cccccc%3B&=U&_c=%23b4b2ab%3B&=Task%20Board&_c=%23cccccc%3B&=O&_c=%23828687%3B&=Toggle%0A%0A%0A%0A%0A%0APatch&_c=%23cccccc%3B&=%7B%0A%5B&=%7D%0A%5D&_x:0.25&w:1.25&h:2&w2:1.5&h2:1&x2:-0.25%3B&=Enter&_x:0.25%3B&=Delete&=End&_c=%2334a4b9%3B&=NV%20Down&_x:0.25&c=%23cccccc%3B&=7%0AHome&=8%0A%E2%86%91&=9%0APgUp&_h:2%3B&=+%3B&@_c=%237adabd&w:1.75%3B&=Device%0A%0A%0A%0AQAW&_c=%23c8c4b6%3B&=A&=S&=D&_c=%23ffb07b%3B&=Use%2F%2F%0AAmmo%20Check&_c=%239b6482&t=%23d3d622%3B&=Grena%0A%0A%0A%0A%0A%0Ade&_c=%23e26757&t=%23000000%3B&=BHS&_c=%23b4b2ab%3B&=RPG%0A%0A%0A%0A%0A%0AMenu&_c=%23cccccc%3B&=K&_c=%2334a4b9%3B&=Torch%0A%0A%0A%0ALASER&_c=%23cccccc%3B&=%2F:%0A%2F%3B&=%2F@%0A'&=~%0A%23&_x:4.75%3B&=4%0A%E2%86%90&=5&=6%0A%E2%86%92%3B&@_w:1.25%3B&=Walk&_c=%23828687%3B&=Toggle%20scope&_c=%23ffb07b%3B&=Unjam%0AInspect&_c=%23cccccc%3B&=Run&_c=%237adabd%3B&=Squad&_c=%23cccccc%3B&=V&_c=%23d5d54b%3B&=Lower%20Weapon&_c=%2334a4b9%3B&=Night%0A%0A%0A%0A%0A%0AVision&_c=%23b4b2ab%3B&=PDA%20Map&_c=%23cccccc%3B&=%3C%0A,&=%3E%0A.&_c=%23828687%3B&=Toggle%20Map&_c=%23cccccc&w:2.75%3B&=Shift&_x:1.25%3B&=%E2%86%91&_x:1.25%3B&=1%0AEnd&=2%0A%E2%86%93&=3%0APgDn&_h:2%3B&=Enter%3B&@_w:1.25%3B&=Crouch&_w:1.25%3B&=Win&_w:1.25%3B&=Alt&_a:7&w:6.25%3B&=&_a:4&w:1.25%3B&=AltGr&_w:1.25%3B&=Win&_w:1.25%3B&=Menu&_w:1.25%3B&=Ctrl&_x:0.25%3B&=%E2%86%90&=%E2%86%93&=%E2%86%92&_x:0.25&w:2%3B&=0%0AIns&=.%0ADel
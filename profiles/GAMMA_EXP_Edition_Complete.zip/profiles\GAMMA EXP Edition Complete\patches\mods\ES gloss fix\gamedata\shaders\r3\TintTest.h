//Reverse tonemapping on sky and cubemaps to preserve original look
//Experiemental color grading for cubemaps

#define SkyType 2 //0=original //1=boost before blend //2=boost after blend

float3 InvTonemap(float3 x)
{
	float SkyBoost = 0.9;
	float SkyBoostSat = 1.0;
	
	x = x / max(0.001, 1 - vibrance(x * SkyBoost, SkyBoostSat));

	x = pow(x, 0.7) * 0.18/pow(0.18,0.7); //inverse ACES curve
	
	return x;
}

float3 SkyBlendTint(float3 Sky0, float3 Sky1, float Blend, float3 Tint)
{
	
	float TintScale = 1.0;
	float TintOffset = 0.0;
	float TintPow = 1.0;
	float TintSat = 1.0;
	
	float SkyScale = 1.0;
	float SkyOffset = 0.0;
	float SkyPow = 1.0;
	float SkySat = 1.0;

	float3 SkyPre;
	float3 SkyPost;
	float3 SkyTint;
	
#if SkyType == 1
	Sky0 = SRGBToLinear(Sky0);
	Sky0 = InvTonemap(Sky0);
	Sky1 = SRGBToLinear(Sky1);
	Sky1 = InvTonemap(Sky1);
#endif
	
	//blend skies
	float3 Sky = lerp(Sky0, Sky1, Blend);
	
	//sky tinting and grading
	SkyPre = Sky;
	
#if SkyType == 2
	SkyPre = SRGBToLinear(SkyPre);
	SkyPre = InvTonemap(SkyPre);
#endif
	
	//apply grading
	SkyPost = vibrance(pow((SkyPre * SkyScale) + SkyOffset, SkyPow), SkySat); 
	
	//apply tint
	SkyTint = vibrance(pow((Tint * TintScale) + TintOffset, TintPow), TintSat);
	SkyPost = SkyPost * SkyTint;
	
	//reverse grading
	//SkyPost = (pow(vibrance(SkyPost, 1/SkySat), 1/SkyPow) - SkyOffset) / SkyScale;
	
#if SkyType > 0
	SkyPost = LinearTosRGB(SkyPost); 
#endif

	return SkyPost;
}
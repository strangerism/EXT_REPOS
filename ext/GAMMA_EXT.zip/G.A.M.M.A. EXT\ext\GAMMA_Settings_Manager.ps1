function SaveSettings {

    $profileName = GetActiveMOProfile

    DisplayHeadingMessage " Saving Profile $profileName Settings "

    SaveReshadeSettings $profileName

    SaveUserSettings $profileName

    SaveMCMSettings $profileName

    Write-Host
    DisplayHeadingMessage " Profile Settings $profileName Saved! "
}

function SaveReshadeSettings {
    param (
        $profileName
    )

    $targetPath = [WildcardPattern]::Escape("$Global:pathToEXTSettings/$profileName/bin")

    DisplayProcessStep " Saving Reshade " $tabIndent
    Get-ChildItem -Path "$Global:pathToAnomalyBin/*" -Include *.ini -Exclude alsoft.ini -Recurse | ForEach-Object {

        $dest = $_.FullName.Replace((Get-Item $Global:pathToAnomalyBin).FullName, (Get-Item $targetPath).FullName)
        Copy-Item -Path $_.FullName -Destination $dest -Force -Recurse -Verbose 4>$Global:pathToEXTWorkspace\verbose.txt 
        DisplayVerbose "" $tabIndent
    }
}

function SaveMCMSettingsSimple {
    param (
        $profileName
    )
    
    DisplayProcessStep " Saving MCM settings " $tabIndent

    $mcmSettings = "$Global:GAMMAOverwrite/gamedata/configs/axr_options.ltx"
    $mcmSavedSettingsFile = "$Global:pathToEXTSettings/$profileName/appdata/mcm_saved_settings.ltx"

    Copy-Item -LiteralPath $mcmSettings -Destination $mcmSavedSettingsFile -Force -Verbose 4>$Global:pathToEXTWorkspace\verbose.txt 
    DisplayVerbose "" $tabIndent
}

function SaveMCMSettings {
    param (
        $profileName
    )
    
    DisplayProcessStep " Saving MCM settings " $tabIndent


    $mcmMasterSettingsFile = "$Global:GAMMAMods\G.A.M.M.A. MCM values - Rename to keep your personal changes\gamedata\configs\axr_options.ltx"
    $mcmSettingsFile = "$Global:GAMMAOverwrite/gamedata/configs/axr_options.ltx"
    $mcmSavedSettingsFile = "$Global:pathToEXTSettings/$profileName/appdata/mcm_saved_settings.ltx"

    [string[]]$mcmMasterSettings = Get-Content -Path $mcmMasterSettingsFile
    [string[]]$mcmSettings = Get-Content -Path $mcmSettingsFile

    $mcmSavedSettings = @()

    if (Test-Path -LiteralPath $mcmSettingsFile){

        $mcmMasterSettingsTable = createMCMHashTable $mcmMasterSettings

        for ($i = 0; $i -lt $mcmSettings.Length; $i++) {

            if ($mcmSettings[$i].Trim().Length -eq 0){
                $mcmSavedSettings += $mcmSettings[$i]
                continue
            }

            if ($mcmSettings[$i].StartsWith("[")){
                $prefix = $mcmSettings[$i].Substring($mcmSettings[$i].IndexOf("[") + 1, $mcmSettings[$i].IndexOf("]") - 1)
                $mcmSavedSettings += $mcmSettings[$i]
                continue
            }

            $mcmKey = $($mcmSettings[$i]).Substring(0, $($mcmSettings[$i]).IndexOf("="))
            $mcmSavedKey = $prefix + ":" + $mcmKey
            $mcmSavedValue = $($mcmSettings[$i]).Substring($($mcmSettings[$i]).IndexOf("=") + 1)
            
            if (!$mcmMasterSettingsTable.Contains($mcmSavedKey)){
                # the current mcm setting does not exists in the master file, it's a new setting from a custom mod
                $newMCMSetting = $mcmKey + "=" + $mcmSavedValue
                Write-Host "Saving new setting $newMCMSetting"
                $mcmSavedSettings += $newMCMSetting
            }else{
                # the current mcm setting exists in the master file, it's value is an override of a master mcm setting
                $mcmDefaultValue = $mcmMasterSettingsTable.$mcmSavedKey
                if ($mcmSavedValue -ne $mcmDefaultValue){
                    # the value of the setting is different from the default value
                    $newMCMSetting = $mcmKey + "=" + $mcmSavedValue
                    Write-Host "Updating setting $($mcmSettings[$i])"
                    $mcmSavedSettings += $newMCMSetting
                }else{
                    # the current mcm setting is a default from the master mcm setting
                    # we do not save it
                    continue
                }
            }
        }

        Set-Content -LiteralPath $mcmSavedSettingsFile -Value $mcmSavedSettings -Force -Verbose   
    }
}
function createMCMHashTable{
    param (
        $mcmSettings
    )
    $table = @{}
    foreach($setting in $mcmSettings){

        if ($setting.Trim().Length -eq 0){
            continue
        }

        if ($setting.StartsWith("[")){
            # tag the key context
            $prefix = $setting.Substring($setting.IndexOf("[") + 1, $setting.IndexOf("]") - 1)
        }else{
            $mcmKey = $prefix + ":" + $setting.Substring(0, $setting.IndexOf("="))
            $mcmValue = $setting.Substring($setting.IndexOf("=") + 1)
            $table.Add($mcmKey, $mcmValue)
        }
    }
    return $table
}
function ApplyMCMSettingsSimple {
    param (
        $profileName
    )

    $mcmSettings = "$Global:GAMMAOverwrite/gamedata/configs/axr_options.ltx"
    $mcmSavedSettingsFile = "$Global:pathToEXTSettings/$profileName/appdata/mcm_saved_settings.ltx"

    Copy-Item -LiteralPath $mcmSavedSettingsFile -Destination $mcmSettings -Force -Verbose 4>$Global:pathToEXTWorkspace\verbose.txt 
    DisplayVerbose "" $tabIndent
}

# function ApplyMCMSettings{
#     param (
#         $profileName
#     )

# # Define paths
# $masterPath   = "$Global:GAMMAMods\G.A.M.M.A. MCM values - Rename to keep your personal changes\gamedata\configs\axr_options.ltx"
# $defaultPath  = "$Global:pathToEXTSettings/$profileName/appdata/mcm_default_settings.ltx"
# $savedPath    = "$Global:pathToEXTSettings/$profileName/appdata/mcm_saved_settings.ltx"
# $mergedPath   = "$Global:GAMMAOverwrite/gamedata/configs/axr_options_merged.ltx"

# # Load content
# $masterContent  = Get-Content $masterPath
# $defaultContent = Get-Content -LiteralPath $defaultPath
# $savedContent   = Get-Content -LiteralPath $savedPath

# # Parse function
# function Parse-Ini {
#     param($lines)
#     $data = @{}
#     $section = "_global"

#     foreach ($line in $lines) {
#         $line = $line.Trim()
#         if ($line -match "^\[(.+?)\]") {
#             $section = $matches[1]
#         } elseif ($line -match "^\s*([^#;].+?)\s*=\s*(.*)") {
#             $key = $matches[1]
#             $val = $matches[2]
#             if (-not $data.ContainsKey($section)) {
#                 $data[$section] = @{}
#             }
#             $data[$section][$key] = $val
#         }
#     }
#     return $data
# }

# # Parse files
# $defaultParsed = Parse-Ini $defaultContent
# $savedParsed   = Parse-Ini $savedContent

# # Build override tree: apply default first, then saved
# $overrides = @{}
# foreach ($section in $defaultParsed.Keys) {
#     $overrides[$section] = @{}
#     foreach ($key in $defaultParsed[$section].Keys) {
#         $overrides[$section][$key] = $defaultParsed[$section][$key]
#     }
# }

# foreach ($section in $savedParsed.Keys) {
#     if (-not $overrides.ContainsKey($section)) {
#         $overrides[$section] = @{}
#     }
#     foreach ($key in $savedParsed[$section].Keys) {
#         $overrides[$section][$key] = $savedParsed[$section][$key]
#     }
# }

# # Track what's in master
# $seenKeys = @{}
# $sectionsInMaster = @()
# $currentSection = "_global"

# foreach ($line in $masterContent) {
#     if ($line -match "^\[(.+?)\]") {
#         $currentSection = $matches[1]
#         $sectionsInMaster += $currentSection
#     } elseif ($line -match "^\s*([^#;].+?)\s*=\s*(.*)") {
#         $key = $matches[1]
#         $val = $matches[2]
#         if (-not $seenKeys.ContainsKey($currentSection)) {
#             $seenKeys[$currentSection] = @{}
#         }
#         $seenKeys[$currentSection][$key] = $val
#     }
# }

# # Prepare output
# $finalLines = @()
# $currentSection = "_global"

# Write-Host " Applying overrides from default and saved settings..."

# foreach ($line in $masterContent) {
#     if ($line -match "^\[(.+?)\]") {
#         $currentSection = $matches[1]
#         $finalLines += $line
#         continue
#     }

#     if ($line -match "^\s*([^#;].+?)\s*=\s*(.*)") {
#         $key = $matches[1]
#         $originalValue = $matches[2]

#         if ($overrides.ContainsKey($currentSection) -and $overrides[$currentSection].ContainsKey($key)) {
#             $newValue = $overrides[$currentSection][$key]
#             $finalLines += "$key = $newValue"
#             $seenKeys[$currentSection].Remove($key)
#             Write-Host " Overridden [$currentSection] $key = $newValue"
#         } else {
#             $finalLines += $line
#         }
#     } else {
#         $finalLines += $line
#     }
# }

# # Add missing entries
# Write-Host " Adding new keys and sections..."

# foreach ($section in $overrides.Keys) {
#     $isGlobal = ($section -eq "_global")
#     $existingKeys = @()
#     if ($seenKeys.ContainsKey($section)) {
#         $existingKeys = $seenKeys[$section].Keys
#     }

#     $newLines = @()
#     foreach ($key in $overrides[$section].Keys) {
#         if (-not $existingKeys -contains $key) {
#             $value = $overrides[$section][$key]
#             $newLines += "$key = $value"
#             Write-Host " New [$section] $key = $value"
#         }
#     }

#     if ($newLines.Count -gt 0) {
#         $finalLines += ""  # Add blank line before new section

#         # Ensure we add a section header for truly new sections
#         if (-not $isGlobal) {
#             $finalLines += "[$section]"
#             Write-Host "Confirmed: Added section header [$section]"
#         }

#         foreach ($entry in $newLines) {
#             $finalLines += $entry
#             Write-Host "   Appended: $entry"
#         }
#     }
# }
# New-item "$Global:GAMMAOverwrite/gamedata/configs" -ItemType Directory -Force | Out-Null
# # Save output
# $finalLines | Set-Content $mergedPath
# Write-Host " Merge complete! Output written to $mergedPath"

# }

function ApplyMCMSettings {
    param (
        $profileName,
        $mcmSettingsType,
        $sourceIsFromOverride
    )

    DisplayProcessStep " Generating MCM settings, axr_options.ltx, using saved MCM settings [$mcmSettingsType]"

    if ($sourceIsFromOverride) {
        DisplayProcessStep "override source"
        $mcmSettingsFile = "$Global:GAMMAOverwrite/gamedata/configs/axr_options.ltx"
    }else{
        DisplayProcessStep "mcm mod source"
        $mcmSettingsFile = "$Global:GAMMAMods\G.A.M.M.A. MCM values - Rename to keep your personal changes\gamedata\configs\axr_options.ltx"
    }

    $mcmSavedSettingsFile = "$Global:pathToEXTSettings/$profileName/appdata/$mcmSettingsType.ltx"

    $overrideMcmSettingsFolder = "$Global:GAMMAOverwrite/gamedata/configs"
    New-item $overrideMcmSettingsFolder -ItemType Directory -Force | Out-Null
    
    if (Test-Path -LiteralPath $mcmSavedSettingsFile){

        [string[]]$mcmSettings = Get-Content -Path $mcmSettingsFile
        [string[]]$mcmSavedSettings = Get-Content -LiteralPath $mcmSavedSettingsFile

        $mcmSavedSettingsTable = createMCMHashTable $mcmSavedSettings

        $overrideMcmSettings = @()
        
        for ($i = 0; $i -lt $mcmSettings.Length; $i++) {

            if ($mcmSettings[$i].Trim().Length -eq 0){
                $overrideMcmSettings += $mcmSettings[$i]
                continue
            }

            if ($mcmSettings[$i].StartsWith("[")){
                $prefix = $mcmSettings[$i].Substring($mcmSettings[$i].IndexOf("[") + 1, $mcmSettings[$i].IndexOf("]") - 1)
                $overrideMcmSettings += $mcmSettings[$i]
                continue
            }

            $mcmKey = $($mcmSettings[$i]).Substring(0, $($mcmSettings[$i]).IndexOf("="))
            $mcmSavedKey = $prefix + ":" + $mcmKey
            if ($mcmSavedSettingsTable.Contains($mcmSavedKey)){
                $newMCMSetting = $mcmKey + "=" + $mcmSavedSettingsTable.$mcmSavedKey
                Write-Host "Overriding MCM default setting $($mcmSettings[$i]) --> $($mcmSavedSettingsTable.$mcmSavedKey)"
                $overrideMcmSettings += $newMCMSetting
            }else{
                $overrideMcmSettings += $mcmSettings[$i]
            }
        }

        Set-Content -LiteralPath "$overrideMcmSettingsFolder/axr_options.ltx" -Value $overrideMcmSettings -Force -Verbose

        [string[]]$overrideMcmSettings = Get-Content -Path "$overrideMcmSettingsFolder/axr_options.ltx"

        $overrideMcmSettingsTable = createMCMHashTable $overrideMcmSettings

        $overrideMcmList = ReadMCMSettingsFile "$overrideMcmSettingsFolder/axr_options.ltx"

        for ($i = 0; $i -lt $mcmSavedSettings.Length; $i++) {
            
            if ($mcmSavedSettings[$i].Trim().Length -eq 0){
                continue
            }

            if ($mcmSavedSettings[$i].StartsWith("[")){
                # store the prefix
                $prefix = $mcmSavedSettings[$i].Substring($mcmSavedSettings[$i].IndexOf("[") + 1, $mcmSavedSettings[$i].IndexOf("]") - 1)
                # store this position as beforeKey
                $beforeKey = $mcmSavedSettings[$i]
                continue
            }

            $mcmKey = $($mcmSavedSettings[$i]).Substring(0, $($mcmSavedSettings[$i]).IndexOf("="))
            $mcmSavedKey = $prefix + ":" + $mcmKey

            if ($overrideMcmSettingsTable.Contains($mcmSavedKey) -eq ""){
                # the saved settings is new
                Write-Host "Adding new MCM setting $($mcmSavedSettings[$i])"
                # find where to instert it
                $beforeNode = $overrideMcmList.Find($beforeKey, $null)
                # instert setting here
                $newSettingNode = @{ name = $mcmSavedKey; setting = $mcmSavedSettings[$i] }
                $null = $overrideMcmList.Insert($newSettingNode, $beforeNode)
                # store this position as beforeKey
                $beforeKey = $prefix + ":" + $mcmSavedSettings[$i].Substring(0, $mcmSavedSettings[$i].IndexOf("="))
            }else{
                # store this position as beforeKey
                # $beforeKey = $prefix + ":" + $mcmSavedSettings[$i].Substring(0, $mcmSavedSettings[$i].IndexOf("="))
            }
        }

        $overrideMcmList = $overrideMcmList.ToArray({
            param($currentNode)
        
            $line = $currentNode.setting
        
            return $line
        })

        Set-Content -LiteralPath "$overrideMcmSettingsFolder/axr_options.ltx" -Value $overrideMcmList -Force -Verbose
    }else{
        DisplayWarningMessage " Could not find saved MCM settings file: $mcmSavedSettingsFile "
        Set-Content -LiteralPath "$overrideMcmSettingsFolder/axr_options.ltx" -Value $() -Force -Verbose
    }
    
}
function ReadMCMSettingsFile {
    param (
        $mcmSettingsFile
    )

    $mcmSettings = Get-Content -LiteralPath $mcmSettingsFile

    $linkedList = New-Object LinkedList(,{
        param($currentNode, $mcmSavedKey)
    
        if ($currentNode.name -eq $mcmSavedKey){
            return 0
        }else{
            return -1
        }
    
        return 1
    })

    foreach($line in $mcmSettings){
        
        if ($line.Trim().Length -eq 0){
            # $null = $linkedList.append( @{ key = $mcmSavedKey; setting = $line })
            continue
        }

        if ($line.StartsWith("[")){
            $prefix = $line.Substring($line.IndexOf("[") + 1, $line.IndexOf("]") - 1)
            $null = $linkedList.append( @{ name = $line; setting = $line })
            continue
        }

        $mcmKey = $line.Substring(0, $line.IndexOf("="))
        $mcmSavedKey = $prefix + ":" + $mcmKey
    
        $null = $linkedList.append( @{ name = $mcmSavedKey; setting = $line })
    }

    return $linkedList
}
function SaveUserSettings {
    param (
        $profileName
    )

    DisplayProcessStep " Saving game settings " $tabIndent

    $userSettingsFile = "$Global:pathToAnomalyAppdata/user.ltx"

    [string[]]$userSettings = Get-Content -Path $userSettingsFile
    
    $userOptions = @()
    
    for ($i = 0; $i -lt $userSettings.Length; $i++) {
    
        if ($userSettings[$i] -like "g_*"){
            $userOptions += $userSettings[$i]
        }
        if ($userSettings[$i] -like "bind *"){
            $userOptions += $userSettings[$i]
        }
        if ($userSettings[$i] -like "hud_*"){
            $userOptions += $userSettings[$i]
        }
        if ($userSettings[$i] -like "vid_mode*"){
            $userOptions += $userSettings[$i]
        }
        if ($userSettings[$i] -like "fov*"){
            $userOptions += $userSettings[$i]
        }
        if ($userSettings[$i] -like "rs_screenmode*"){
            $userOptions += $userSettings[$i]
        }
        if ($userSettings[$i] -like "ai_use_torch_dynamic_lights"){
            $userOptions += $userSettings[$i]
        }
        if ($userSettings[$i] -like "discord_status"){
            $userOptions += $userSettings[$i]
        }
        if ($userSettings[$i] -like "g_3d_pda"){
            $userOptions += $userSettings[$i]
        }
        if ($userSettings[$i] -like "mouse_*"){
            $userOptions += $userSettings[$i]
        }
        if ($userSettings[$i] -like "head_bob_factor"){
            $userOptions += $userSettings[$i]
        }
        if ($userSettings[$i] -like "r2_detail_bump"){
            $userOptions += $userSettings[$i]
        }
        if ($userSettings[$i] -like "r2_dof_enable"){
            $userOptions += $userSettings[$i]
        }
        if ($userSettings[$i] -like "r2_gloss_factor"){
            $userOptions += $userSettings[$i]
        }
        if ($userSettings[$i] -like "r2_ls_squality"){
            $userOptions += $userSettings[$i]
        }
        if ($userSettings[$i] -like "r2_mblur*"){
            $userOptions += $userSettings[$i]
        }
        if ($userSettings[$i] -like "r2_slight_fade"){
            $userOptions += $userSettings[$i]
        }
        if ($userSettings[$i] -like "r2_smaa"){
            $userOptions += $userSettings[$i]
        }
        if ($userSettings[$i] -like "r2_soft_particles"){
            $userOptions += $userSettings[$i]
        }
        if ($userSettings[$i] -like "r2_soft_water"){
            $userOptions += $userSettings[$i]
        }
        if ($userSettings[$i] -like "r2_ssao*"){
            $userOptions += $userSettings[$i]
        }
        if ($userSettings[$i] -like "r2_steep_parallax"){
            $userOptions += $userSettings[$i]
        }
        if ($userSettings[$i] -like "r2_sun"){
            $userOptions += $userSettings[$i]
        }
        if ($userSettings[$i] -like "r2_sun_quality"){
            $userOptions += $userSettings[$i]
        }
        if ($userSettings[$i] -like "r2_sunshafts_*"){
            $userOptions += $userSettings[$i]
        }
        if ($userSettings[$i] -like "r2_volumetric_lights"){
            $userOptions += $userSettings[$i]
        }
        if ($userSettings[$i] -like "r3_dynamic_wet_surfaces*"){
            $userOptions += $userSettings[$i]
        }
        if ($userSettings[$i] -like "r3_msaa"){
            $userOptions += $userSettings[$i]
        }
        if ($userSettings[$i] -like "r3_volumetric_smoke"){
            $userOptions += $userSettings[$i]
        }
        if ($userSettings[$i] -like "r__actor_shadow"){
            $userOptions += $userSettings[$i]
        }
        if ($userSettings[$i] -like "r4_enable_tessellation"){
            $userOptions += $userSettings[$i]
        }
        if ($userSettings[$i] -like "r__detail_*"){
            $userOptions += $userSettings[$i]
        }
        if ($userSettings[$i] -like "r__enable_grass_shadow"){
            $userOptions += $userSettings[$i]
        }
        if ($userSettings[$i] -like "r__framelimit"){
            $userOptions += $userSettings[$i]
        }
        if ($userSettings[$i] -like "r__geometry_lod"){
            $userOptions += $userSettings[$i]
        }
        if ($userSettings[$i] -like "r__optimize_*"){
            $userOptions += $userSettings[$i]
        }
        if ($userSettings[$i] -like "r__tf_aniso"){
            $userOptions += $userSettings[$i]
        }
        if ($userSettings[$i] -like "r__tf_mipbias"){
            $userOptions += $userSettings[$i]
        }
        if ($userSettings[$i] -like "rs_v_sync"){
            $userOptions += $userSettings[$i]
        }
        if ($userSettings[$i] -like "rs_vis_distance"){
            $userOptions += $userSettings[$i]
        }
        if ($userSettings[$i] -like "snd_efx"){
            $userOptions += $userSettings[$i]
        }
        if ($userSettings[$i] -like "snd_volume_eff"){
            $userOptions += $userSettings[$i]
        }
        if ($userSettings[$i] -like "snd_volume_music"){
            $userOptions += $userSettings[$i]
        }
        if ($userSettings[$i] -like "texture_lod"){
            $userOptions += $userSettings[$i]
        }
        if ($userSettings[$i] -like "wpn_aim_toggle"){
            $userOptions += $userSettings[$i]
        }
        if ($userSettings[$i] -like "foo"){
            $userOptions += $userSettings[$i]
        }                  
    }
    
    $userOptionsFile = "$Global:pathToEXTSettings/$profileName/appdata/saved_settings.ltx"
    
    Set-Content -LiteralPath $userOptionsFile -Value $userOptions -Force -Verbose   
    
    # Create manual_edits_settings in GAMMA settings if not there
    if ($profileName -eq "G.A.M.M.A"){
        
        $manualEditsSettingsFile = "./settings/G.A.M.M.A/appdata/manual_edits_settings.ltx"
        if (!(Test-Path -LiteralPath $manualEditsSettingsFile)){
            DisplayProcessStep " Creating manual edit file settings " $tabIndent
            Set-Content -LiteralPath $manualEditsSettingsFile -Value $null -Verbose
        }
    }
}

function ApplySettings {

    $profileName = GetActiveMOProfile

    SwitchSettings $profileName
    
}
function ClearSettings {

    RemovePreviousSettings
    ApplyGAMMAReshade
    ApplyGAMMAPatchedExes
    Copy-Item -Path $Global:gammaUserSettings -Destination "$Global:pathToAnomalyAppdata/user.ltx" -Force
    
}
function SwitchSettings {
    param (
        [Parameter(Mandatory = $false, Position = 0)]
        $profileName
    )
    
    if (($null -eq $profileName) -or ($profileName -eq "")){

        $profileName = SelectSettings
    }

    DisplayHeadingMessage " Switch to `"$profileName`" settings "

    if ($profileName -eq "G.A.M.M.A"){
        RemovePreviousSettings
        ApplyGAMMAReshade
        ApplyGAMMAPatchedExes
        ApplyGAMMASettings
    }else{

        # TODO move this check up when gamma dummy profiledef if is ever added as requirement - needs implementation in the ext install phase and in the future EXT definitions update command  
        $profileDefinitions = GetMOProfileDefinitions $profileName

        if ($null -eq $profileDefinitions){
            PromptMessageBeforeExit " This profile is $profileName not installed in MO "
        }

        $settingsPath = "$Global:pathToEXTSettings/$($profileDefinitions.profileName)"

        if (Test-Path -LiteralPath $settingsPath) {
            RemovePreviousSettings
            ApplyProfileReshade $profileDefinitions
            ApplyGAMMAPatchedExes
            ApplyProfilePatchedExes $profileDefinitions
            ApplyProfileSettings $profileDefinitions

        }else{
    
            DisplayErrorMessage " Settings for $profileDefinitions.profileName does not exists "
            PromptMessageBeforeExit ""
        }
    }
    Write-Host

    DisplayHeadingMessage " Profile Settings $profileName switch Completed! "
}


function ApplyGAMMAPatchedExes{
    
    DisplayProcessStep " Copying G.A.M.M.A modified Anomaly exes " ($tabIndent + $tabIndent)

    DisplayProcessStep "bin"
    Copy-Item -Path "$Global:pathToGAMMAPatches/bin/*" -Destination "$Global:pathToAnomaly/bin" -Recurse -Include *.exe, alsoft.ini, soft_oal.dll -Verbose 4>$Global:pathToEXTWorkspace\verbose.txt
    DisplayVerbose "" $tabIndent

    DisplayProcessStep "gamedata"
    Copy-Item -Path "$Global:pathToGAMMAPatches/gamedata" -Destination "$Global:pathToAnomaly" -Recurse -Force -Verbose 4>$Global:pathToEXTWorkspace\verbose.txt
    DisplayVerbose "" $tabIndent

    DisplayProcessStep "db"
    Copy-Item -Path "$Global:pathToGAMMAPatches/db" -Destination "$Global:pathToAnomaly" -Recurse -Force -Verbose 4>$Global:pathToEXTWorkspace\verbose.txt
    DisplayVerbose "" $tabIndent
}
function ApplyProfilePatchedExes{

    DisplayProcessStep " Copying Profile's modified Anomaly exes " ($tabIndent + $tabIndent)

    DisplayProcessStep "bin"
    $pathToExes = [WildcardPattern]::Escape("$Global:pathToEXTSettings/$($profileDefinitions.profileName)/bin")  + "/*"

    if (Test-Path -Path $pathToExes){
        Copy-Item -Path $pathToExes -Destination "$Global:pathToAnomaly/bin" -Include *.exe -Verbose 4>$Global:pathToEXTWorkspace\verbose.txt
        DisplayVerbose "" $tabIndent        
    }else{
        DisplayWarningMessage " Could not find any exe files in profile settings bin folder: $pathToExes "
    }

    DisplayProcessStep "gamedata"
    $pathToExes = [WildcardPattern]::Escape("$Global:pathToEXTSettings/$($profileDefinitions.profileName)/gamedata")
    if (Test-Path -Path $pathToExes){
        Copy-Item -Path $pathToExes -Destination "$Global:pathToAnomaly" -Recurse -Force -Verbose 4>$Global:pathToEXTWorkspace\verbose.txt
        DisplayVerbose "" $tabIndent
    }else{
        DisplayWarningMessage " Could not find any gamedata files in profile settings gamedata folder: $pathToExes "
    }

    DisplayProcessStep "db"
    $pathToMods = [WildcardPattern]::Escape("$Global:pathToEXTSettings/$($profileDefinitions.profileName)/db/mods")
    if (Test-Path -Path $pathToMods) {
        $dbFiles = Get-ChildItem -LiteralPath "$Global:pathToEXTSettings/$($profileDefinitions.profileName)/db/mods" -Filter "*.db*" -File
        if ($dbFiles.Count -gt 0) {
            foreach ($dbFile in $dbFiles) {
                DisplayProcessSubStep "Unpacking $($dbFile.Name)"
                UnpackSingleXr $dbFile.FullName "$Global:pathToAnomaly/gamedata"
            }
        } else {
            # Folder exists but is empty or contains no .db files
            DisplayWarningMessage "Could not find any db files in profile settings folder: $pathToMods"
        }
    } else {
        DisplayWarningMessage " Could not find folder: $pathToMods "
    }
}
function ApplyGAMMAReshade{

    RemoveExistingReshade
    DisplayProcessStep " Copying G.A.M.M.A default reshade " ($tabIndent + $tabIndent)
    Copy-Item -Path "$Global:pathToGAMMAReshade/*" -Destination $Global:pathToAnomalyBin -Recurse -Exclude *.exe, alsoft.ini, soft_oal.dll -Verbose 4>$Global:pathToEXTWorkspace\verbose.txt
    DisplayVerbose "\reshade-shaders\" $tabIndent

    DisplayProcessStep " Applying G.A.M.M.A reshade custom settings" ($tabIndent + $tabIndent)
    Copy-Item -Path "./settings/G.A.M.M.A/bin/*" -Destination $Global:pathToAnomalyBin -Verbose 4>$Global:pathToEXTWorkspace\verbose.txt
    DisplayVerbose "" $tabIndent

    RemoveShaderCache
}

function ApplyGAMMAReshadeDlls{

    DisplayProcessStep " Copying G.A.M.M.A default reshade binaries " ($tabIndent + $tabIndent)
    Copy-Item -Path "$Global:pathToGAMMAReshade/dxgi.dll" -Destination $Global:pathToAnomalyBin -Verbose 4>$Global:pathToEXTWorkspace\verbose.txt
    DisplayVerbose "" $tabIndent
}

function ApplyGAMMAReshadeIni{

    DisplayProcessStep " Copying G.A.M.M.A default reshade ini " ($tabIndent + $tabIndent)
    Copy-Item -Path "$Global:pathToGAMMAReshade/ReShade.ini" -Destination $Global:pathToAnomalyBin -Verbose 4>$Global:pathToEXTWorkspace\verbose.txt
    DisplayVerbose "" $tabIndent
}

function ApplyGAMMASettings{
    
    # RemovePreviousSettings

    GenerateGAMMAUserSettings

    DisplayProcessStep " Apply GAMMA profile saved settings " ($tabIndent + $tabIndent)
    
    New-Item -ItemType Directory "$Global:GAMMAOverwrite/appdata" -Force | Out-Null
    Copy-Item -Path $Global:pathToGAMMASettingsAppdata -Destination "$Global:GAMMAOverwrite/appdata" -Force -Exclude .gitignore, user.ltx -Verbose 4>$Global:pathToEXTWorkspace\verbose.txt

    DisplayVerbose "" $tabIndent

    # ApplyMCMSettings "G.A.M.M.A"

}

function ApplyProfileReshade{

    param (
        [Parameter(Mandatory = $true, Position = 0)]
        $profileDefinitions
    )

    $binFolder =  "$Global:pathToEXTSettings/$($profileDefinitions.profileName)/bin"

    if (Test-Path -LiteralPath $binFolder){

        $binFiles = Get-ChildItem -LiteralPath $binFolder -Name

        if ($null -ne $binFiles -and $binFiles.Length -gt 0){

            RemoveExistingReshade

            $hasReshade = CheckIfBinHasReshadeFiles $binFiles

            if ($hasReshade -eq $False){
                Write-Host
                DisplayNoticeMessage " No Reshade was found in settings for this profile, applying G.A.M.M.A default reshades instead "
                ApplyGAMMAReshade
                return
            }

            Write-Host
            DisplayProcessStep " Copying $profileName reshade files "
            
            $pathToReshadeBin = [WildcardPattern]::Escape("$Global:pathToEXTSettings/$profileName/bin") + "/*"

            Copy-Item -Path $pathToReshadeBin -Destination $Global:pathToAnomalyBin -Force -Recurse -Exclude *.exe, alsoft*, soft_oal* -Verbose 4>$Global:pathToEXTWorkspace\verbose.txt

            DisplayVerbose "\reshade-shaders\" $tabIndent

            $hasReshadeDlls = $binFiles | ForEach-Object {
                if ($_.EndsWith(".dll")){
                    return $true
                }
            } 
            if (!$hasReshadeDlls){
                ApplyGAMMAReshadeDlls
            }

            $hasReshadeIni = Get-ChildItem -LiteralPath $binFolder -Name | ForEach-Object {
                if ($_ -eq "ReShade.ini"){
                    return $true
                }
            }
            
            if (!$hasReshadeIni){
                ApplyGAMMAReshadeIni
            }
            
            $shadersCachePatch = $profileDefinitions.gamePatches | Where-Object { $_.patchType -eq "shaders_cache" } 

            if ($null -eq $shadersCachePatch){
                RemoveShaderCache
            }else{
                DisplayNoticeMessage " Settings use its own shaders_cache "
                DisplayNoticeText "     >> shader_cache not deleted"
            }
        }else{
            DisplayWarningMessage " Could not find any reshade files in profile settings bin folder: $binFolder "
            Write-Host
            DisplayNoticeMessage " No Reshade was found in settings for this profile, applying G.A.M.M.A default reshades instead "
            ApplyGAMMAReshade
        }
    }else{
        DisplayWarningMessage " Could not find profile settings bin folder: $binFolder "
        Write-Host
        DisplayNoticeMessage " No Reshade was found in settings for this profile, applying G.A.M.M.A default reshades instead "
        ApplyGAMMAReshade        
    }
}

function CheckIfBinHasReshadeFiles{
    param (
        [Parameter(Mandatory = $true, Position = 0)]
        $binFiles
    )

    foreach ($binFile in $binFiles) {
        if ($binFile.EndsWith(".ini") -or ($binFile -eq "reshade-shaders")){
            return $True
        }
    }

    return $False
}

function ApplyProfileSettings {
    param (
        [Parameter(Mandatory = $true, Position = 0)]
        $profileDefinitions
    )

    # RemovePreviousSettings

    GenerateUserSettings $profileDefinitions

    ApplyMCMSettings $profileDefinitions.profileName "mcm_default_settings"

    ApplyMCMSettings $profileDefinitions.profileName "mcm_saved_settings" $true

    $appdata = "$Global:pathToEXTSettings/$($profileDefinitions.profileName)/appdata"

    if (Test-Path -LiteralPath $appdata){
        $patches = Get-ChildItem -LiteralPath $appdata
        
        if ($patches.Exists){
            Write-Host
            DisplayProcessStep " Apply profile saved settings " ($tabIndent + $tabIndent)

            $pathToPatches =  [WildcardPattern]::Escape("$Global:pathToEXTSettings/$($profileDefinitions.profileName)/appdata") + "/*"
            New-Item -ItemType Directory "$Global:GAMMAOverwrite/appdata" -Force | Out-Null
            Copy-Item -Path $pathToPatches -Destination "$Global:GAMMAOverwrite/appdata" -Recurse -Force -Exclude user.ltx -Verbose 4>$Global:pathToEXTWorkspace\verbose.txt
            
            DisplayVerbose "" $tabIndent

            # ApplyMCMSettings $profileDefinitions.profileName
        }else{
            DisplayWarningMessage " no saved settings were found for this profile "
        }
    }else{
        DisplayWarningMessage " no saved settings were found for this profile "
    }
}

function RemoveExistingReshade {
        
    Remove-Item -Path "$Global:pathToAnomalyBin/*.*" -Recurse -Exclude alsoft.ini, AnomalyDX*, discord_game_sdk.dll, icu*, soft_oal*, tbb*, VerifiedDX11*

    $folders = Get-ChildItem -Path $Global:pathToAnomalyBin -Directory

    foreach ($folder in $folders) {
        Remove-Item -LiteralPath $folder.FullName -Force -Recurse 
    }

}

function RemovePreviousSettings {
    
    if (Test-Path -Path "$Global:GAMMAOverwrite/appdata"){
        Remove-Item -Force -Recurse -LiteralPath "$Global:GAMMAOverwrite/appdata"
    }
    if (Test-Path -Path "$Global:GAMMAOverwrite/bin"){
        Remove-Item -Force -Recurse -LiteralPath "$Global:GAMMAOverwrite/bin"
    }
    if (Test-Path -Path "$Global:GAMMAOverwrite/gamedata"){
        Remove-Item -Force -Recurse -LiteralPath "$Global:GAMMAOverwrite/gamedata"
    }
    if (Test-Path -Path "$Global:GAMMAOverwrite/db"){
        Remove-Item -Force -Recurse -LiteralPath "$Global:GAMMAOverwrite/db"
    }      
    
    Remove-Item -Force -Recurse -LiteralPath "$Global:pathToAnomaly/gamedata/*"
}

function RemoveShaderCache{

    if (Test-Path -Path $Global:AnomalyShaderCache){
        Remove-Item -Force -Recurse -LiteralPath $Global:AnomalyShaderCache
    }
    Write-Host
    DisplayNoticeMessage " Deleted shader_cache "
}

function SelectSettings {

    $settingsProfiles = Get-ChildItem -LiteralPath $Global:pathToEXTSettings -Directory

    $settingsChoices = @()


    for ($i=0; $i -lt $settingsProfiles.Count; $i++) {
      $settingsChoices += [System.Management.Automation.Host.ChoiceDescription]("$($settingsProfiles[$i].Name) (&$($i+1))")
    }
    
    $userChoice = $host.UI.PromptForChoice('Select any settings from the list to apply that specific settings or G.A.M.M.A. to revert to the GAMMA default settings ', 'PLease select one:', $settingsChoices, 0)
    Write-Host
    DisplayNoticeMessage "you selected $($settingsProfiles[$userChoice].Name)"
    Write-Host
    return $settingsProfiles[$userChoice].Name
}

function SynchSettings{
    param (
        [Parameter(Mandatory = $true, Position = 0)]
        $profileDefinitions
    )    

    CreateGamePatchesWorkspace $profileDefinitions

    SetSettingsFolders $profileDefinitions.profileName

    ApplyPatches $profileDefinitions.gamePatches $profileDefinitions.profileName

}
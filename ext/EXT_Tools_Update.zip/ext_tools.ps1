param (
    [Parameter(Mandatory = $false)][switch]$update,
    [Parameter(Mandatory = $false)][switch]$install,
    [Parameter(Mandatory = $false)][switch]$validate,
    [Parameter(Mandatory = $false)][switch]$download,
    [Parameter(Mandatory = $false)][switch]$offline
)

$Global:AppProps

function LoadProperties {
    $Global:AppProps = convertfrom-stringdata (get-content "./app.properties" -raw).Replace("\","/")

    if ((Test-Path -Path $Global:AppProps.'gammafolder') -eq $False) {
        Write-Host cannot find path to $Global:AppProps.'gammafolder' - ensure gammafolder in app.properties points to your GAMMA folder -ForegroundColor Yellow -BackgroundColor DarkRed
        exit
    } 
    
    if ((Test-Path -Path $Global:AppProps.'anomalyfolder') -eq $False) {
        Write-Host cannot find path to $Global:AppProps.'anomalyfolder' - ensure anomalyfolder in app.properties points to your Anomaly folder -ForegroundColor Yellow -BackgroundColor DarkRed
        exit
    } 
    
    if ((Test-Path -Path $Global:AppProps.'extfolder') -eq $False) {
        Write-Host cannot find path to $Global:AppProps.'extfolder' - ensure extfolder in app.properties points to GAMMA-EXT folder -ForegroundColor Yellow -BackgroundColor DarkRed
        exit
    } 

    if ((Test-Path -Path $AppProps.'7zipFolder') -eq $False) {
        Write-Host cannot find path to $AppProps.'7zipFolder' - ensure 7zipFolder in app.properties points to your 7z installation folder -ForegroundColor Yellow -BackgroundColor DarkRed
        exit
    }
    
}



function RemoveOldVersion {

    Write-Host
    Write-Host "    " -NoNewline
    Write-Host " Remove Old EXT Version " -ForegroundColor Red -BackgroundColor Yellow

    Remove-Item -Path "./ext" -Force -Recurse
    Remove-Item -Path "./GAMMA_EXT.ps1" -Force -Recurse

    try {
        # Remove-Item -Path "./resources" -Force -Recurse -ErrorAction Stop
        Remove-Item -Path "./updater.ps1" -Force  -ErrorAction Stop
        Remove-Item -Path "./modders-resources" -Force -Recurse  -ErrorAction Stop
    }catch { 
        # Write-Host "       Tried to delete some old files but were not found. It's All Good" -ForegroundColor Yellow
    }    

}

function RemoveOldGAMMAProfiles {

    Write-Host
    Write-Host "    " -NoNewline
    Write-Host " Remove Old GAMMA-EXT Profiles " -ForegroundColor Red -BackgroundColor Yellow

    try {
        # Remove-Item -Path "./profiles/GAMMA Majestic Weatherfx" -Force -Recurse -ErrorAction Stop
        # Remove-Item -Path "./profiles/GAMMA Season's Redux - All Seasons" -Force -Recurse -ErrorAction Stop
        # Remove-Item -Path "./profiles/GAMMA Season's Redux - Autumn" -Force -Recurse -ErrorAction Stop
        # Remove-Item -Path "./profiles/GAMMA Season's Redux - Golden Autumn" -Force -Recurse -ErrorAction Stop
        # Remove-Item -Path "./profiles/GAMMA Season's Redux - Summer" -Force -Recurse -ErrorAction Stop
        # Remove-Item -Path "./profiles/GAMMA Season's Redux - Winter" -Force -Recurse -ErrorAction Stop
        Remove-Item -Path "./profiles/GAMMA Expedition Reshade & Weather" -Force -Recurse -ErrorAction Stop
        Remove-Item -Path "./profiles/GAMMA R.A.W" -Force -Recurse -ErrorAction Stop
    }
    catch { 
        # Write-Host "       Tried to delete an old profile but it was not found. It's All Good" -ForegroundColor Yellow
    }
}

function RemoveUnsupportedProfiles {

    Write-Host
    Write-Host "    " -NoNewline
    Write-Host " Remove Unsupported Profiles " -BackgroundColor Yellow -ForegroundColor Red

    $unsupportedProfile = "./profiles/GAMMA EXP Edition"
    if (Test-Path -LiteralPath $unsupportedProfile){
        PromptToDeleteProfile $unsupportedProfile
    }
    $unsupportedProfile = "./profiles/GAMMA Season's Redux - All Seasons"
    if (Test-Path -LiteralPath $unsupportedProfile){
        PromptToDeleteProfile $unsupportedProfile
    }
    $unsupportedProfile = "./profiles/GAMMA Season's Redux - Autumn"
    if (Test-Path -LiteralPath $unsupportedProfile){
        PromptToDeleteProfile $unsupportedProfile
    }
    $unsupportedProfile = "./profiles/GAMMA Season's Redux - Golden Autumn"
    if (Test-Path -LiteralPath $unsupportedProfile){
        PromptToDeleteProfile $unsupportedProfile
    }
    $unsupportedProfile = "./profiles/GAMMA Season's Redux - Summer"
    if (Test-Path -LiteralPath $unsupportedProfile){
        PromptToDeleteProfile $unsupportedProfile
    }
    $unsupportedProfile = "./profiles/GAMMA Season's Redux - Winter"
    if (Test-Path -LiteralPath $unsupportedProfile){
        PromptToDeleteProfile $unsupportedProfile
    }
    $unsupportedProfile = "./profiles/GAMMA Majestic Weatherfx"
    if (Test-Path -LiteralPath $unsupportedProfile){
        PromptToDeleteProfile $unsupportedProfile
    }        
}

function PromptToDeleteProfile {
    param (
        $unsupportedProfile
    )

    # Write-Host
    # Write-Host " You have an unsupported demo profile -ForegroundColor Yellow"    
    # Write-Host
    # Write-Host
    # Write-Host "    " -NoNewline
    # Write-Host
    # Write-Host "    " -NoNewline        
    # Write-Host " $unsupportedProfile " -BackgroundColor Yellow -ForegroundColor Red
    # Write-Host
    # Write-Host "        Unsupported demo profiles don't get anymore updates and are not garanteed to install with future GAMMA-EXT updates"
    # Write-Host
    # Write-Host "        Do you want to delete them now? "
    # Write-Host "        Alternatively you can keep them and delete it whenever you want with command .\GAMMA_EXT.ps1 -remove `"profileName`" "
    # Write-Host
    # Write-Host "        If you are unsure on what to do type Yes " -ForegroundColor Yellow
    # Write-Host
    # $Prompt = " Type `"Yes`" to remove this profile, `"No`" to keep it"
    # $Choices = [System.Management.Automation.Host.ChoiceDescription[]] @("&Yes", "&No")
    # $Default = 1

    # # Prompt for the choice
    # $Choice = $global:Host.UI.PromptForChoice($Title, $Prompt, $Choices, $Default)
     
    # switch($Choice)
    # {
    #     0 { 
    #         Remove-Item -LiteralPath $unsupportedProfile -Force -Recurse -ErrorAction Stop
    #     }
    #     1 { 
    #         # selected No --> skip
    #     }
    # }

    Remove-Item -LiteralPath $unsupportedProfile -Force -Recurse -ErrorAction Stop
}

function RemoveOldGAMMASettings {

    Write-Host
    Write-Host "    " -NoNewline
    Write-Host " Remove Old GAMMA Settings " -ForegroundColor Red -BackgroundColor Yellow

    if (Test-Path "./settings/G.A.M.M.A/appdata/user.ltx"){
        Remove-Item -Path "./settings/G.A.M.M.A/appdata/user.ltx" -Force
    }

    $anomalyAppdata = $Global:AppProps.'anomalyfolder' + "/appdata"

    if (Test-Path "$anomalyAppdata/manual_edits_settings.ltx" ){

    }

    if (Test-Path "$anomalyAppdata/saved_settings.ltx" ){
        
    }    
}

function RemoveOldGuides {

    Write-Host
    Write-Host "    " -NoNewline
    Write-Host " Remove Old Guides " -ForegroundColor Red -BackgroundColor Yellow

    Remove-Item -Path "./*.pdf" -Force -Recurse
    
}

function CopyNewEXTVersion {

    Write-Host
    Write-Host "    " -NoNewline
    Write-Host " Copy New EXT Version" -ForegroundColor White -BackgroundColor Blue

    $target = "./workspace/updater/G.A.M.M.A. EXT/ext"
    Copy-Item -Path $target -Destination "." -Force -Recurse

    # $target = "./workspace/updater/G.A.M.M.A. EXT/resources"
    # Copy-Item -Path $target -Destination "." -Force -Recurse

    $target = "./workspace/updater/G.A.M.M.A. EXT/GAMMA_EXT.ps1"
    Copy-Item -Path $target -Destination "." -Force -Recurse

}

function CopyNewProfiles {

    Write-Host
    Write-Host "    " -NoNewline
    Write-Host " Copy New Profiles " -ForegroundColor White -BackgroundColor Blue

    $target = "./workspace/updater/G.A.M.M.A. EXT/profiles"
    Copy-Item -Path $target -Destination "." -Force -Recurse
}

function CopyNewSettings {

    Write-Host
    Write-Host "    " -NoNewline
    Write-Host " Copy New Settings " -ForegroundColor White -BackgroundColor Blue

    $target = "./workspace/updater/G.A.M.M.A. EXT/settings"
    Copy-Item -Path $target -Destination "." -Force -Recurse
}

function CopyNewGuides {

    Write-Host
    Write-Host "    " -NoNewline
    Write-Host " Copy New Guides " -ForegroundColor White -BackgroundColor Blue

    $target = "./workspace/updater/G.A.M.M.A. EXT/*.pdf"
    Copy-Item -Path $target -Destination "." -Force -Recurse
}

function DisplayUpdateWarning {

    Write-Host " You are about to update your GAMMA-EXT " -ForegroundColor Red -BackgroundColor Yellow
    Write-Host
    Write-Host " The following settings will be deleted/replaced " -ForegroundColor Yellow
    Write-Host
    Write-Host "    " -NoNewline
    Write-Host " G.A.M.M.A " -ForegroundColor Red -BackgroundColor Yellow
    Write-Host "    " -NoNewline
    Write-Host "    " -NoNewline
    Write-Host "The files in [settings/G.A.M.M.A] will be updated" -ForegroundColor Yellow
    Write-Host "    " -NoNewline
    Write-Host "    " -NoNewline
    Write-Host "before doing so a backup is automatically created in the [backups] folder" -ForegroundColor Yellow
    Write-Host "    " -NoNewline
    Write-Host "    " -NoNewline
    Write-Host "use that to replace what settings you need (e.g. reshade presets, user.ltx)" -ForegroundColor Yellow 
    Write-Host
    Write-Host '    Press any key to continue...';
    $null = $Host.UI.RawUI.ReadKey('NoEcho,IncludeKeyDown');
}

function DisplayInstallWarning {

    Write-Host " You are about to install GAMMA-EXT " -ForegroundColor Red -BackgroundColor Yellow
    Write-Host
    Write-Host " Before you proceed make sure you have configured the app.properties file correctly " -ForegroundColor Yellow
    Write-Host
    Write-Host '    Press any key to continue...';
    $null = $Host.UI.RawUI.ReadKey('NoEcho,IncludeKeyDown');
}

function CreateShortcut {
    param ( 
        [string]$SourceExe, 
        [string]$ArgumentsToSourceExe,
        [string]$startsIn, 
        [string]$DestinationPath 
    )

    # $WshShell = New-Object -comObject WScript.Shell
    $Shortcut = $WshShell.CreateShortcut($DestinationPath)
    $Shortcut.TargetPath = $SourceExe
    $Shortcut.WorkingDirectory = $startsIn
    $Shortcut.Arguments = $ArgumentsToSourceExe
    $Shortcut.IconLocation = $Global:AppProps.'extfolder' + "\resources\ext_icon.ico"
    $Shortcut.Save()
}


function CreateEXTShortcuts {

    Write-Host
    Write-Host "    " -NoNewline
    Write-Host " Create EXT shortcuts " -ForegroundColor White -BackgroundColor Blue

    $WshShell = New-Object -comObject WScript.Shell
    $baseDestination = $WshShell.SpecialFolders("Desktop")

    $powershellExe = "C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe"
    $startsIn = $Global:AppProps.'extfolder'
    $arguments = "-ExecutionPolicy Bypass -File `"$startsIn\GAMMA_EXT.ps1`" -switch_settings"
    $destination = $baseDestination +"\GAMMA EXT - Switch Profile Settings.lnk"

    CreateShortcut $powershellExe $arguments $startsIn $destination

    $arguments = "-ExecutionPolicy Bypass -File `"$startsIn\GAMMA_EXT.ps1`" -apply_settings"
    $destination = $baseDestination +"\GAMMA EXT - Apply Profile Settings.lnk"

    CreateShortcut $powershellExe $arguments $startsIn $destination

    $arguments = "-ExecutionPolicy Bypass -File `"$startsIn\GAMMA_EXT.ps1`" -save_settings"
    $destination = $baseDestination +"\GAMMA EXT - Save Profile Settings.lnk"

    CreateShortcut $powershellExe $arguments $startsIn $destination

    $arguments = ""
    $destination = $baseDestination + "\GAMMA EXT Console.lnk"

    CreateShortcut $powershellExe $arguments $startsIn $destination
}
function UpdateMoIni{

    Write-Host
    Write-Host "    " -NoNewline
    Write-Host " Update Mod Organizer ini " -ForegroundColor White -BackgroundColor Blue

    $pathToMOIni = $Global:AppProps.'gammafolder' +"/ModOrganizer.ini"
    $pathToMOIniNew = $Global:AppProps.'gammafolder' +"/ModOrganizer.ini"
    $pathToMOIniBackup = $Global:AppProps.'gammafolder' +"/ModOrganizer.ini.extbackup"

    $pathToEXTMOCustomExecutables = "resources/extcustomexec.txt"

    if (!(Test-Path -LiteralPath $pathToMOIniBackup)){
        Copy-Item -LiteralPath $pathToMOIni -Destination $pathToMOIniBackup
    }

    $moIni = Get-Content -Path $pathToMOIni
    $moIniNew=@()
    $customExecutablesFound = $false
    $customExecCount

    foreach($line in $MOIni)
    {

        if ($customExecutablesFound){

            if ($line -clike "size=*"){
                $value = $line.Split('=',2)
                [int]$origCustomExecCount = $value[1]
                $newCustomExecCount = $origCustomExecCount + 4

                $line = "size=$newCustomExecCount"
            }

            $customExecutablesFound = $false
        }

        if ($line -clike "``[customExecutables``]"){
            $customExecutablesFound = $true
        }


        if ($line -clike "``[recentDirectories``]"){
            
            
            $moIni = Get-Content -Path $pathToMOIni
            $extCust = Get-Content -Path $pathToEXTMOCustomExecutables

            foreach($item in $extCust){

                $extFolderEscaped = ($Global:AppProps.'extfolder').Replace("/", "\").Replace("\", "\\")


                $item = $item.Replace("%extfolder%", $extFolderEscaped)
                $execId = $origCustomExecCount +1 
                $item = $item.Replace("%exec1%","$execId")
                $execId = $origCustomExecCount +2 
                $item = $item.Replace("%exec2%","$execId")
                $execId = $origCustomExecCount +3 
                $item = $item.Replace("%exec3%","$execId")
                $execId = $origCustomExecCount +4 
                $item = $item.Replace("%exec4%","$execId")
                $moIniNew += $item
            }
        }


        $moIniNew += $line
    }  

    Set-Content -Path $pathToMOIniNew $moIniNew

}

function ArchiveSettingsTools{
    Param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        $settingsProfileName
    )
    
    $profileSettingsBinFolder = "settings/" + $settingsProfileName + "/bin"
    $profileSettingsAppdataFolder = "settings/" + $settingsProfileName + "/appdata"
    $tempSettingsFolder = "workspace/tmp/settings"
    Write-Host
    Write-Host " Archiving current settings "  -BackgroundColor DarkMagenta -ForegroundColor Yellow

    $tabIndent = "    "

    New-Item -Path $tempSettingsFolder -ItemType Directory -Force | Out-Null
    Copy-Item -LiteralPath $profileSettingsBinFolder -Destination $tempSettingsFolder
    Copy-Item -LiteralPath $profileSettingsAppdataFolder -Destination $tempSettingsFolder

    # $timestamp = Get-Date -Format "_MM-dd-yyyy-HH-mm"

    $archiveFile = "backups/" + ($settingsProfileName).Replace(" ","_") + ".zip"

    if (Test-Path -LiteralPath $archiveFile){
        Remove-Item -LiteralPath $archiveFile
    }

    $compress = @{
        Path = $tempSettingsFolder
        CompressionLevel = "Fastest"
        DestinationPath = $archiveFile
    }
    Compress-Archive @compress -Force

    $tmpFolder =  "workspace/tmp"
    Remove-Item -LiteralPath $tmpFolder -Recurse -Force | Out-Null
    
    Write-Host
    Write-Host "$tabIndent The profile's settings has been saved as backup in " -ForegroundColor Yellow
    Write-Host
    Write-Host "$tabIndent $($compress.DestinationPath)" -ForegroundColor Yellow

}

function Validate7z {
    
    Write-Host " Validate 7zip " -BackgroundColor DarkMagenta -ForegroundColor Yellow

    $7zPath =  $Global:AppProps.'7zipFolder' + "/7z"
    
    $command = ". `"$7zPath`""
    try{
        Invoke-Expression $command
    }catch{
        Write-Host " Cannot run 7z.exe, please check that 7zipFolder value in app.properties is correctly set to your 7z install folder "  -ForegroundColor Yellow -BackgroundColor DarkRed
    }
    

}

function DownloadExtRelease {

    if ((Test-Path -Path "./shared") -eq $false){
        New-Item -Path "./shared" -ItemType Directory | Out-Null
    }

    $extUrl = "https://github.com/strangerism/EXT_REPOS/raw/refs/heads/master/ext/GAMMA_EXT.zip"
    # $extUrl = "https://mega.nz/file/cCImnZrb#fpKoo4iOFoYmO7X6Lc3VJ-DbscuxXsWr6kV9m4lrp2g"

    Write-Host " Downloading EXT release file " -BackgroundColor DarkMagenta -ForegroundColor Yellow
    Write-Host " hold on... "

    # Invoke-WebRequest -Uri $extUrl -OutFile ".\shared\GAMMA_EXT.zip" -SessionVariable googleDriveSession -ErrorAction Stop
    # $WebClient = New-Object System.Net.WebClient
    # $WebClient.DownloadFile($extUrl,".\shared\GAMMA_EXT.zip")
    Start-BitsTransfer -Source $extUrl -Destination ".\shared\GAMMA_EXT.zip" -ErrorAction Stop

    Write-Host
    Write-Host " EXT Latest Release Downloaded "  -BackgroundColor DarkMagenta -ForegroundColor Yellow
    Write-Host    
}

function CreateSericeFolders {

    if ((Test-Path -Path "./addons") -eq $false){
        New-Item -Path "./addons" -ItemType Directory
    }

    if ((Test-Path -Path "./backups") -eq $false){
        New-Item -Path "./backups" -ItemType Directory
    }    
}

## EXT TOOLS MAIN

$version = 0.7

$banner = Get-Content -Path "resources/welcome-banner.txt" -Raw

Write-Host -ForegroundColor DarkGreen -BackgroundColor Black $banner

Write-Host -ForegroundColor DarkGreen -BackgroundColor Black "ext_tools Version $version"

Write-Host


if ($validate.IsPresent){
    LoadProperties
    Validate7z
}

Write-Host
Write-Host " Before continuing with the install or update CLOSE Mod Organizer " -ForegroundColor Red -BackgroundColor Yellow
Write-Host
Write-Host 'Press any key to continue...';
$null = $Host.UI.RawUI.ReadKey('NoEcho,IncludeKeyDown');   
Write-Host

if ($update.IsPresent){

    Write-Host  
    if (!$offline.IsPresent){
        DownloadExtRelease
    }
    $updateFile = "shared/GAMMA_EXT.zip"

    Write-Host " GAMMA EXT Update " -BackgroundColor DarkMagenta -ForegroundColor Yellow
    Write-Host

    if (Test-Path -Path $updateFile){
    
        DisplayUpdateWarning

        # ArchiveSettingsTools "G.A.M.M.A"

        $dest = "./workspace/updater"
    
        New-Item -Path $dest -Force -ItemType Directory | Out-Null
    
        Expand-Archive -Force -Path $updateFile -DestinationPath $dest | Out-Null
    
        RemoveOldVersion
    
        RemoveUnsupportedProfiles
        
        RemoveOldGAMMAProfiles
        
        RemoveOldGAMMASettings

        RemoveOldGuides
    
        CopyNewEXTVersion
    
        CopyNewProfiles
    
        CopyNewGuides
    
        CopyNewSettings

        CreateSericeFolders

        . ".\ext\CustomMods.ps1"
        . ".\ext\Globals.ps1"
        . ".\ext\ModMetaIni.ps1"

        RemoveEXTSeparatorMod

        CreateEXTSeparatorMod

        CreateProfileCustomModsSignposts

        Remove-Item -Path $dest -Force -Recurse
    
        Write-Host
        Write-Host " EXT Update Complete "  -BackgroundColor DarkMagenta -ForegroundColor Yellow
        Write-Host
        Write-Host
    } 
    else{
        Write-Host
        Write-Host "cannot find update file GAMMA_EXT.zip in ./shared" -ForegroundColor Yellow -BackgroundColor Red
    }
    

}


if ($install.IsPresent){

    Write-Host  
    if (!$offline.IsPresent){
        DownloadExtRelease
    }

    $updateFile = "shared/GAMMA_EXT.zip"

    Write-Host " GAMMA EXT Install " -BackgroundColor DarkMagenta -ForegroundColor Yellow
    Write-Host
    Write-Host

    if (Test-Path -Path $updateFile){

        DisplayInstallWarning

        LoadProperties

        Validate7z

        UpdateMoIni

        $dest = "./workspace/updater"
    
        New-Item -Path $dest -Force -ItemType Directory | Out-Null
    
        Expand-Archive -Force -Path $updateFile -DestinationPath $dest | Out-Null

        CopyNewEXTVersion
    
        CopyNewProfiles
    
        CopyNewGuides
    
        CopyNewSettings

        CreateEXTShortcuts

        CreateSericeFolders

        . ".\ext\CustomMods.ps1"
        . ".\ext\Globals.ps1"
        . ".\ext\ModMetaIni.ps1"

        RemoveEXTSeparatorMod

        CreateEXTSeparatorMod

        CreateProfileCustomModsSignposts

        Remove-Item -Path $dest -Force -Recurse
    
        Write-Host
        Write-Host "G.A.M.M.A. EXT Install Complete"  -BackgroundColor DarkMagenta -ForegroundColor Yellow
        Write-Host
        Write-Host
    } 
    else{
        Write-Host
        Write-Host "cannot find install file GAMMA_EXT.zip in ./shared" -ForegroundColor Yellow -BackgroundColor Red
    }
}

if ($download.IsPresent){

    DownloadExtRelease
    Write-Host
    Write-Host " run  .\ext_tools.ps1 -update to update EXT " -ForegroundColor Yellow

}
